prompt --application/shared_components/navigation/lists/application_configuration
begin
--   Manifest
--     LIST: Application Configuration
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(184271080153096961)
,p_name=>'Application Configuration'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(184109230400094878)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(184271515527096961)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Configuration Options'
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&SESSION.::&DEBUG.:10010:::'
,p_list_item_icon=>'fa-sliders'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>'Enable or disable application features'
,p_required_patch=>wwv_flow_imp.id(184109230400094878)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(140012321041797966)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Remote Update Configurations'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ROWID:&P10000_REMOTE_CONF_ROWID.:'
,p_list_item_icon=>'fa-sliders'
,p_list_text_01=>'Remote update configurations'
,p_required_patch=>wwv_flow_imp.id(184109230400094878)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(140710462601211476)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Manage Automations'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:24:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Manage Automations'
,p_required_patch=>wwv_flow_imp.id(184109230400094878)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16794306607331586)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Manage Profiles'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.:44:::'
,p_list_item_icon=>'fa-flag-o'
,p_list_text_01=>'Manage Profiles'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
