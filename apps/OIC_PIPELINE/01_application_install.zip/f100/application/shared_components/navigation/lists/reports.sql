prompt --application/shared_components/navigation/lists/reports
begin
--   Manifest
--     LIST: Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(161440001833356692)
,p_name=>'Reports'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(184108966515094878)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161440200775356695)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inconsistencies'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:::'
,p_list_item_icon=>'fa-exclamation-square-o'
,p_list_text_01=>'View inconsistencies between environments'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161545881222452579)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Pipeline View'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:14:::'
,p_list_item_icon=>'fa-exchange'
,p_list_text_01=>'View pipeline status'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161546418005456754)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Schedules'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-window-clock'
,p_list_text_01=>'View schedule status'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161546906676460038)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Last Integration Changes'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-user-cursor'
,p_list_text_01=>'Last Integration Changes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161599562577901973)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Compare Environments'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18:::'
,p_list_item_icon=>'fa-box-plot-chart'
,p_list_text_01=>'Compare Environments differences'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24514707280211305)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Compare Lookups'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-table-search'
,p_list_text_01=>'Compare Lookup differences beetween environments'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
