prompt --application/shared_components/automations/sync_integrations
begin
--   Manifest
--     AUTOMATION: Sync Integrations
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(183433369651666520)
,p_name=>'Sync Integrations'
,p_static_id=>'sync-integrations'
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=MINUTELY;INTERVAL=15'
,p_polling_status=>'ACTIVE'
,p_result_type=>'ALWAYS'
,p_use_local_sync_table=>false
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(183434114266670150)
,p_automation_id=>wwv_flow_imp.id(183433369651666520)
,p_name=>'oic_pip_prc_auto_int_downloads'
,p_execution_sequence=>20
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_prc_auto_int_downloads;',
'END;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
