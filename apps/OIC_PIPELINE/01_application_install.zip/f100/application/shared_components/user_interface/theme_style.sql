prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(7995262973334469)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(7995600230334469)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(7996034082334470)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(7996466929334470)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(7996866827334471)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(19819586415930211)
,p_theme_id=>42
,p_name=>'Vita (OIC_PIPELINE)'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#less/theme/Vita.less',
'#THEME_DB_FILES#less/fos-notification-themeroller.less'))
,p_theme_roller_config=>'{"classes":[],"vars":{"@fos-notif-title-font-size":"1.1rem","@fos-notif-title-font-weight":"100undefined","@fos-notif-message-font-size":"1rem","@fos-notif-message-font-weight":"100undefined","@fos-notif-min-width":"200px","@fos-notif-max-width":"480'
||'px","@fos-notif-opacity":"0.9undefined","@g_Container-BorderRadius":"2px","@irrBg":"#ffffff","@g_Nav_Style":"light","@g_Nav-BG":"#dae0e5","@g_Nav-FG":"#172d41","@g_Nav-Active-BG":"#b3bbc3","@g_Nav-Active-FG":"#000000","@g_Accent-BG":"#3a5369","@g_Acc'
||'ent-OG":"#ffffff","@g_Link-Base":"#1176c4","@g_Color-Palette-1":"#1e89c3","@g_Color-Palette-1-FG":"#ffffff","@g_Color-Palette-2":"#0e8ea2","@g_Color-Palette-2-FG":"#e4f9fd","@g_Color-Palette-3":"#229997","@g_Color-Palette-3-FG":"#f0fcfb","@g_Color-Pa'
||'lette-4":"#2d8c69","@g_Color-Palette-4-FG":"#f0faf6","@g_Color-Palette-5":"#629c40","@g_Color-Palette-5-FG":"#ffffff","@g_Color-Palette-6":"#c7c924","@g_Color-Palette-6-FG":"#2a2a08","@g_Color-Palette-7":"#f2b606","@g_Color-Palette-7-FG":"#443302","@'
||'g_Color-Palette-8":"#ce5a12","@g_Color-Palette-8-FG":"#ffffff","@g_Focus":"#22374a","@g_NavBarMenu-BG":"#ffffff","@g_NavBarMenu-FG":"#262626","@g_Nav-Badge-BG":"#3a5369","@g_Nav-Badge-FG":"#ffffff","@g_Nav-Accent-BG":"#1264ab","@g_Nav-Accent-FG":"#ff'
||'ffff","@g_Nav-Icon":"#277fce","@g_Nav-Icon-Active":"#000000"},"customCSS":"","useCustomLess":"Y"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#19819586415930211.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
