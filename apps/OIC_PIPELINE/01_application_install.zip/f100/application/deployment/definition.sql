prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(181911745582677249)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    FOR reg IN (SELECT object_name',
'                     , DECODE(object_type, ''PACKAGE BODY'', ''PACKAGE'', object_type) object_type',
'                 FROM user_objects',
'                WHERE object_type not in (''PACKAGE BODY'', ''TABLE'', ''INDEX'', ''LOB'', ''CREDENTIAL''))',
'    LOOP',
'        EXECUTE IMMEDIATE ''DROP '' || reg.object_type || '' '' || reg.object_name;',
'    END LOOP;',
'',
'    FOR reg IN (SELECT constraint_name, table_name',
'                  FROM user_constraints',
'                 WHERE constraint_type = ''R'')',
'    LOOP',
'        EXECUTE IMMEDIATE ''ALTER TABLE '' || reg.table_name || '' DROP CONSTRAINT '' || reg.constraint_name;',
'    END LOOP;',
'',
'    FOR reg IN (SELECT object_name',
'                     , DECODE(object_type, ''PACKAGE BODY'', ''PACKAGE'', object_type) object_type',
'                  FROM user_objects',
'                 WHERE object_type in (''TABLE''))',
'    LOOP',
'        EXECUTE IMMEDIATE ''DROP '' || reg.object_type || '' '' || reg.object_name;',
'    END LOOP;    ',
'END;',
''))
,p_required_free_kb=>300
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE SYNONYM:CREATE TABLE:CREATE TRIGGER:CREATE TYPE :CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
