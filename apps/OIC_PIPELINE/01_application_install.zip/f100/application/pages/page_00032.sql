prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Environment Lookups Diff Report'
,p_alias=>'ENVIRONMENT-LOOKUPS-DIFF-REPORT'
,p_step_title=>'Environment Lookups Diff Report'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'span.com-wrap {',
'width:40px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220624212356'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173434614434433301)
,p_plug_name=>'Environment Diff Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001',
'     , c002',
'     , c003',
'     , c004',
'     , c005',
'FROM apex_collections',
'WHERE collection_name = ''LOOKUPS_COMPARE''',
'AND (c001 NOT IN (:P32_ONLY_DIFF) OR :P32_ONLY_DIFF = ''NULL'' OR c001 IS NULL)',
'ORDER BY 5, 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P32_FIRST_ENV,P32_NEXT_ENV,P32_ONLY_DIFF'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Environment Diff Report'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(173434694062433301)
,p_name=>'Environment Diff Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>173434694062433301
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24485092201406402)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'W'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24485108470406403)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'X'
,p_column_label=>'Key Column'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24485261850406404)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'Y'
,p_column_label=>'Value(s) - &P32_ENV1_NAME.'
,p_column_html_expression=>'<span style="display:inline-block;width:600px;word-break:break-all;">#C003#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24485307258406405)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'Z'
,p_column_label=>'Value(s) - &P32_ENV2_NAME.'
,p_column_html_expression=>'<span style="display:inline-block;width:600px;word-break:break-all;">#C004#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24485407681406406)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'AA'
,p_column_label=>'Lookup'
,p_column_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::P42_PROJ_ID_1,P42_PROJ_ID_2,P42_LKP_ID,P42_ENV1_NAME,P42_ENV2_NAME:&P32_FIRST_ENV.,&P32_NEXT_ENV.,#C005#,&P32_ENV1_NAME.,&P32_ENV2_NAME.'
,p_column_linktext=>'#C005#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(173442231325435590)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125664'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'C001:C002:C003:C004:C005'
,p_break_on=>'C005:0:0:0:0:0'
,p_break_enabled_on=>'C005:0:0:0:0:0'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11868495645828344)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11868815012828345)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11869236250828350)
,p_name=>'P32_FIRST_ENV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_prompt=>'Environment 1'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT project, id FROM oic_pip_projects order by 2'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11869684233828353)
,p_name=>'P32_NEXT_ENV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_prompt=>'Environment 2'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT project, id FROM oic_pip_projects WHERE id <> :P32_FIRST_ENV order by 2'
,p_lov_cascade_parent_items=>'P32_FIRST_ENV'
,p_ajax_items_to_submit=>'P32_NEXT_ENV'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24485738580406409)
,p_name=>'P32_ONLY_DIFF'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_prompt=>'Only Differences'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Identical Record'
,p_attribute_04=>'NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24486119063406413)
,p_name=>'P32_ENV1_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_source=>'oic_pip_pkg_utils.fnc_get_project_name(:P32_FIRST_ENV)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24486281393406414)
,p_name=>'P32_ENV2_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(173434614434433301)
,p_source=>'oic_pip_pkg_utils.fnc_get_project_name(:P32_NEXT_ENV)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11870042061828366)
,p_name=>'Apply'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11868815012828345)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24484969852406401)
,p_event_id=>wwv_flow_imp.id(11870042061828366)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    apex_collection.create_or_truncate_collection(''LOOKUPS_COMPARE'');',
'    ',
'    FOR reg IN (SELECT DISTINCT env1.id',
'                FROM oic_pip_lookup_header env1',
'                   , oic_pip_lookup_header env2',
'                WHERE env1.id = env2.id',
'                  AND env1.project_id = :P32_FIRST_ENV',
'                  AND env2.project_id = :P32_NEXT_ENV)',
'    LOOP',
'        oic_pip_prc_compare_lookup(:P32_FIRST_ENV, :P32_NEXT_ENV, reg.id, 1);',
'    END LOOP;',
'    ',
'',
'    FOR reg IN (SELECT DISTINCT env1.id',
'                FROM oic_pip_lookup_header env1',
'                WHERE env1.project_id = :P32_FIRST_ENV',
'                MINUS',
'                SELECT DISTINCT env2.id',
'                FROM oic_pip_lookup_header env2',
'                WHERE env2.project_id = :P32_NEXT_ENV)',
'    LOOP',
'        apex_collection.add_member(p_collection_name => ''LOOKUPS_COMPARE'', p_c005 => reg.id || '' NOT EXIST IN '' ||',
'                                                                                     oic_pip_pkg_utils.fnc_get_project_name(:P32_NEXT_ENV));',
'    END LOOP;',
'    ',
'    FOR reg IN (SELECT DISTINCT env2.id',
'                FROM oic_pip_lookup_header env2',
'                WHERE env2.project_id = :P32_NEXT_ENV',
'                MINUS',
'                SELECT DISTINCT env1.id',
'                FROM oic_pip_lookup_header env1',
'                WHERE env1.project_id = :P32_FIRST_ENV )',
'    LOOP',
'        apex_collection.add_member(p_collection_name => ''LOOKUPS_COMPARE'', p_c005 => reg.id || '' NOT EXIST IN '' ||',
'                                                                                     oic_pip_pkg_utils.fnc_get_project_name(:P32_FIRST_ENV));',
'    END LOOP;',
'END;'))
,p_attribute_02=>'P32_FIRST_ENV,P32_NEXT_ENV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24486302296406415)
,p_event_id=>wwv_flow_imp.id(11870042061828366)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P32_ONLY_DIFF,P32_ENV1_NAME,P32_ENV2_NAME'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24486497085406416)
,p_event_id=>wwv_flow_imp.id(11870042061828366)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P32_ONLY_DIFF,P32_ENV1_NAME,P32_ENV2_NAME'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P32_ENV2_NAME := oic_pip_pkg_utils.fnc_get_project_name(:P32_NEXT_ENV);',
'    :P32_ENV1_NAME := oic_pip_pkg_utils.fnc_get_project_name(:P32_FIRST_ENV);',
'END;'))
,p_attribute_07=>'P32_ONLY_DIFF,P32_ENV1_NAME,P32_ENV2_NAME'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11870502550828368)
,p_event_id=>wwv_flow_imp.id(11870042061828366)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(173434614434433301)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24485962109406411)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P32_ONLY_DIFF'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24485842908406410)
,p_event_id=>wwv_flow_imp.id(24485962109406411)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(173434614434433301)
);
wwv_flow_imp.component_end;
end;
/
