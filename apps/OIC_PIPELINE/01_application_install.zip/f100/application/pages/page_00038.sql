prompt --application/pages/page_00038
begin
--   Manifest
--     PAGE: 00038
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>38
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Lookup Promotion'
,p_alias=>'LOOKUP-PROMOTION'
,p_page_mode=>'MODAL'
,p_step_title=>'Lookup Promotion'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220705193645'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18334735666528592)
,p_plug_name=>'&P38_SOURCE_ENV. - &P38_LKP_ID.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7858059763825170)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_button_name=>'Promote'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Promote'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7833152389954802)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_button_name=>'Lookup_Content'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Lookup Content'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::P40_HEADER_LKP_ID:&P38_LOOKUP_HEADER_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7833215572954803)
,p_name=>'P38_LOOKUP_HEADER_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7858469345825176)
,p_name=>'P38_LKP_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_prompt=>'Lookup Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7858829090825178)
,p_name=>'P38_PROJECT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7859216491825179)
,p_name=>'P38_ERROR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7859698304825179)
,p_name=>'P38_SOURCE_ENV'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_prompt=>'Source Environment'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7860022117825180)
,p_name=>'P38_TARGET_ENV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_item_default=>'oic_pip_pkg_utils.fnc_get_next_project_id(:P38_PROJECT_ID)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Target Environment'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT project, id',
'FROM oic_pip_projects',
'WHERE status NOT IN (''CLOSED'')',
'  AND id <> :P38_PROJECT_ID',
'ORDER BY pipeline_order ASC'))
,p_cSize=>70
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7860472903825181)
,p_name=>'P38_LOOKUP_DESC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_prompt=>'Lookup Desc'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7860802564825181)
,p_name=>'P38_STATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7861271974825182)
,p_name=>'P38_ROWCOUNT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(18334735666528592)
,p_prompt=>'Rows'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7862542460825191)
,p_computation_sequence=>10
,p_computation_item=>'P38_SOURCE_ENV'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT project FROM oic_pip_projects WHERE id = :P38_PROJECT_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7862924775825191)
,p_computation_sequence=>30
,p_computation_item=>'P38_LOOKUP_DESC'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT description',
'FROM oic_pip_lookup_header',
'WHERE id = :P38_LKP_ID',
'  AND project_id = :P38_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7863349769825192)
,p_computation_sequence=>40
,p_computation_item=>'P38_ROWCOUNT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT rowcount',
'FROM oic_pip_lookup_header',
'WHERE id = :P38_LKP_ID',
'  AND project_id = :P38_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7864522689825193)
,p_computation_sequence=>70
,p_computation_item=>'P38_STATUS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT status',
'FROM oic_pip_lookup_header',
'WHERE id = :P38_LKP_ID',
'  AND project_id = :P38_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7864802377825194)
,p_name=>'Promote'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7858059763825170)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7866828024825198)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7866344344825197)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_in_execution BOOLEAN;',
'    l_dummy        NUMBER;',
'    l_erro         oic_pip_pkg_int_interface.INTERFACE_ERROR;',
'',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_lkp_downloads'';',
'',
'BEGIN',
'    :P38_ERROR := NULL;',
'',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'',
'    IF l_in_execution THEN',
'        :P38_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'        oic_pip_pkg_int_interface.prc_promote_lkp(:P38_PROJECT_ID, :P38_TARGET_ENV, :P38_LKP_ID, l_erro);',
'        IF l_erro.code IS NOT NULL THEN',
'            :P38_ERROR := ''Lookup: '' || :P38_LKP_ID || '' - '' || l_erro.detail || '' - '' || l_erro.code;',
'        END IF;',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN :P38_ERROR := SQLERRM;',
'END;'))
,p_attribute_02=>'P38_LKP_ID,P38_PROJECT_ID,P38_TARGET_ENV'
,p_attribute_03=>'P38_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7865359998825196)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7867318953825198)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P38_ERROR.'
,p_attribute_02=>'Promote Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P38_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7865836765825196)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Lookup &P38_ERROR. promoted.'
,p_attribute_02=>'Promote Finished'
,p_attribute_03=>'success'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P38_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7867863466825199)
,p_event_id=>wwv_flow_imp.id(7864802377825194)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
