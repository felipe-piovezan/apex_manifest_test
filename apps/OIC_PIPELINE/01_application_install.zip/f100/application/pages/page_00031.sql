prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>31
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Table Size'
,p_alias=>'TABLE-SIZE'
,p_page_mode=>'MODAL'
,p_step_title=>'Table Size'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220705121158'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10469824561424988)
,p_plug_name=>'Table Size'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.table_name',
'     , round(sum(a.bytes + nvl(b.bytes,0) + nvl(c.bytes,0))/1024/1024,2) MB',
'FROM ( SELECT SUM(s.bytes) bytes',
'            , s.segment_name table_name',
'       FROM user_segments s',
'       WHERE s.segment_type = ''TABLE''',
'       GROUP BY segment_name',
'     ) a',
'   , ( SELECT SUM(s.bytes) bytes',
'            , l.table_name',
'       FROM user_segments s',
'          , user_lobs     l',
'       WHERE l.segment_name = s.segment_name',
'       GROUP BY l.table_name',
'     ) b',
'   , ( SELECT SUM(s.bytes) bytes',
'            , i.table_name',
'       FROM user_segments s',
'          , user_indexes  i',
'       WHERE i.index_type = ''LOB''',
'         AND i.index_name = s.segment_name',
'       GROUP BY i.table_name',
'     ) c',
'WHERE a.table_name = b.table_name (+)',
'  AND a.table_name = c.table_name (+)',
'GROUP BY a.table_name',
'ORDER BY 2 DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Table Size'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10469922690424988)
,p_name=>'Table Size'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'OIC_PIP_DEV'
,p_internal_uid=>10469922690424988
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10470764813424991)
,p_db_column_name=>'TABLE_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Table Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10473522845703401)
,p_db_column_name=>'MB'
,p_display_order=>12
,p_column_identifier=>'C'
,p_column_label=>'Size in MB'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10471301964426238)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104714'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABLE_NAME:MB:'
,p_sum_columns_on_break=>'SIZE_MB:MB'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10473665270703402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10469824561424988)
,p_button_name=>'Truncate'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Truncate temp blob tables'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This will truncate temporary blob tables and reset any data and LOB indexes for theses tables.',
'<br> ',
'There is no impact on this action.',
'<br>',
'Affected tables: OIC_PIP_INT_IN_TIME_BLOB, OIC_PIP_BLOB_FILES.'))
,p_confirm_style=>'information'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10473762267703403)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10473665270703402)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10473950211703405)
,p_event_id=>wwv_flow_imp.id(10473762267703403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE oic_pip_int_in_time_blob'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE oic_pip_blob_files'';',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10473863265703404)
,p_event_id=>wwv_flow_imp.id(10473762267703403)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10469824561424988)
);
wwv_flow_imp.component_end;
end;
/
