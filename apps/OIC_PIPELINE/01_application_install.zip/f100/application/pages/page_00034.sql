prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>34
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'2. Install - Remote Configuration'
,p_alias=>'2-INSTALL-REMOTE-CONFIGURATION'
,p_step_title=>'2. Install - Remote Configuration'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220606195440'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142589900328170584)
,p_plug_name=>'2. Install - Remote Configuration'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(184032613546094824)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(142585931375170577)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184081847704094857)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'<center><h1><b>OIC Pipeline Install</b></h1></center>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142589979999170584)
,p_plug_name=>'2. Install - Remote Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(142589900328170584)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(183993785181094800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Ready to install.</p>',
'<p>Click "Install" to continue.</p>',
'<p>After the progress bar is completed, click "Next" to continue.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(142591972439170586)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(142589900328170584)
,p_button_name=>'INSTALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Install'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20294201052813790)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(142589900328170584)
,p_button_name=>'Next'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(142591875532170586)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(142589900328170584)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184083948638094859)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(142593356008170588)
,p_branch_name=>'Go To Page 35'
,p_branch_action=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(20294201052813790)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(142592667288170587)
,p_branch_name=>'Go To Page 33'
,p_branch_action=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::P33_BITBUCKET_PASS:&P34_BITBUCKET_PASS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(142591875532170586)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20294443386813793)
,p_name=>'P34_PROGRESS_BAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(142589979999170584)
,p_item_default=>'0'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#4c6478'
,p_attribute_05=>'#eee'
,p_attribute_07=>'ease-in'
,p_attribute_08=>'20000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'queue-animations'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142606473849357836)
,p_name=>'P34_INSTALL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(142589900328170584)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20294308506813791)
,p_name=>'Load'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20294330333813792)
,p_event_id=>wwv_flow_imp.id(20294308506813791)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(20294201052813790)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20294806390813796)
,p_name=>'Click_Install'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(142591972439170586)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20295481904813803)
,p_event_id=>wwv_flow_imp.id(20294806390813796)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20294925192813798)
,p_event_id=>wwv_flow_imp.id(20294806390813796)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'70'
,p_attribute_09=>'N'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20295522420813804)
,p_event_id=>wwv_flow_imp.id(20294806390813796)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(142591972439170586)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142656105641812854)
,p_event_id=>wwv_flow_imp.id(20294806390813796)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR cur_conf IS',
'        -- cur_conf',
'        SELECT provider',
'             , repo_name',
'             , owner',
'             , install_file_path',
'             , current_remote_version_file_path',
'             , dev_application',
'        FROM oic_pip_remote_update_conf ;',
'    vr_conf CUR_CONF%ROWTYPE;',
'',
'BEGIN',
'    OPEN cur_conf;',
'    FETCH cur_conf INTO vr_conf;',
'    CLOSE cur_conf;',
'',
'    oic_pip_prc_app_install(NULL, vr_conf, ''INSTALL'');',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296010898813808)
,p_event_id=>wwv_flow_imp.id(20294806390813796)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'100'
,p_attribute_09=>'Y'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20295153749813800)
,p_name=>'Load_resource'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20295352257813802)
,p_event_id=>wwv_flow_imp.id(20295153749813800)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P34_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20295716166813805)
,p_name=>'PROGRESS_BAR_COMPLETE'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P34_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20295856729813807)
,p_event_id=>wwv_flow_imp.id(20295716166813805)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_03=>'Done!'
,p_attribute_07=>'prevent-duplicates:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20295763766813806)
,p_event_id=>wwv_flow_imp.id(20295716166813805)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(20294201052813790)
);
wwv_flow_imp.component_end;
end;
/
