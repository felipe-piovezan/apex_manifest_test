prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Manage Integrations Status'
,p_alias=>'MANAGE-INTEGRATIONS-STATUS'
,p_step_title=>'Manage Integrations Status'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220823222739'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206391515106000418)
,p_plug_name=>'Ints'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM ( SELECT a.name',
'            , a.version',
'            , b.task_name',
'            , a.status',
'            , a.pattern',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'       WHERE a.project_id = b.id',
'         AND :P23_PROJECT_ID = b.id',
'         AND a.status = DECODE( :P23_ACTION',
'                              , ''ACTIVATED'', ''CONFIGURED''',
'                              , ''CONFIGURED'', ''ACTIVATED''',
'                              )',
'       ORDER BY a.name',
'              , a.version DESC',
'              , a.pattern',
'     )'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P23_ACTION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Ints'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(150357004011183539)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>400
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(150357092113183540)
,p_name=>'VERSION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERSION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(150357254915183541)
,p_name=>'TASK_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(150357271782183542)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(173369035889309159)
,p_name=>'PATTERN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Pattern'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(173369652385309165)
,p_name=>'row_selector'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(173368433632309153)
,p_internal_uid=>33367971856822236
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(173388765012363766)
,p_interactive_grid_id=>wwv_flow_imp.id(173368433632309153)
,p_static_id=>'126206'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(173388975968363766)
,p_report_id=>wwv_flow_imp.id(173388765012363766)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(151772377212570243)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(150357004011183539)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(151773271525570249)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(150357092113183540)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(151774164654570253)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(150357254915183541)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(151775102110570255)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(150357271782183542)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(173393927060363796)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(173369035889309159)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(173412925521394168)
,p_view_id=>wwv_flow_imp.id(173388975968363766)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(173369652385309165)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206560755935979384)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151760710103443601)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(206560755935979384)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_PROJECT_ID:&P23_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151761078480443604)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(206560755935979384)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10999377215777522)
,p_name=>'P23_ERROR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46608195991895704)
,p_name=>'P23_PROGRESS_BAR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_source=>'oic_pip_pkg_progress.fnc_get(apex_custom_auth.get_session_id, :APP_PAGE_ID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''35px'';',
'}'))
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#0063ce'
,p_attribute_05=>'#a6d1ff'
,p_attribute_07=>'linear'
,p_attribute_08=>'5000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'add-timer'
,p_attribute_12=>'4000'
,p_attribute_13=>'progress-is-complete'
,p_attribute_15=>'P23_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151758369184443595)
,p_name=>'P23_ENV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_prompt=>'Source Environment'
,p_source=>'SELECT project FROM oic_pip_projects WHERE id = :P23_PROJECT_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151759172965443597)
,p_name=>'P23_ACTION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_item_default=>'null'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Action'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:DEACTIVATE;CONFIGURED,ACTIVATE;ACTIVATED'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-'
,p_lov_null_value=>'NULL'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151759580890443598)
,p_name=>'P23_IDS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151760039950443598)
,p_name=>'P23_PROJECT_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(206391515106000418)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(151761795307443611)
,p_name=>'DiagClose'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(206391515106000418)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151762329881443614)
,p_event_id=>wwv_flow_imp.id(151761795307443611)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROJECT_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P23_PROJECT_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151762849238443615)
,p_event_id=>wwv_flow_imp.id(151761795307443611)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(206391515106000418)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(151763191467443616)
,p_name=>'Refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P23_ALL_VERSIONS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151763747733443616)
,p_event_id=>wwv_flow_imp.id(151763191467443616)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(206391515106000418)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(151764149222443617)
,p_name=>'catchIDs'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(206391515106000418)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151764588596443617)
,p_event_id=>wwv_flow_imp.id(151764149222443617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i_ids = ":", i_ids,',
'',
'model = this.data.model;',
'',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    ',
'    i_ids += model.getValue( this.data.selectedRecords[i], "NAME") ',
'           + "|"',
'           + model.getValue( this.data.selectedRecords[i], "VERSION")',
'           + ":";',
'    ',
'}',
'',
'apex.item( "P23_IDS" ).setValue (i_ids);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151765072165443618)
,p_event_id=>wwv_flow_imp.id(151764149222443617)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_IDS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150356818521183537)
,p_name=>'Refresh_on_Change'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P23_ACTION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150356950079183538)
,p_event_id=>wwv_flow_imp.id(150356818521183537)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(206391515106000418)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46608414002898160)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P23_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46610332163898169)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(apex_custom_auth.get_session_id, 23);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46609783545898169)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46610830991898170)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46608766661898167)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(151761078480443604)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46611314039898170)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_ACTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10999423666777523)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P23_ERROR.'
,p_attribute_02=>'Action Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P23_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46609307852898168)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(206391515106000418)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46649066898492822)
,p_event_id=>wwv_flow_imp.id(46608414002898160)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_04=>'Process completed successfully'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P23_ERROR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46611705464899812)
,p_name=>'SubimitProcess'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(151761078480443604)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46613090618899815)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P23_PROGRESS_BAR'');',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46612660682899814)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(151761078480443604)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46614096917899816)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_ACTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46613605869899815)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151766561565443620)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sq1          NUMBER;',
'    l_count        NUMBER := 0;',
'    l_max          NUMBER := 0;',
'    l_in_execution BOOLEAN;',
'    l_dummy        NUMBER;',
'    l_erro         oic_pip_pkg_int_interface.INTERFACE_ERROR;',
'',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_int_downloads'';',
'',
'    -- cur_count',
'    CURSOR cur_count IS',
'        SELECT COUNT(1) AS int_id',
'        FROM TABLE (apex_string.split(RTRIM(LTRIM(:P23_IDS, '':''), '':''), '':'')) t;',
'',
'BEGIN',
'',
'    :P23_ERROR := '''';',
'',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'',
'    IF l_in_execution THEN',
'        :P23_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'',
'        OPEN cur_count;',
'        FETCH cur_count INTO l_max;',
'        CLOSE cur_count;',
'',
'        IF l_max = 0 THEN',
'            l_max := 1;',
'        END IF;',
'',
'        oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 5);',
'',
'        FOR reg IN ( SELECT int.id',
'                          , ( SELECT proj.task_name',
'                              FROM oic_pip_projects proj',
'                              WHERE proj.id = int.project_id',
'                            ) task',
'                     FROM oic_pip_ints_downloaded int',
'                     WHERE name || ''|'' || version IN ( SELECT t.column_value AS int_id',
'                                                       FROM TABLE (apex_string.split(RTRIM(LTRIM(:P23_IDS, '':''), '':''), '':'')) t',
'                                                     )',
'                       AND int.project_id = :P23_PROJECT_ID)',
'        LOOP',
'            l_sq1 := oic_pip_fnc_create_log(''STATUS CHANGE - oic_pip_pkg_int_interface.prc_update_int_status'',',
'                                            ''RUNNING'');',
'            oic_pip_pkg_int_interface.prc_update_int_status(reg.id, :P23_ACTION, reg.task, NULL, l_erro);',
'            IF l_erro.code IS NOT NULL THEN',
'                :P23_ERROR := :P23_ERROR || reg.id || '' - '' || l_erro.detail || '' - '' || l_erro.code || ''; '';',
'                oic_pip_prc_create_log_err(l_sq1,',
'                                                ''oic_pip_pkg_int_interface.prc_update_int_status call - error - '' || l_erro.detail || '' - '' || l_erro.code);',
'                l_sq1 := oic_pip_fnc_create_log(''STATUS CHANGE - oic_pip_pkg_int_interface.prc_update_int_status'', ''ERROR'', l_sq1,',
'                                                SYSDATE);',
'                l_erro.code := NULL;',
'                l_erro.detail := NULL;',
'            ELSE',
'                l_sq1 := oic_pip_fnc_create_log(''STATUS CHANGE - oic_pip_pkg_int_interface.prc_update_int_status'',',
'                                            ''COMPLETED'', l_sq1, SYSDATE);',
'            END IF;',
'',
'            l_count := l_count + 1;',
'            oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID,',
'                                         CEIL(l_count / l_max * 100) - 2);',
'        END LOOP;',
'',
'        dbms_session.sleep(0.3);',
'        oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN oic_pip_prc_create_log_err(l_sq1,',
'                                                ''oic_pip_pkg_int_interface.prc_update_int_status call - error - '' ||',
'                                                SQLERRM);',
'    l_sq1 := oic_pip_fnc_create_log(''STATUS CHANGE - oic_pip_pkg_int_interface.prc_update_int_status'', ''ERROR'', l_sq1,',
'                                    SYSDATE);',
'    oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'    :P23_ERROR := :P23_ERROR || SQLERRM;',
'END;'))
,p_attribute_02=>'P23_IDS,P23_ACTION,P23_ERROR'
,p_attribute_03=>'P23_ERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44149534367089171)
,p_event_id=>wwv_flow_imp.id(46611705464899812)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'info'
,p_attribute_02=>'static'
,p_attribute_04=>'Process started'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_attribute_13=>'warning'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46614498122901393)
,p_name=>'INIT_PROGRESS_BAR'
,p_event_sequence=>80
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46615397585901394)
,p_event_id=>wwv_flow_imp.id(46614498122901393)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46614916178901394)
,p_event_id=>wwv_flow_imp.id(46614498122901393)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P23_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
