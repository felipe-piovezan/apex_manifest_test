prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Package Promotion'
,p_alias=>'PACKAGE-PROMOTION'
,p_page_mode=>'MODAL'
,p_step_title=>'Package Promotion'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220531115906'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10477303880703439)
,p_plug_name=>'&P30_SOURCE_ENV. - &P30_PACKAGE_NAME.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10896530477639907)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_button_name=>'Promote'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Promote'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10477409756703440)
,p_name=>'P30_SOURCE_ENV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Source Environment'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10477585500703441)
,p_name=>'P30_TARGET_ENV'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_item_default=>'oic_pip_pkg_utils.fnc_get_next_project_id(:P30_PROJECT_ID)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Target Environment'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT project, id',
'FROM oic_pip_projects',
'WHERE status NOT IN (''CLOSED'')',
'  AND id <> :P30_PROJECT_ID',
'ORDER BY pipeline_order ASC'))
,p_cSize=>70
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10477629083703442)
,p_name=>'P30_PACKAGE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10477758079703443)
,p_name=>'P30_PROJECT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10478104774703447)
,p_name=>'P30_PACKAGE_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Package Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10478333705703449)
,p_name=>'P30_COUNTOFINTEGRATIONS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Integrations Count'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10895973809639901)
,p_name=>'P30_ISCLONEALLOWED'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Is Clone Allowed'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10896182358639903)
,p_name=>'P30_ISVIEWALLOWED'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Is View Allowed'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10896349652639905)
,p_name=>'P30_TYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_prompt=>'Type'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10897223913639914)
,p_name=>'P30_ERROR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10477303880703439)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10477823028703444)
,p_computation_sequence=>10
,p_computation_item=>'P30_SOURCE_ENV'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT project FROM oic_pip_projects WHERE id = :P30_PROJECT_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10478225409703448)
,p_computation_sequence=>30
,p_computation_item=>'P30_PACKAGE_NAME'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT name FROM oic_pip_pkgs_downloaded WHERE id = :P30_PACKAGE_ID AND project_id = :P30_PROJECT_ID',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10478467696703450)
,p_computation_sequence=>40
,p_computation_item=>'P30_COUNTOFINTEGRATIONS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT countofintegrations FROM oic_pip_pkgs_downloaded WHERE id = :P30_PACKAGE_ID AND project_id = :P30_PROJECT_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10896085341639902)
,p_computation_sequence=>50
,p_computation_item=>'P30_ISCLONEALLOWED'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT iscloneallowed FROM oic_pip_pkgs_downloaded WHERE id = :P30_PACKAGE_ID AND project_id = :P30_PROJECT_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10896212876639904)
,p_computation_sequence=>60
,p_computation_item=>'P30_ISVIEWALLOWED'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT isviewallowed FROM oic_pip_pkgs_downloaded WHERE id = :P30_PACKAGE_ID AND project_id = :P30_PROJECT_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10896494155639906)
,p_computation_sequence=>70
,p_computation_item=>'P30_TYPE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT type FROM oic_pip_pkgs_downloaded WHERE id = :P30_PACKAGE_ID AND project_id = :P30_PROJECT_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10896608466639908)
,p_name=>'Promote'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10896530477639907)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10896806360639910)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10896729211639909)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_in_execution BOOLEAN;',
'    l_dummy        NUMBER;',
'    l_erro         oic_pip_pkg_int_interface.INTERFACE_ERROR;',
'    ',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_pkg_downloads'';',
'',
'BEGIN',
'    :P30_ERROR := NULL;',
'    ',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'    ',
'    IF l_in_execution THEN',
'        :P30_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'        oic_pip_pkg_int_interface.prc_promote_pkg(:P30_PROJECT_ID, :P30_TARGET_ENV, :P30_PACKAGE_ID, l_erro);',
'        IF l_erro.code IS NOT NULL THEN',
'            :P30_ERROR := ''Package: '' ||:P30_PACKAGE_ID || '' - '' || l_erro.detail || '' - '' || l_erro.code;',
'        END IF;',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN :P30_ERROR := SQLERRM;',
'END;'))
,p_attribute_02=>'P30_PACKAGE_ID,P30_PROJECT_ID,P30_TARGET_ENV'
,p_attribute_03=>'P30_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10896952389639911)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10897349205639915)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P30_ERROR.'
,p_attribute_02=>'Promote Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P30_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10997244208777501)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Package &P30_ERROR. promoted.'
,p_attribute_02=>'Promote Finished'
,p_attribute_03=>'success'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P30_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10897093543639912)
,p_event_id=>wwv_flow_imp.id(10896608466639908)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
