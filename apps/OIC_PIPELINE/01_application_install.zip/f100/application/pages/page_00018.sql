prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Environment Diff Report'
,p_alias=>'ENVIRONMENT-DIFF-REPORT'
,p_step_title=>'Environment Diff Report'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220215142455'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161574134360605006)
,p_plug_name=>'Environment Diff Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH header AS ( SELECT current_proj.project || '' | '' || current_proj.version environment_version',
'                      , next_proj.project || '' | '' || next_proj.version       next_environment_version',
'                      , current_proj.name                                     integration_name',
'                      , current_proj.version                                  cur_version',
'                      , next_proj.version                                     next_version',
'                      , current_proj.project                                  cur_proj',
'                      , next_proj.project                                     next_proj',
'                 FROM ( SELECT a.name',
'                             , MAX(a.version) version',
'                             , b.pipeline_order',
'                             , b.project',
'                        FROM oic_pip_ints_downloaded a',
'                           , oic_pip_projects        b',
'                        WHERE a.project_id = b.id',
'                        GROUP BY a.name',
'                               , b.pipeline_order',
'                               , b.project',
'                      ) current_proj',
'                    , ( SELECT a.name',
'                             , MAX(a.version) version',
'                             , b.pipeline_order',
'                             , b.project',
'                        FROM oic_pip_ints_downloaded a',
'                           , oic_pip_projects        b',
'                        WHERE a.project_id = b.id',
'                        GROUP BY a.name',
'                               , b.pipeline_order',
'                               , b.project',
'                      ) next_proj',
'                 WHERE current_proj.pipeline_order = :P18_FIRST_ENV',
'                   AND next_proj.pipeline_order = :P18_NEXT_ENV',
'                   AND current_proj.name = next_proj.name',
'                  AND ((TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'                        TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 4, 2)) AND',
'                        TO_NUMBER(SUBSTR(current_proj.version, 7, 4)) < TO_NUMBER(SUBSTR(next_proj.version, 7, 4)))',
'                      OR',
'                       (TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'                        TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 4, 2)))',
'                      OR',
'                       TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 1, 2))',
'                      )',
'                 UNION ALL',
'                 SELECT current_proj.project || '' | '' || current_proj.version environment_version',
'                      , next_proj.project || '' | '' || next_proj.version       next_environment_version',
'                      , next_proj.name                                        integration_name',
'                      , current_proj.version                                  cur_version',
'                      , next_proj.version                                     next_version',
'                      , current_proj.project                                  cur_proj',
'                      , next_proj.project                                     next_proj',
'                 FROM ( SELECT '' - '' name',
'                             , '' - '' version',
'                             , b.pipeline_order',
'                             , b.project',
'                             , b.id  project_id',
'                        FROM oic_pip_projects b',
'                        GROUP BY b.pipeline_order',
'                               , b.project',
'                               , b.id',
'                      ) current_proj',
'                    , ( SELECT a.name',
'                             , MAX(a.version) version',
'                             , b.pipeline_order',
'                             , b.project',
'                             , b.id           project_id',
'                        FROM oic_pip_ints_downloaded a',
'                           , oic_pip_projects        b',
'                        WHERE a.project_id = b.id',
'                        GROUP BY a.name',
'                               , b.pipeline_order',
'                               , b.project',
'                               , b.id',
'                      ) next_proj',
'                 WHERE current_proj.pipeline_order = :P18_FIRST_ENV',
'                   AND next_proj.pipeline_order = :P18_NEXT_ENV',
'                   AND NOT EXISTS(SELECT NULL',
'                                  FROM oic_pip_ints_downloaded aux',
'                                  WHERE aux.project_id = current_proj.project_id AND aux.name = next_proj.name)',
'               )',
'SELECT header.*',
'     , source.*',
'     , NVL(target.p_env_target, target_null.p_env_target)                 p_env_target',
'     , NVL(target.p_int_target, target_null.p_int_target)                 p_int_target',
'     , NVL(target.p_int_target_status, target_null.p_int_target_status)   p_int_target_status',
'     , NVL(target.p_int_target_version, target_null.p_int_target_version) p_int_target_version',
'     , NVL(target.p_int_task_to, target_null.p_int_task_to)               p_int_task_to',
'FROM ( SELECT prj.project   p_env_source',
'            , int.name      p_int_source',
'            , int.status    p_int_source_status',
'            , int.version   p_int_source_version',
'            , int.pattern   p_int_pattern',
'            , prj.task_name p_int_task_from',
'       FROM oic_pip_ints_downloaded int',
'          , oic_pip_projects        prj',
'       WHERE int.project_id = prj.id',
'     ) source',
'   , ( SELECT prj.project   p_env_target',
'            , int.name      p_int_target',
'            , int.status    p_int_target_status',
'            , int.version   p_int_target_version',
'            , prj.task_name p_int_task_to',
'       FROM oic_pip_ints_downloaded int',
'          , oic_pip_projects        prj',
'       WHERE int.project_id = prj.id',
'     ) target',
'   , ( SELECT prj.project   p_env_target',
'            , NULL          p_int_target',
'            , NULL          p_int_target_status',
'            , NULL          p_int_target_version',
'            , prj.task_name p_int_task_to',
'       FROM oic_pip_projects prj',
'     ) target_null',
'   ,   header',
'WHERE source.p_int_source_version = header.next_version',
'  AND source.p_env_source = header.next_proj',
'  AND source.p_int_source = header.integration_name',
'  AND target.p_int_target_version(+) = header.cur_version',
'  AND target.p_env_target(+) = header.cur_proj',
'  AND target.p_int_target(+) = header.integration_name',
'  AND target_null.p_env_target = header.cur_proj',
'  AND :P18_FIRST_ENV IS NOT NULL',
'  AND :P18_NEXT_ENV IS NOT NULL',
'',
'UNION ALL',
'',
'SELECT *',
'FROM ( WITH header AS ( SELECT current_proj.project || '' | '' || current_proj.version environment_version',
'                             , next_proj.project || '' | '' || next_proj.version       next_environment_version',
'                             , current_proj.name                                     integration_name',
'                             , current_proj.version                                  cur_version',
'                             , next_proj.version                                     next_version',
'                             , current_proj.project                                  cur_proj',
'                             , next_proj.project                                     next_proj',
'                        FROM ( SELECT a.name',
'                                    , MAX(a.version) version',
'                                    , b.pipeline_order',
'                                    , b.project',
'                               FROM oic_pip_ints_downloaded a',
'                                  , oic_pip_projects        b',
'                               WHERE a.project_id = b.id',
'                               GROUP BY a.name',
'                                      , b.pipeline_order',
'                                      , b.project',
'                             ) current_proj',
'                           , ( SELECT a.name',
'                                    , MAX(a.version) version',
'                                    , b.pipeline_order',
'                                    , b.project',
'                               FROM oic_pip_ints_downloaded a',
'                                  , oic_pip_projects        b',
'                               WHERE a.project_id = b.id',
'                               GROUP BY a.name',
'                                      , b.pipeline_order',
'                                      , b.project',
'                             ) next_proj',
'                        WHERE current_proj.pipeline_order = :P18_NEXT_ENV',
'                          AND next_proj.pipeline_order = :P18_FIRST_ENV',
'                          AND current_proj.name = next_proj.name',
'                          AND ((TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'                                TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 4, 2)) AND',
'                                TO_NUMBER(SUBSTR(current_proj.version, 7, 4)) < TO_NUMBER(SUBSTR(next_proj.version, 7, 4)))',
'                              OR',
'                               (TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'                                TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 4, 2)))',
'                              OR',
'                               TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 1, 2))',
'                              )',
'                        UNION ALL',
'                        SELECT current_proj.project || '' | '' || current_proj.version environment_version',
'                             , next_proj.project || '' | '' || next_proj.version       next_environment_version',
'                             , next_proj.name                                        integration_name',
'                             , current_proj.version                                  cur_version',
'                             , next_proj.version                                     next_version',
'                             , current_proj.project                                  cur_proj',
'                             , next_proj.project                                     next_proj',
'                        FROM ( SELECT '' - '' name',
'                                    , '' - '' version',
'                                    , b.pipeline_order',
'                                    , b.project',
'                                    , b.id  project_id',
'                               FROM oic_pip_projects b',
'                               GROUP BY b.pipeline_order',
'                                      , b.project',
'                                      , b.id',
'                             ) current_proj',
'                           , ( SELECT a.name',
'                                    , MAX(a.version) version',
'                                    , b.pipeline_order',
'                                    , b.project',
'                                    , b.id           project_id',
'                               FROM oic_pip_ints_downloaded a',
'                                  , oic_pip_projects        b',
'                               WHERE a.project_id = b.id',
'                               GROUP BY a.name',
'                                      , b.pipeline_order',
'                                      , b.project',
'                                      , b.id',
'                             ) next_proj',
'                        WHERE current_proj.pipeline_order = :P18_NEXT_ENV',
'                          AND next_proj.pipeline_order = :P18_FIRST_ENV',
'                          AND NOT EXISTS(SELECT NULL',
'                                         FROM oic_pip_ints_downloaded aux',
'                                         WHERE aux.project_id = current_proj.project_id AND aux.name = next_proj.name)',
'                      )',
'       SELECT header.*',
'            , source.*',
'            , NVL(target.p_env_target, target_null.p_env_target)                 p_env_target',
'            , NVL(target.p_int_target, target_null.p_int_target)                 p_int_target',
'            , NVL(target.p_int_target_status, target_null.p_int_target_status)   p_int_target_status',
'            , NVL(target.p_int_target_version, target_null.p_int_target_version) p_int_target_version',
'            , NVL(target.p_int_task_to, target_null.p_int_task_to)               p_int_task_to',
'       FROM ( SELECT prj.project   p_env_source',
'                   , int.name      p_int_source',
'                   , int.status    p_int_source_status',
'                   , int.version   p_int_source_version',
'                   , int.pattern   p_int_pattern',
'                   , prj.task_name p_int_task_from',
'              FROM oic_pip_ints_downloaded int',
'                 , oic_pip_projects        prj',
'              WHERE int.project_id = prj.id',
'            ) source',
'          , ( SELECT prj.project   p_env_target',
'                   , int.name      p_int_target',
'                   , int.status    p_int_target_status',
'                   , int.version   p_int_target_version',
'                   , prj.task_name p_int_task_to',
'              FROM oic_pip_ints_downloaded int',
'                 , oic_pip_projects        prj',
'              WHERE int.project_id = prj.id',
'            ) target',
'          , ( SELECT prj.project   p_env_target',
'                   , NULL          p_int_target',
'                   , NULL          p_int_target_status',
'                   , NULL          p_int_target_version',
'                   , prj.task_name p_int_task_to',
'              FROM oic_pip_projects prj',
'            ) target_null',
'          ,   header',
'       WHERE source.p_int_source_version = header.next_version',
'         AND source.p_env_source = header.next_proj',
'         AND source.p_int_source = header.integration_name',
'         AND target.p_int_target_version(+) = header.cur_version',
'         AND target.p_env_target(+) = header.cur_proj',
'         AND target.p_int_target(+) = header.integration_name',
'         AND target_null.p_env_target = header.cur_proj',
'         AND :P18_FIRST_ENV IS NOT NULL',
'         AND :P18_NEXT_ENV IS NOT NULL',
'     )',
'',
'ORDER BY 1 DESC',
'       , 3',
'       , 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P18_FIRST_ENV,P18_NEXT_ENV'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Environment Diff Report'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(161574213988605006)
,p_name=>'Environment Diff Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>12558774969387655
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161574638583605009)
,p_db_column_name=>'ENVIRONMENT_VERSION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Environment Version'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161575007145605010)
,p_db_column_name=>'NEXT_ENVIRONMENT_VERSION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Next Environment Version'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161575395697605011)
,p_db_column_name=>'INTEGRATION_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Integration Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161575783408605012)
,p_db_column_name=>'CUR_VERSION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Cur Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161576220254605013)
,p_db_column_name=>'NEXT_VERSION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Next Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161576560831605014)
,p_db_column_name=>'CUR_PROJ'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Cur Proj'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161576949006605016)
,p_db_column_name=>'NEXT_PROJ'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Next Proj'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161577367462605017)
,p_db_column_name=>'P_ENV_SOURCE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'P Env Source'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161577816994605018)
,p_db_column_name=>'P_INT_SOURCE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'P Int Source'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161578232680605020)
,p_db_column_name=>'P_INT_SOURCE_STATUS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'P Int Source Status'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161578603658605021)
,p_db_column_name=>'P_INT_SOURCE_VERSION'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'P Int Source Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161578972463605023)
,p_db_column_name=>'P_INT_PATTERN'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'P Int Pattern'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161579370321605025)
,p_db_column_name=>'P_INT_TASK_FROM'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'P Int Task From'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161579760226605026)
,p_db_column_name=>'P_ENV_TARGET'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'P Env Target'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161580145024605027)
,p_db_column_name=>'P_INT_TARGET'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'P Int Target'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161580619906605028)
,p_db_column_name=>'P_INT_TARGET_STATUS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'P Int Target Status'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161580962414605029)
,p_db_column_name=>'P_INT_TARGET_VERSION'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'P Int Target Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161581415226605030)
,p_db_column_name=>'P_INT_TASK_TO'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'P Int Task To'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(161581751251607295)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125664'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ENVIRONMENT_VERSION:NEXT_ENVIRONMENT_VERSION:INTEGRATION_NAME:CUR_VERSION:NEXT_VERSION:CUR_PROJ:NEXT_PROJ:P_ENV_SOURCE:P_INT_SOURCE:P_INT_SOURCE_STATUS:P_INT_SOURCE_VERSION:P_INT_PATTERN:P_INT_TASK_FROM:P_ENV_TARGET:P_INT_TARGET:P_INT_TARGET_STATUS:P'
||'_INT_TARGET_VERSION:P_INT_TASK_TO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161475166580398963)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(161574134360605006)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161475114430398962)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(161574134360605006)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161474870505398960)
,p_name=>'P18_FIRST_ENV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(161574134360605006)
,p_prompt=>'Environment 1'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT project, pipeline_order FROM oic_pip_projects order by 2'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161475001271398961)
,p_name=>'P18_NEXT_ENV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(161574134360605006)
,p_prompt=>'Environment 2'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT project, pipeline_order FROM oic_pip_projects order by 2'
,p_lov_cascade_parent_items=>'P18_FIRST_ENV'
,p_ajax_items_to_submit=>'P18_NEXT_ENV'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161475440710398966)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(161475114430398962)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161475625827398967)
,p_event_id=>wwv_flow_imp.id(161475440710398966)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(161574134360605006)
);
wwv_flow_imp.component_end;
end;
/
