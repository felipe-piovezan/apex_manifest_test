prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Sync Environment'
,p_alias=>'SYNC-ENVIRONMENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Sync Environment'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220323115107'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150358461305183553)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Synchronizing... Please wait for the window to close..'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46549278437984077)
,p_name=>'P25_PROGRESS_BAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(150358461305183553)
,p_source=>'oic_pip_pkg_progress.fnc_get(null, 25)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''25px'';',
'}'))
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#0063ce'
,p_attribute_05=>'#a6d1ff'
,p_attribute_07=>'linear'
,p_attribute_08=>'4000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'add-timer'
,p_attribute_12=>'3000'
,p_attribute_13=>'progress-is-complete'
,p_attribute_15=>'P25_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150358491031183554)
,p_name=>'P25_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(150358461305183553)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150358244560183551)
,p_name=>'Page Load'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150358336002183552)
,p_event_id=>wwv_flow_imp.id(150358244560183551)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(null, 25);',
'    oic_pip_prc_auto_int_downloads(p_project_id => :P25_PROJECT_ID, p_page_progress_bar => 25);',
'END;'))
,p_attribute_02=>'P25_PROJECT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46553026014003055)
,p_event_id=>wwv_flow_imp.id(150358244560183551)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P25_PROGRESS_BAR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P25_PROGRESS_BAR'');',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46549534224988144)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P25_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46550445113988152)
,p_event_id=>wwv_flow_imp.id(46549534224988144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(null, 25);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150358848361183557)
,p_event_id=>wwv_flow_imp.id(46549534224988144)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
