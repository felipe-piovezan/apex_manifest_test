prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Pipeline History'
,p_alias=>'PIPELINE-HISTORY'
,p_page_mode=>'MODAL'
,p_step_title=>'Pipeline History'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(183981809851094792)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220407111152'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182464019089596030)
,p_plug_name=>'Pipeline History'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OIC_PIP_VW_AUDIT'
,p_query_where=>':P7_INTEGRATION_ID = INTEGRATION_ID'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JQM_REFLOW'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_no_data_found=>'There is no history.'
,p_attribute_01=>'STRIPE:STROKE'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(182465019561596038)
,p_name=>'ACTION'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Action'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(182465508572596039)
,p_name=>'EXECUTED_BY_USER'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Executed By User'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(182466008947596040)
,p_name=>'EXECUTION_DATE'
,p_data_type=>'DATE'
,p_is_visible=>true
,p_heading=>'Execution Date'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(182529383740017037)
,p_name=>'ACTION_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Action Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_01=>'PLAIN'
,p_attribute_08=>'N'
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18588482657815324)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182464019089596030)
,p_button_name=>'RESET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Resete Pipeline Flow'
,p_button_position=>'DELETE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18809225919392180)
,p_name=>'P7_PIPELINE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182464019089596030)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(181929012574777057)
,p_name=>'P7_INTEGRATION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182464019089596030)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18808726040392175)
,p_name=>'click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(18588482657815324)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18808906473392176)
,p_event_id=>wwv_flow_imp.id(18808726040392175)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'This will reset the integration pipeline flow. If integration only exists in the first environment, you''ll be able to restart the pipeline. Do you want to continue?'
,p_attribute_04=>'fa-database-x'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18809004431392177)
,p_event_id=>wwv_flow_imp.id(18808726040392175)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE oic_pip_audit_pipeline',
'    SET pipeline_id = NULL',
'    WHERE pipeline_id = :P7_PIPELINE_ID;',
'',
'    INSERT INTO oic_pip_audit_pipeline ( id',
'                                       , action',
'                                       , executed_by_user',
'                                       , execution_date',
'                                       , pipeline_id',
'                                       , integration_id)',
'    VALUES ( oic_pip_audit_pipeline_sq1.nextval',
'           , ''Intergration '' || :P7_INTEGRATION_ID || '' had the pipeline flow reset.''',
'           , wwv_flow.g_user',
'           , SYSDATE',
'           , NULL',
'           , :P7_INTEGRATION_ID);',
'',
'    DELETE oic_pip_int_pipeline_msgs',
'    WHERE pipeline_id = :P7_PIPELINE_ID;',
'',
'    DELETE oic_pip_int_pipeline',
'    WHERE id = :P7_PIPELINE_ID;',
'',
'    COMMIT;',
'',
'END;'))
,p_attribute_02=>'P7_INTEGRATION_ID,P7_PIPELINE_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18809407703392181)
,p_event_id=>wwv_flow_imp.id(18808726040392175)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
