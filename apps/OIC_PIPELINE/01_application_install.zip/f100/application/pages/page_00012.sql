prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Inconsistencies Report'
,p_alias=>'INCONSISTENCIES-REPORT'
,p_step_title=>'Inconsistencies Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220127193310'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194529529148995170)
,p_plug_name=>'Inconsistencies'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH header AS',
'(SELECT current_proj.project||'' | ''||current_proj.version environment_version',
'     , next_proj.project ||'' | ''|| next_proj.version  next_environment_version',
'     , current_proj.name    integration_name',
'     , current_proj.version cur_version',
'     , next_proj.version next_version',
'     , current_proj.project cur_proj',
'     , next_proj.project next_proj',
'FROM ( SELECT a.name',
'            , MAX(a.version) version',
'            , b.pipeline_order',
'            , b.project',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'       WHERE a.project_id = b.id',
'         AND b.status NOT IN (''CLOSED'')',
'     GROUP BY a.name',
'            , b.pipeline_order',
'            , b.project',
'     ) current_proj',
'   , ( SELECT a.name',
'            , MAX(a.version) version',
'            , b.pipeline_order',
'            , b.project',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'       WHERE a.project_id = b.id',
'         AND b.status NOT IN (''CLOSED'')',
'     GROUP BY a.name',
'            , b.pipeline_order',
'            , b.project',
'     ) next_proj',
'WHERE current_proj.pipeline_order = next_proj.pipeline_order - 1',
'  AND current_proj.name = next_proj.name',
'  AND ((TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'        TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 4, 2)) AND',
'        TO_NUMBER(SUBSTR(current_proj.version, 7, 4)) < TO_NUMBER(SUBSTR(next_proj.version, 7, 4)))',
'      OR',
'       (TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) = TO_NUMBER(SUBSTR(next_proj.version, 1, 2)) AND',
'        TO_NUMBER(SUBSTR(current_proj.version, 4, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 4, 2)))',
'      OR',
'       TO_NUMBER(SUBSTR(current_proj.version, 1, 2)) < TO_NUMBER(SUBSTR(next_proj.version, 1, 2))',
'      )',
'UNION ALL',
'SELECT current_proj.project||'' | ''||current_proj.version environment_version',
'     , next_proj.project ||'' | ''|| next_proj.version  next_environment_version',
'     , next_proj.name    integration_name',
'     , current_proj.version cur_version',
'     , next_proj.version next_version',
'     , current_proj.project cur_proj',
'     , next_proj.project next_proj',
'FROM ( SELECT '' - '' name',
'            , '' - '' version',
'            , b.pipeline_order',
'            , b.project',
'            , b.id project_id',
'       FROM oic_pip_projects        b',
'      WHERE b.status NOT IN (''CLOSED'')',
'     GROUP BY b.pipeline_order',
'            , b.project',
'            , b.id',
'     ) current_proj',
'   , ( SELECT a.name',
'            , MAX(a.version) version',
'            , b.pipeline_order',
'            , b.project',
'            , b.id project_id',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'       WHERE a.project_id = b.id',
'         AND b.status NOT IN (''CLOSED'')',
'     GROUP BY a.name',
'            , b.pipeline_order',
'            , b.project',
'            , b.id',
'     ) next_proj',
'WHERE current_proj.pipeline_order = next_proj.pipeline_order - 1',
'  AND NOT EXISTS ( SELECT null ',
'                    FROM oic_pip_ints_downloaded aux',
'                   WHERE aux.project_id = current_proj.project_id',
'                     AND aux.name = next_proj.name',
'                  ))',
'SELECT header.*',
'     , source.*',
'     , nvl(target.p_env_target, target_null.p_env_target) p_env_target',
'     , nvl(target.p_int_target, target_null.p_int_target) p_int_target',
'     , nvl(target.p_int_target_status, target_null.p_int_target_status) p_int_target_status',
'     , nvl(target.p_int_target_version, target_null.p_int_target_version) p_int_target_version',
'     , nvl(target.p_int_task_to, target_null.p_int_task_to) p_int_task_to',
'FROM ( SELECT prj.project   p_env_source',
'            , int.name      p_int_source',
'            , int.status    p_int_source_status',
'            , int.version   p_int_source_version',
'            , int.pattern   p_int_pattern',
'            , prj.task_name p_int_task_from',
'       FROM oic_pip_ints_downloaded int',
'          , oic_pip_projects        prj',
'       WHERE int.project_id = prj.id',
'         AND prj.status NOT IN (''CLOSED'')',
'     ) source',
'   , ( SELECT prj.project   p_env_target',
'            , int.name      p_int_target',
'            , int.status    p_int_target_status',
'            , int.version   p_int_target_version',
'            , prj.task_name p_int_task_to',
'       FROM oic_pip_ints_downloaded int',
'          , oic_pip_projects        prj',
'       WHERE int.project_id = prj.id',
'         AND prj.status NOT IN (''CLOSED'')',
'     ) target',
'    , ( SELECT prj.project   p_env_target',
'            , null           p_int_target',
'            , null           p_int_target_status',
'            , null           p_int_target_version',
'            , prj.task_name  p_int_task_to',
'       FROM oic_pip_projects        prj',
'      WHERE prj.status NOT IN (''CLOSED'')',
'     ) target_null',
'    , header',
'WHERE source.p_int_source_version = header.next_version',
'  AND source.p_env_source = header.next_proj',
'  AND source.p_int_source = header.integration_name',
'  AND target.p_int_target_version(+) = header.cur_version',
'  AND target.p_env_target(+) = header.cur_proj',
'  AND target.p_int_target(+) = header.integration_name',
'  AND target_null.p_env_target = header.cur_proj'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Inconsistencies'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(194529582513995171)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>45514143494777820
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161448373040375854)
,p_db_column_name=>'INTEGRATION_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Integration Name'
,p_column_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::P9_ENV_SOURCE,P9_ENV_TARGET,P9_INT_SOURCE,P9_INT_SOURCE_STATUS,P9_INT_SOURCE_VERSION,P9_INT_TARGET,P9_INT_TARGET_STATUS,P9_INT_TARGET_VERSION,P9_INT_TASK_FROM,P9_INT_TASK_TO,P9_INT_PATTERN:#P_ENV_SOURCE#,#P_ENV_TARG'
||'ET#,#P_INT_SOURCE#,#P_INT_SOURCE_STATUS#,#P_INT_SOURCE_VERSION#,#P_INT_TARGET#,#P_INT_TARGET_STATUS#,#P_INT_TARGET_VERSION#,#P_INT_TASK_FROM#,#P_INT_TASK_TO#,#P_INT_PATTERN#'
,p_column_linktext=>'#INTEGRATION_NAME#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161448743720375856)
,p_db_column_name=>'ENVIRONMENT_VERSION'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Environment Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161449210322375857)
,p_db_column_name=>'NEXT_ENVIRONMENT_VERSION'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Next Environment Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161449623305375858)
,p_db_column_name=>'CUR_VERSION'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Cur Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161450016884375859)
,p_db_column_name=>'NEXT_VERSION'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Next Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161450398060375860)
,p_db_column_name=>'CUR_PROJ'
,p_display_order=>80
,p_column_identifier=>'J'
,p_column_label=>'Cur Proj'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161450789379375861)
,p_db_column_name=>'P_ENV_SOURCE'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'P Env Source'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161451166567375863)
,p_db_column_name=>'P_INT_SOURCE'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>'P Int Source'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161451563444375864)
,p_db_column_name=>'P_INT_SOURCE_STATUS'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'P Int Source Status'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161451999513375865)
,p_db_column_name=>'P_INT_SOURCE_VERSION'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'P Int Source Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161452393527375866)
,p_db_column_name=>'P_INT_PATTERN'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'P Int Pattern'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161452770673375869)
,p_db_column_name=>'P_INT_TASK_TO'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'P Int Task To'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161453233228375870)
,p_db_column_name=>'P_ENV_TARGET'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'P Env Target'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161453590037375871)
,p_db_column_name=>'P_INT_TARGET'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'P Int Target'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161454026818375872)
,p_db_column_name=>'P_INT_TARGET_STATUS'
,p_display_order=>170
,p_column_identifier=>'T'
,p_column_label=>'P Int Target Status'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161454281826375879)
,p_db_column_name=>'P_INT_TARGET_VERSION'
,p_display_order=>180
,p_column_identifier=>'U'
,p_column_label=>'P Int Target Version'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161454669059375880)
,p_db_column_name=>'P_INT_TASK_FROM'
,p_display_order=>190
,p_column_identifier=>'V'
,p_column_label=>'P Int Task From'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161455055587375880)
,p_db_column_name=>'NEXT_PROJ'
,p_display_order=>200
,p_column_identifier=>'W'
,p_column_label=>'Next Proj'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(194572664317211457)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124400'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ENVIRONMENT_VERSION:NEXT_ENVIRONMENT_VERSION:INTEGRATION_NAME::P_ENV_SOURCE:P_INT_SOURCE:P_INT_SOURCE_STATUS:P_INT_SOURCE_VERSION:P_INT_PATTERN:P_INT_TASK_TO:P_ENV_TARGET:P_INT_TARGET:P_INT_TARGET_STATUS:P_INT_TARGET_VERSION:P_INT_TASK_FROM:NEXT_PROJ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161474383463398955)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194529529148995170)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161463367268375904)
,p_name=>'ChangeIntStatus'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_INTEGRATION_STATUS_SCH'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149263404208629418)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(194529529148995170)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149263552877629419)
,p_event_id=>wwv_flow_imp.id(149263404208629418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194529529148995170)
);
wwv_flow_imp.component_end;
end;
/
