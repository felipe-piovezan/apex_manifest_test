prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>43
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Lookup Usages'
,p_alias=>'LOOKUP-USAGES'
,p_page_mode=>'MODAL'
,p_step_title=>'&P43_LKP_ID.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220629200915'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(36478768969847619)
,p_name=>'Lookup'
,p_template=>wwv_flow_imp.id(183996957676094802)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT int.name, int.version, int.status',
'FROM oic_pip_lkps_usage      lkp_u',
'   , oic_pip_ints_downloaded int',
'WHERE lkp_u.integration_id = int.id',
'  AND lkp_u.project_id = int.project_id',
'  AND (DECODE (:P43_ONLY_ACTIVE',
'             , ''YES'', ''ACTIVATED''',
'             ) = int.status OR :P43_ONLY_ACTIVE IS NULL)',
'  AND lkp_u.lookup_id = :P43_LKP_ID',
'  AND lkp_u.project_id = :P43_PROJECT_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P43_LKP_ID,P43_PROJECT_ID,P43_ONLY_ACTIVE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(184051106413094836)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24679429460833207)
,p_query_column_id=>1
,p_column_alias=>'NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Integration Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24679579728833208)
,p_query_column_id=>2
,p_column_alias=>'VERSION'
,p_column_display_sequence=>20
,p_column_heading=>'Integration Version'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24679642121833209)
,p_query_column_id=>3
,p_column_alias=>'STATUS'
,p_column_display_sequence=>30
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24679278242833205)
,p_name=>'P43_PROJECT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36478768969847619)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24679323595833206)
,p_name=>'P43_ONLY_ACTIVE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(36478768969847619)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24852926202457632)
,p_name=>'P43_LKP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(36478768969847619)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
