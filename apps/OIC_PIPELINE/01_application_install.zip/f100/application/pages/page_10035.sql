prompt --application/pages/page_10035
begin
--   Manifest
--     PAGE: 10035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>10035
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Automations Log'
,p_alias=>'AUTOMATIONS-LOG'
,p_page_mode=>'MODAL'
,p_step_title=>'Automations Log'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(184113450625094882)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(184111529044094880)
,p_required_patch=>wwv_flow_imp.id(184108966515094878)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page provides an interactive report of the automations log.</p>',
'<p>Review logged information about previous automation executions. The log contains start and end timestamps as well as details about processed rows (successful and with errors). Drill down into Messages to see individual messages for processed rows.'
||'</p>',
''))
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220614140053'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184188503693096109)
,p_plug_name=>'Automations Log'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.run_id',
'     , a.start_time start_timestamp',
'     , a.name automation_name',
'     , a.status',
'     , NULL successful_row_count',
'     , NULL error_row_count',
'     , NULL msg_count',
'     , ''Yes'' is_job',
'     , a.end_time end_timestamp',
'  FROM oic_pip_automation_log a',
' ORDER BY run_id DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Automations Log'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(184189409223096109)
,p_name=>'Automations Log'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>12057784749599073
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184190243720096110)
,p_db_column_name=>'AUTOMATION_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Automation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184190715075096111)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184192313302096112)
,p_db_column_name=>'IS_JOB'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Scheduled'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184189856376096110)
,p_db_column_name=>'START_TIMESTAMP'
,p_display_order=>90
,p_column_identifier=>'B'
,p_column_label=>'Started'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184192631156096113)
,p_db_column_name=>'END_TIMESTAMP'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Ended'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182101331027836737)
,p_db_column_name=>'RUN_ID'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Run Id'
,p_column_link=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.::P10037_RUN_ID:#RUN_ID#'
,p_column_linktext=>'#RUN_ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182101512728836738)
,p_db_column_name=>'SUCCESSFUL_ROW_COUNT'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Successful Row Count'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182101584490836739)
,p_db_column_name=>'ERROR_ROW_COUNT'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Error Row Count'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182101712791836740)
,p_db_column_name=>'MSG_COUNT'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Msg Count'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(184193674558096114)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120621'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'START_TIMESTAMP:END_TIMESTAMP:AUTOMATION_NAME:STATUS:RUN_ID:'
,p_sort_column_1=>'START_TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11854584159599652)
,p_application_user=>'OIC_PIP_DEV'
,p_name=>'LOOKUP SYNC'
,p_description=>'See Lookups sync instances'
,p_report_seq=>10
,p_report_alias=>'118546'
,p_status=>'PUBLIC'
,p_report_columns=>'START_TIMESTAMP:END_TIMESTAMP:AUTOMATION_NAME:STATUS:RUN_ID:'
,p_sort_column_1=>'START_TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(11854939748599662)
,p_report_id=>wwv_flow_imp.id(11854584159599652)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'AUTOMATION_NAME'
,p_operator=>'='
,p_expr=>'SYNC - oic_pip_prc_auto_lkp_downloads'
,p_condition_sql=>'"AUTOMATION_NAME" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''SYNC - oic_pip_prc_auto_lkp_downloads''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11855963455607536)
,p_application_user=>'OIC_PIP_DEV'
,p_name=>'INTEGRATION SYNC'
,p_description=>'See Integration sync instances'
,p_report_seq=>10
,p_report_alias=>'118560'
,p_status=>'PUBLIC'
,p_report_columns=>'START_TIMESTAMP:END_TIMESTAMP:AUTOMATION_NAME:STATUS:RUN_ID:'
,p_sort_column_1=>'START_TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(11856359718607537)
,p_report_id=>wwv_flow_imp.id(11855963455607536)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'AUTOMATION_NAME'
,p_operator=>'='
,p_expr=>'SYNC - oic_pip_prc_auto_int_downloads'
,p_condition_sql=>'"AUTOMATION_NAME" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''SYNC - oic_pip_prc_auto_int_downloads''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11858427512776173)
,p_application_user=>'OIC_PIP_DEV'
,p_name=>'PACKAGE SYNC'
,p_description=>'See Package sync instances'
,p_report_seq=>10
,p_report_alias=>'118588'
,p_status=>'PUBLIC'
,p_report_columns=>'START_TIMESTAMP:END_TIMESTAMP:AUTOMATION_NAME:STATUS:RUN_ID:'
,p_sort_column_1=>'START_TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(11859164041778363)
,p_report_id=>wwv_flow_imp.id(11858427512776173)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'AUTOMATION_NAME'
,p_operator=>'='
,p_expr=>'SYNC - oic_pip_prc_auto_pkg_downloads'
,p_condition_sql=>'"AUTOMATION_NAME" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''SYNC - oic_pip_prc_auto_pkg_downloads''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152224867145703128)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184188503693096109)
,p_button_name=>'FIX'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_image_alt=>'Fix'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-heartbeat'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(150358993779183559)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(184188503693096109)
,p_button_name=>'PURGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_image_alt=>'Purge Log'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184194614444096115)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(184188503693096109)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150359099285183560)
,p_name=>'Purge'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(150358993779183559)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150359330621183562)
,p_event_id=>wwv_flow_imp.id(150359099285183560)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150359256254183561)
,p_event_id=>wwv_flow_imp.id(150359099285183560)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    FOR reg IN (SELECT a.run_id',
'                FROM oic_pip_automation_log_err a',
'                WHERE a.run_id IN ( SELECT b.run_id',
'                                    FROM oic_pip_automation_log b',
'                                    WHERE SUBSTR(b.status, 1, 9) = ''COMPLETED''',
'                                  )',
'                  AND a.update_date <= SYSDATE - 15',
'                UNION',
'                SELECT a.run_id',
'                FROM oic_pip_automation_log_err a',
'                WHERE a.run_id IN ( SELECT b.run_id',
'                                    FROM oic_pip_automation_log b',
'                                    WHERE SUBSTR(b.status, 1, 5) = ''ERROR''',
'                                  )',
'                  AND a.update_date <= SYSDATE - 90)',
'        LOOP',
'            DELETE oic_pip_automation_log_err WHERE run_id = reg.run_id;',
'            DELETE oic_pip_automation_log WHERE run_id = reg.run_id;',
'        END LOOP;',
'    COMMIT;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150359417355183563)
,p_event_id=>wwv_flow_imp.id(150359099285183560)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150359466578183564)
,p_event_id=>wwv_flow_imp.id(150359099285183560)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(184188503693096109)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152225050536703129)
,p_name=>'Fix'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(152224867145703128)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152225533443703134)
,p_event_id=>wwv_flow_imp.id(152225050536703129)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'This will force an update to non ended sync automation instance. Do you want to continue?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152225128457703130)
,p_event_id=>wwv_flow_imp.id(152225050536703129)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152225226641703131)
,p_event_id=>wwv_flow_imp.id(152225050536703129)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_result  INTEGER;',
'BEGIN',
'    UPDATE oic_pip_automation_log',
'    SET end_time = SYSDATE',
'    WHERE end_time IS NULL;',
'    ',
'    DELETE oic_pip_thread;',
'',
'    BEGIN',
'        FOR reg IN (SELECT *',
'                    FROM user_scheduler_jobs)',
'            LOOP',
'                dbms_scheduler.drop_job(reg.job_name, TRUE);',
'            END LOOP;',
'    EXCEPTION',
'        WHEN OTHERS THEN NULL;',
'    END;',
'',
'    DELETE oic_pip_progress;',
'',
'    COMMIT;',
'',
'    FOR interfaces IN (select ''pipe_sync_interface'' topic from dual ',
'                        union all',
'                        select ''pipe_sync_download_blob'' from dual ',
'                        union all',
'                        select ''pipe_sync_download_schedule_sync'' from dual',
'                        union all',
'                        select ''pipe_sync_pkg'' from dual',
'                        union all',
'                        select ''pipe_sync_lkp'' from dual)',
'    LOOP',
'        l_result := 0;',
'        WHILE l_result <> 1 ',
'        LOOP',
'            l_result := dbms_pipe.receive_message(pipename => interfaces.topic, timeout => 0);',
'        END LOOP;',
'    END LOOP;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152225266189703132)
,p_event_id=>wwv_flow_imp.id(152225050536703129)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152225434495703133)
,p_event_id=>wwv_flow_imp.id(152225050536703129)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(184188503693096109)
);
wwv_flow_imp.component_end;
end;
/
