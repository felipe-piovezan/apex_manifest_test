prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Environment Lookups Diff Report Details'
,p_alias=>'ENVIRONMENT-LOOKUPS-DIFF-REPORT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Environment Lookups Diff Report Details'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'span.com-wrap {',
'width:40px;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220624181534'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197956610819903560)
,p_plug_name=>'Environment Diff Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001',
'     , c002',
'     , c003',
'     , c004',
'     , c005',
'FROM apex_collections',
'WHERE collection_name = ''LOOKUPS_COMPARE''',
'AND (c001 NOT IN (:P42_ONLY_DIFF) OR :P42_ONLY_DIFF = ''NULL'' OR c001 IS NULL)',
'AND c005 = :P42_LKP_ID',
'ORDER BY 5, 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P42_ONLY_DIFF,P42_LKP_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_page_header=>'Environment Diff Report'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(197956690447903560)
,p_name=>'Environment Diff Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>197956690447903560
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24522583462470278)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'W'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24522988332470279)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'X'
,p_column_label=>'Key Column'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24523307620470280)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'Y'
,p_column_label=>'Value(s) - &P32_ENV1_NAME.'
,p_column_html_expression=>'<span style="display:inline-block;width:600px;word-break:break-all;">#C003#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24523715531470280)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'Z'
,p_column_label=>'Value(s) - &P32_ENV2_NAME.'
,p_column_html_expression=>'<span style="display:inline-block;width:600px;word-break:break-all;">#C004#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24524144729470281)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'AA'
,p_column_label=>'Lookup'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#C005#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(197964227710905849)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125664'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'C001:C002:C003:C004:C005'
,p_break_on=>'C005:0:0:0:0:0'
,p_break_enabled_on=>'C005:0:0:0:0:0'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24524809649470288)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24487092225406422)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Apply'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24486597253406417)
,p_name=>'P42_PROJ_ID_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24486738944406419)
,p_name=>'P42_PROJ_ID_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24487358504406425)
,p_name=>'P42_KEY_COLUMN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_prompt=>'Key Column'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT a.column_name, a.position',
' FROM oic_pip_lookup_columns a',
'    , oic_pip_lookup_header  b',
' WHERE a.lookup_header_id = b.lookup_header_id',
'   AND b.id = :P42_LKP_ID'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24487596647406427)
,p_name=>'P42_ENV1_NAME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24487636470406428)
,p_name=>'P42_ENV2_NAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24526429680470298)
,p_name=>'P42_ONLY_DIFF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_prompt=>'Only Differences'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Identical Record'
,p_attribute_04=>'NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24527278783470299)
,p_name=>'P42_LKP_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(197956610819903560)
,p_prompt=>'Lookup'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24527693935470315)
,p_name=>'Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P42_ONLY_DIFF'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24528105516470317)
,p_event_id=>wwv_flow_imp.id(24527693935470315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197956610819903560)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24487141271406423)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(24487092225406422)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24487210196406424)
,p_event_id=>wwv_flow_imp.id(24487141271406423)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    apex_collection.create_or_truncate_collection(''LOOKUPS_COMPARE'');',
'    oic_pip_prc_compare_lookup(:P42_PROJ_ID_1, :P42_PROJ_ID_2, :P42_LKP_ID, :P42_KEY_COLUMN);',
'END;'))
,p_attribute_02=>'P42_LKP_ID,P42_PROJ_ID_1,P42_PROJ_ID_2,P42_KEY_COLUMN'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24487426830406426)
,p_event_id=>wwv_flow_imp.id(24487141271406423)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197956610819903560)
);
wwv_flow_imp.component_end;
end;
/
