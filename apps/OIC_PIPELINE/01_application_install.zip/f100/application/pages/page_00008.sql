prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Environment Promotion'
,p_alias=>'ENVIRONMENT-PROMOTION'
,p_page_mode=>'MODAL'
,p_step_title=>'Environment Promotion'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
,p_last_updated_by=>'PROJ1'
,p_last_upd_yyyymmddhh24miss=>'20211126150929'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182049563623959205)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182050345554962037)
,p_plug_name=>'Ints'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.name           "source integration name"',
'     , a.version        "source integration version"',
'     , b.project        "source environment name"',
'     , b.task_name      "source task name"',
'     , a.status         "source integration status"',
'     , a.pattern',
'     , target.project   "target environment name"',
'     , target.task_name "target task name"',
'     , target.name      "target integration name"',
'     , target.version   "target integration version"',
'     , target.status    "target integration status"',
'FROM oic_pip_ints_downloaded a',
'   , oic_pip_projects        b',
'   , ( SELECT MIN(d.status)  status',
'            , c.project',
'            , d.name',
'            , MAX(d.version) version',
'            , c.pipeline_order',
'            , c.task_name',
'       FROM oic_pip_projects        c',
'          , oic_pip_ints_downloaded d',
'       WHERE c.id = d.project_id',
'       GROUP BY c.project',
'              , d.name',
'              , c.pipeline_order',
'              , c.task_name',
'     )                             target',
'WHERE a.project_id = b.id',
'  AND :P8_PROJECT_ID = b.id',
'  AND b.pipeline_order + 1 = target.pipeline_order',
'  AND a.name = target.name',
'--  AND a.status = ''ACTIVATED''',
'   AND a.status = DECODE( :P8_ALL_STATUS',
'                        , ''Y'', a.status',
'                        , ''ACTIVATED''',
'                        )',
'  AND ((TO_NUMBER(SUBSTR(a.version, 1, 2)) = TO_NUMBER(SUBSTR(target.version, 1, 2)) AND',
'        TO_NUMBER(SUBSTR(a.version, 4, 2)) = TO_NUMBER(SUBSTR(target.version, 4, 2)) AND',
'        TO_NUMBER(SUBSTR(a.version, 7, 4)) > TO_NUMBER(SUBSTR(target.version, 7, 4)))',
'      OR',
'       (TO_NUMBER(SUBSTR(a.version, 1, 2)) = TO_NUMBER(SUBSTR(target.version, 1, 2)) AND',
'        TO_NUMBER(SUBSTR(a.version, 4, 2)) > TO_NUMBER(SUBSTR(target.version, 4, 2)))',
'      OR',
'       TO_NUMBER(SUBSTR(a.version, 1, 2)) > TO_NUMBER(SUBSTR(target.version, 1, 2))',
'      )',
'UNION ALL',
'SELECT a.name         "source integration name"',
'     , MAX(a.version) "source integration version"',
'     , b.project      "source environment name"',
'     , b.task_name    "source task name"',
'     , MIN(a.status)  "source integration status"',
'     , a.pattern',
'     , i.project      "target environment name"',
'     , i.task_name    "target task name"',
'     , NULL           "target integration name"',
'     , NULL           "target integration version"',
'     , NULL           "target integration status"',
'FROM oic_pip_ints_downloaded a',
'   , oic_pip_projects        b',
'   , oic_pip_projects        i',
'WHERE a.project_id = b.id',
'  AND b.pipeline_order + 1 = i.pipeline_order',
'  AND :P8_PROJECT_ID = b.id',
'--  AND a.status = ''ACTIVATED''',
'  AND a.status = DECODE( :P8_ALL_STATUS',
'                        , ''Y'', a.status',
'                        , ''ACTIVATED''',
'                        )',
'  AND NOT EXISTS(SELECT NULL',
'                 FROM oic_pip_ints_downloaded d',
'                 WHERE i.id = d.project_id AND a.name = d.name)',
'GROUP BY a.name',
'       , b.project',
'       , a.pattern',
'       , i.project',
'       , i.task_name',
'       , b.task_name',
'ORDER BY 1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P8_ALL_STATUS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Ints'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(182050518097962038)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>9918893624465002
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182162953140923338)
,p_db_column_name=>'source integration name'
,p_display_order=>10
,p_column_identifier=>'AD'
,p_column_label=>'Source Integration Name'
,p_column_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::P9_ENV_SOURCE,P9_ENV_TARGET,P9_INT_SOURCE,P9_INT_TARGET,P9_INT_PATTERN,P9_INT_SOURCE_STATUS,P9_INT_TARGET_STATUS,P9_INT_SOURCE_VERSION,P9_INT_TARGET_VERSION,P9_INT_TASK_FROM,P9_INT_TASK_TO:#source environment name#,'
||'#target environment name#,#source integration name#,#target integration name#,#PATTERN#,#source integration status#,#target integration status#,#source integration version#,#target integration version#,#source task name#,#target task name#'
,p_column_linktext=>'#source integration name#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163075422923339)
,p_db_column_name=>'source integration version'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Source Integration Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163199993923340)
,p_db_column_name=>'source environment name'
,p_display_order=>30
,p_column_identifier=>'AF'
,p_column_label=>'Source Environment Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163281365923341)
,p_db_column_name=>'source task name'
,p_display_order=>40
,p_column_identifier=>'AG'
,p_column_label=>'Source Task Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163397345923342)
,p_db_column_name=>'source integration status'
,p_display_order=>50
,p_column_identifier=>'AH'
,p_column_label=>'Source Integration Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163440972923343)
,p_db_column_name=>'PATTERN'
,p_display_order=>60
,p_column_identifier=>'AI'
,p_column_label=>'Pattern'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163595707923344)
,p_db_column_name=>'target environment name'
,p_display_order=>70
,p_column_identifier=>'AJ'
,p_column_label=>'Target Environment Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163706188923345)
,p_db_column_name=>'target task name'
,p_display_order=>80
,p_column_identifier=>'AK'
,p_column_label=>'Target Task Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163820538923346)
,p_db_column_name=>'target integration name'
,p_display_order=>90
,p_column_identifier=>'AL'
,p_column_label=>'Target Integration Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182163917947923347)
,p_db_column_name=>'target integration version'
,p_display_order=>100
,p_column_identifier=>'AM'
,p_column_label=>'Target Integration Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182164019675923348)
,p_db_column_name=>'target integration status'
,p_display_order=>110
,p_column_identifier=>'AN'
,p_column_label=>'Target Integration Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(182059916460991227)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'99283'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'P_INT_P_INT_TASK_TO:source integration name:source integration version:source environment name:source task name:source integration status:PATTERN:target environment name:target task name:target integration name:target integration version:target integ'
||'ration status'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(159418001397737400)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182049563623959205)
,p_button_name=>'Batch_Promotion'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Batch Promotion'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::P19_PROJECT_ID,P19_ALL_STATUS:&P8_PROJECT_ID.,&P8_ALL_STATUS.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182051707180962050)
,p_name=>'P8_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182050345554962037)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182278159682981045)
,p_name=>'P8_ALL_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182049563623959205)
,p_prompt=>'All Integration Status'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182054679878962080)
,p_name=>'DiagClose'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(182050345554962037)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054781703962081)
,p_event_id=>wwv_flow_imp.id(182054679878962080)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P8_PROJECT_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P8_PROJECT_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054882515962082)
,p_event_id=>wwv_flow_imp.id(182054679878962080)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(182050345554962037)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182278259056981046)
,p_name=>'Refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_ALL_STATUS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182278376546981047)
,p_event_id=>wwv_flow_imp.id(182278259056981046)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(182050345554962037)
);
wwv_flow_imp.component_end;
end;
/
