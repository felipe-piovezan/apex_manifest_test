prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'1. Install - First Install'
,p_alias=>'1-INSTALL-FIRST-INSTALL'
,p_step_title=>'1. Install - First Install'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220707184252'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142586390780170578)
,p_plug_name=>'1. Install - First Install'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(184032613546094824)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(142585931375170577)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184081847704094857)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'<center><h1><b>OIC Pipeline Install</b></h1></center>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142586510067170578)
,p_plug_name=>'1. Install - First Install'
,p_parent_plug_id=>wwv_flow_imp.id(142586390780170578)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(183993785181094800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Welcome to the OIC Pipeline Wizard Setup</b></p>',
'<p>This Wizard will guide you through the installation of OIC Pipeline.</p>',
'<p>To proceed with the installation, it is necessary to configure the remote repository. Fill in the information below and click "Test".</p>',
'<p>Click "Next" to continue.</p>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142601997453357791)
,p_plug_name=>'Repo'
,p_parent_plug_id=>wwv_flow_imp.id(142586510067170578)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'OIC_PIP_REMOTE_UPDATE_CONF'
,p_include_rowid_column=>true
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20293473919813783)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_button_name=>'Test'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Test'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(142588536893170581)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(142586390780170578)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(142589204517170582)
,p_branch_name=>'Go To Page 34'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(142588536893170581)
,p_branch_sequence=>20
,p_branch_condition_type=>'ITEM_IS_NULL'
,p_branch_condition=>'P33_ERROR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142602241134357794)
,p_name=>'P33_REPO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_item_source_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_prompt=>'Repository Name'
,p_source=>'REPO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'LTS Channel'
,p_quick_pick_value_01=>'oic-pipeline'
,p_quick_pick_label_02=>'DEV Channel'
,p_quick_pick_value_02=>'oic_pip_dev'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142602419211357795)
,p_name=>'P33_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_item_source_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_prompt=>'Owner'
,p_source=>'OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142602768883357799)
,p_name=>'P33_BITBUCKET_USER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_prompt=>'Bitbucket User'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142602888554357800)
,p_name=>'P33_BITBUCKET_PASS'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_prompt=>'Bitbucket Token'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142603130685357802)
,p_name=>'P33_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_item_source_plug_id=>wwv_flow_imp.id(142601997453357791)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142604385873357815)
,p_name=>'P33_TAG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(142586390780170578)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142604453913357816)
,p_name=>'P33_ERROR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(142586390780170578)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(142603950417357811)
,p_computation_sequence=>10
,p_computation_item=>'P33_ROWID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_id VARCHAR2(1000);',
'BEGIN',
'    -- create table',
'    BEGIN',
'        EXECUTE IMMEDIATE ''CREATE TABLE oic_pip_remote_update_conf',
'            (provider VARCHAR2(1000), repo_name VARCHAR2(1000), owner VARCHAR2(1000), install_file_path VARCHAR2(1000), current_remote_version_file_path VARCHAR2(1000), dev_application VARCHAR2(1))'';',
'    EXCEPTION',
'        WHEN OTHERS THEN NULL;',
'    END;',
'',
'    -- init conf',
'    BEGIN',
'        EXECUTE IMMEDIATE ''DECLARE CURSOR cur_config_exists IS SELECT 1 FROM oic_pip_remote_update_conf; l_dummy NUMBER; l_not_exists BOOLEAN; BEGIN OPEN cur_config_exists;',
'        FETCH cur_config_exists INTO l_dummy;',
'        l_not_exists := cur_config_exists%NOTFOUND;',
'        CLOSE cur_config_exists;',
'        IF l_not_exists THEN INSERT INTO oic_pip_remote_update_conf (provider, repo_name, owner, install_file_path, current_remote_version_file_path, dev_application) VALUES (''''bitbucket'''', ''''oic-pipeline'''', ''''aggrandizeit'''', ''''remote_deploy/OIC_PIPE'
||'LINE.txt'''', NULL, ''''N''''); END IF; END;'';',
'        COMMIT;',
'    EXCEPTION',
'        WHEN OTHERS THEN NULL;',
'    END;',
'',
'    EXECUTE IMMEDIATE ''SELECT ROWID FROM oic_pip_remote_update_conf'' INTO l_id;',
'',
'    RETURN l_id;',
'END;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20293541870813784)
,p_name=>'Click'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(20293473919813783)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142604331380357814)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url       VARCHAR2(1000);',
'    lc_response CLOB;',
'    l_user      VARCHAR2(1000) := :P33_BITBUCKET_USER;',
'    l_pass      VARCHAR2(1000) := :P33_BITBUCKET_PASS;',
'    l_resp      VARCHAR2(1000);',
'BEGIN',
'    apex_web_service.set_request_headers(p_name_01 => ''Accept'', p_value_01 => ''*/*'', p_reset=> TRUE);',
'',
'    -- pegando o hash do commit da ultima tag',
'    l_url := ''https://api.bitbucket.org/2.0/repositories/'' || :P33_OWNER || ''/'' || :P33_REPO_NAME ||',
'             ''/refs/tags?sort=-target.date&fields=values.target.hash,values.name'';',
'',
'    lc_response := apex_web_service.make_rest_request(p_url => l_url, p_http_method => ''GET'', p_username => l_user,',
'                                                      p_password => l_pass);',
'',
'    IF apex_web_service.g_status_code IN (200, 204) THEN',
'        l_resp := JSON_VALUE(lc_response, ''$.values[0].target.hash'');',
'        :P33_TAG := l_resp;',
'        :P33_ERROR := NULL;',
'    ELSE',
'        l_resp := JSON_VALUE(lc_response, ''$.error.message'');',
'        IF l_resp IS NULL THEN',
'            l_resp := ''There was an error connecting to the repository. Please review the information filled in.'';',
'        END IF;',
'        :P33_TAG := NULL;',
'        :P33_ERROR := l_resp;',
'    END IF;',
'END;'))
,p_attribute_02=>'P33_TAG,P33_ERROR,P33_BITBUCKET_USER,P33_BITBUCKET_PASS,P33_OWNER,P33_REPO_NAME'
,p_attribute_03=>'P33_TAG,P33_ERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142605814827357829)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    lc_response CLOB;',
'    l_url       VARCHAR2(1000);',
'',
'    -- FUNCTION write_clob_buffer',
'    FUNCTION write_clob_buffer(p_clob_full CLOB, p_start NUMBER, p_end NUMBER) RETURN CLOB IS',
'        l_clob          CLOB;',
'        l_number        NUMBER;',
'        l_buffer_amount NUMBER := 30000;',
'    BEGIN',
'        dbms_lob.createtemporary(l_clob, TRUE);',
'        l_number := p_start;',
'        WHILE (l_number + l_buffer_amount <= p_end)',
'        LOOP',
'            dbms_lob.writeappend(l_clob, l_buffer_amount, dbms_lob.substr(p_clob_full, l_buffer_amount, l_number));',
'            l_number := l_number + l_buffer_amount;',
'        END LOOP;',
'        dbms_lob.writeappend(l_clob, p_end - l_number + 1,',
'                             dbms_lob.substr(p_clob_full, p_end - l_number + 1, l_number));',
'        RETURN l_clob;',
'    END write_clob_buffer;',
'',
'BEGIN',
'    apex_web_service.set_request_headers(p_name_01 => ''Accept'', p_value_01 => ''*/*'', p_reset=> TRUE);',
'',
'    l_url := ''https://api.bitbucket.org/2.0/repositories/'' || :P33_OWNER || ''/'' || :P33_REPO_NAME || ''/src/'' ||',
'             :P33_TAG || ''/'' || ''DDL/OIC_PIP_PRC_APP_INSTALL.sql'';',
'    lc_response := apex_web_service.make_rest_request(p_url => l_url, p_http_method => ''GET'',',
'                                                      p_username => :P33_BITBUCKET_USER,',
'                                                      p_password => :P33_BITBUCKET_PASS);',
'    lc_response := write_clob_buffer(lc_response, 1, instr(lc_response,''/'' ,-1)-1);',
'    EXECUTE IMMEDIATE lc_response;',
'EXCEPTION WHEN OTHERS THEN',
'    :P33_ERROR := SQLERRM;',
'END;'))
,p_attribute_02=>'P33_TAG,P33_ERROR,P33_BITBUCKET_USER,P33_BITBUCKET_PASS,P33_OWNER,P33_REPO_NAME'
,p_attribute_03=>'P33_ERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142604632469357817)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'error'
,p_attribute_02=>'static'
,p_attribute_03=>'Repo Configuration Error'
,p_attribute_04=>'&P33_ERROR.'
,p_attribute_09=>'N'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P33_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20293766407813786)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_03=>'Repo Configuration Succeeded!'
,p_attribute_09=>'N'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P33_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142605006845357821)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_workspace      VARCHAR(255);',
'    l_application_id NUMBER := apex_application.g_flow_id;',
'    l_workspace_id   NUMBER := apex_application_install.get_workspace_id;',
'',
'    -- cur_workspace',
'    CURSOR cur_workspace IS',
'        SELECT COALESCE(( SELECT app.workspace',
'                            FROM apex_applications app',
'                            WHERE app.application_id = l_application_id',
'                        ), ( SELECT app.workspace',
'                                FROM apex_applications app',
'                                WHERE app.workspace_id = l_workspace_id',
'                            ))',
'        FROM dual;',
'',
'BEGIN',
'    UPDATE oic_pip_remote_update_conf',
'       SET repo_name = :P33_REPO_NAME',
'         , owner = :P33_OWNER;',
'',
'    COMMIT;',
'',
'    OPEN cur_workspace;',
'    FETCH cur_workspace INTO l_workspace;',
'    CLOSE cur_workspace;',
'    ',
'    BEGIN',
'        apex_credential.drop_credential(''BITBUCKT_CREDENTIAL'');',
'    EXCEPTION WHEN OTHERS THEN',
'        NULL;',
'    END;',
'',
'    apex_util.set_workspace(p_workspace => l_workspace);',
'',
'    apex_credential.create_credential(p_credential_name => ''BITBUCKT_CREDENTIAL'',',
'                                        p_credential_static_id => ''BITBUCKT_CREDENTIAL'',',
'                                        p_authentication_type => apex_credential.c_type_basic,',
'                                        p_prompt_on_install => FALSE);',
'',
'    apex_credential.set_persistent_credentials(p_credential_static_id => ''BITBUCKT_CREDENTIAL'',',
'                                                p_client_id => :P33_BITBUCKET_USER, p_client_secret => :P33_BITBUCKET_PASS);',
'END;'))
,p_attribute_02=>'P33_REPO_NAME,P33_OWNER,P33_BITBUCKET_USER,P33_BITBUCKET_PASS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P33_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20293899346813787)
,p_event_id=>wwv_flow_imp.id(20293541870813784)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(142588536893170581)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P33_ERROR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20293924211813788)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P33_REPO_NAME'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20294057242813789)
,p_event_id=>wwv_flow_imp.id(20293924211813788)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P33_REPO_NAME = ''oic_pip_dev'' THEN',
'  :P33_OWNER := ''felipevpiovezan'';',
'ELSE',
'  :P33_OWNER := ''aggrandizeit'';',
'END IF;'))
,p_attribute_02=>'P33_REPO_NAME'
,p_attribute_03=>'P33_OWNER'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11000194433777530)
,p_name=>'load'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(142588536893170581)
,p_bind_type=>'bind'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11000257405777531)
,p_event_id=>wwv_flow_imp.id(11000194433777530)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(142588536893170581)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(142601855559357790)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create remote conf table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- create table',
'    BEGIN',
'        EXECUTE IMMEDIATE ''CREATE TABLE oic_pip_remote_update_conf',
'            (provider VARCHAR2(1000), repo_name VARCHAR2(1000), owner VARCHAR2(1000), install_file_path VARCHAR2(1000), current_remote_version_file_path VARCHAR2(1000), dev_application VARCHAR2(1))'';',
'    EXCEPTION',
'        WHEN OTHERS THEN NULL;',
'    END;',
'',
'    -- init conf',
'    BEGIN',
'        EXECUTE IMMEDIATE ''DECLARE CURSOR cur_config_exists IS SELECT 1 FROM oic_pip_remote_update_conf; l_dummy NUMBER; l_not_exists BOOLEAN; BEGIN OPEN cur_config_exists;',
'        FETCH cur_config_exists INTO l_dummy;',
'        l_not_exists := cur_config_exists%NOTFOUND;',
'        CLOSE cur_config_exists;',
'        IF l_not_exists THEN INSERT INTO oic_pip_remote_update_conf (provider, repo_name, owner, install_file_path, current_remote_version_file_path, dev_application) VALUES (''''bitbucket'''', ''''oic-pipeline'''', ''''aggrandizeit'''', ''''remote_deploy/OIC_PIPE'
||'LINE.txt'''', NULL, ''''N''''); END IF; END;'';',
'        COMMIT;',
'    EXCEPTION',
'        WHEN OTHERS THEN NULL;',
'    END;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(142602064255357792)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(142601997453357791)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 1. Install - First Install'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
