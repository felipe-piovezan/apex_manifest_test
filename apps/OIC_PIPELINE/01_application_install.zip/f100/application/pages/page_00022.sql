prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Remote Update Config'
,p_alias=>'REMOTE-UPDATE-CONFIG'
,p_step_title=>'Remote Update Config'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220718125132'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140012915722814515)
,p_plug_name=>'Remote Update Configuration'
,p_region_template_options=>'t-BreadcrumbRegion--useRegionTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140013487090814945)
,p_plug_name=>'Remote Update Config'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OIC_PIP_REMOTE_UPDATE_CONF'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140039379388424793)
,p_plug_name=>'Credential'
,p_parent_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140039601805424795)
,p_plug_name=>'Credential Created'
,p_parent_plug_id=>wwv_flow_imp.id(140039379388424793)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM ( SELECT ''github'' provider',
'       FROM user_credentials',
'       WHERE UPPER(credential_name) = ''OIC_PIPELINE_CRED''',
'       UNION ALL',
'       SELECT ''bitbucket'' provider',
'       FROM apex_workspace_credentials',
'       WHERE static_id = ''BITBUCKT_CREDENTIAL''',
'     ) a',
'WHERE provider = :P22_PROVIDER'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140039801074424797)
,p_plug_name=>'Credential NOT Created'
,p_parent_plug_id=>wwv_flow_imp.id(140039379388424793)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM ( SELECT ''github'' provider',
'       FROM user_credentials',
'       WHERE UPPER(credential_name) = ''OIC_PIPELINE_CRED''',
'       UNION ALL',
'       SELECT ''bitbucket'' provider',
'       FROM apex_workspace_credentials',
'       WHERE static_id = ''BITBUCKT_CREDENTIAL''',
'     ) a',
'WHERE provider = :P22_PROVIDER'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140039443915424794)
,p_plug_name=>'Development OIC_PIPELINE Environment'
,p_parent_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_imp.id(140165923468238086)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137269043977646534)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(140039443915424794)
,p_button_name=>'GET_BASE64_INSTALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Get Application Install'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P22_DEV_APPLICATION'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140018679498814965)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140012915722814515)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11209106463273130)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140039801074424797)
,p_button_name=>'Test'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Test'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140019892827814968)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140012915722814515)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P22_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140039638796424796)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140039601805424795)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Delete Credential'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140039880264424798)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(140039801074424797)
,p_button_name=>'Create'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Credential'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(140020636459814969)
,p_branch_name=>'Go To Page 10000'
,p_branch_action=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::P22_ROWID:&P22_ROWID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10999783900777526)
,p_name=>'P22_ERROR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_source=>'APPLICATION_EXPORT'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140013769366814946)
,p_name=>'P22_ROWID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140014182486814951)
,p_name=>'P22_PROVIDER'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Provider'
,p_source=>'PROVIDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Bitbucket;bitbucket'
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140014546051814957)
,p_name=>'P22_REPO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Repo Name'
,p_source=>'REPO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140014952077814957)
,p_name=>'P22_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Owner'
,p_source=>'OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140015390312814958)
,p_name=>'P22_INSTALL_FILE_PATH'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Install File Path'
,p_source=>'INSTALL_FILE_PATH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140015750802814958)
,p_name=>'P22_CURRENT_REMOTE_VERSION_FILE_PATH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Current Remote Version File Path'
,p_source=>'CURRENT_REMOTE_VERSION_FILE_PATH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1000
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140016175577814960)
,p_name=>'P22_DEV_APPLICATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140039443915424794)
,p_item_source_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_prompt=>'Dev Application'
,p_source=>'DEV_APPLICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140039208150424791)
,p_name=>'P22_FILE_TYPE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(140013487090814945)
,p_source=>'APPLICATION_EXPORT'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140040286718424802)
,p_name=>'P22_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140039801074424797)
,p_prompt=>'Repo Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140040399561424803)
,p_name=>'P22_TOKEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(140039801074424797)
,p_prompt=>'Repo Token'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(137269291360646536)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(137269043977646534)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137269412298646537)
,p_event_id=>wwv_flow_imp.id(137269291360646536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137269579229646539)
,p_event_id=>wwv_flow_imp.id(137269291360646536)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_utils.export_application;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137269502243646538)
,p_event_id=>wwv_flow_imp.id(137269291360646536)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140039079594424790)
,p_event_id=>wwv_flow_imp.id(137269291360646536)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'url = ''f?p=&APP_ID.:22:&APP_SESSION.:APPLICATION_PROCESS=DOWNLOAD_BLOB:::FILE_TYPE:&P22_FILE_TYPE.''',
'window.open(url).focus();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140040012481424799)
,p_name=>'DeleteCred'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(140039638796424796)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040095845424800)
,p_event_id=>wwv_flow_imp.id(140040012481424799)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_pkg_application.drop_credentials;',
'  :P22_USERNAME := null;',
'  :P22_TOKEN := null;',
'END;'))
,p_attribute_02=>'P22_USERNAME,P22_TOKEN'
,p_attribute_03=>'P22_USERNAME,P22_TOKEN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040223937424801)
,p_event_id=>wwv_flow_imp.id(140040012481424799)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140040451348424804)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(140039880264424798)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040586324424805)
,p_event_id=>wwv_flow_imp.id(140040451348424804)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_application.create_credentials(:P22_USERNAME, :P22_TOKEN);',
'    :P22_USERNAME := NULL;',
'    :P22_TOKEN := NULL;',
'END;'))
,p_attribute_02=>'P22_USERNAME,P22_TOKEN'
,p_attribute_03=>'P22_USERNAME,P22_TOKEN'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040731293424806)
,p_event_id=>wwv_flow_imp.id(140040451348424804)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11209550090276098)
,p_name=>'Test'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11209106463273130)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11209916649276101)
,p_event_id=>wwv_flow_imp.id(11209550090276098)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url       VARCHAR2(1000);',
'    lc_response CLOB;',
'    l_user      VARCHAR2(1000) := :P22_USERNAME;',
'    l_pass      VARCHAR2(1000) := :P22_TOKEN;',
'    l_resp      VARCHAR2(1000);',
'BEGIN',
'    :P22_ERROR := null;',
'    ',
'    apex_web_service.set_request_headers(p_name_01 => ''Accept'', p_value_01 => ''*/*'', p_reset=> TRUE);',
'',
'    -- pegando o hash do commit da ultima tag',
'    l_url := ''https://api.bitbucket.org/2.0/repositories/'' || :P22_OWNER || ''/'' || :P22_REPO_NAME ||',
'             ''/refs/tags?sort=-target.date&fields=values.target.hash,values.name'';',
'',
'    lc_response := apex_web_service.make_rest_request(p_url => l_url, p_http_method => ''GET'', p_username => l_user,',
'                                                      p_password => l_pass);',
'',
'    IF apex_web_service.g_status_code IN (200, 204) THEN',
'        :P22_ERROR := NULL;',
'    ELSE',
'        l_resp := JSON_VALUE(lc_response, ''$.error.message'');',
'        IF l_resp IS NULL THEN',
'            l_resp := ''There was an error connecting to the repository. Please review the information filled in.'';',
'        END IF;',
'        :P22_ERROR := l_resp;',
'    END IF;',
'END;'))
,p_attribute_02=>'P22_USERNAME,P22_TOKEN,P22_OWNER,P22_REPO_NAME,P22_ERROR'
,p_attribute_03=>'P22_ERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11210901092276102)
,p_event_id=>wwv_flow_imp.id(11209550090276098)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'error'
,p_attribute_02=>'static'
,p_attribute_03=>'Repo Configuration Error'
,p_attribute_04=>'&P22_ERROR.'
,p_attribute_09=>'N'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P22_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11211434025276102)
,p_event_id=>wwv_flow_imp.id(11209550090276098)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_03=>'Repo Configuration Succeeded!'
,p_attribute_09=>'N'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P22_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11212409242276104)
,p_event_id=>wwv_flow_imp.id(11209550090276098)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(140039880264424798)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P22_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11000034347777529)
,p_event_id=>wwv_flow_imp.id(11209550090276098)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11209106463273130)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P22_ERROR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10999863562777527)
,p_name=>'Load'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10999981945777528)
,p_event_id=>wwv_flow_imp.id(10999863562777527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(140039880264424798)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140021518473814971)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(140013487090814945)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Remote Update Config'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140021125135814971)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(140013487090814945)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Remote Update Config'
);
wwv_flow_imp.component_end;
end;
/
