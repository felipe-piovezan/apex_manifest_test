prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Manage End User'
,p_alias=>'MANAGE-END-USER'
,p_page_mode=>'MODAL'
,p_step_title=>'Manage End User'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(184113450625094882)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_required_role=>wwv_flow_imp.id(184111529044094880)
,p_required_patch=>wwv_flow_imp.id(184108851778094878)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220331233414'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140932685191216298)
,p_plug_name=>'User'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200171755577739326)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183994767129094800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141007121095073141)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(200171755577739326)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P26_USERNAME'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141007460955073142)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(200171755577739326)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'NEXT'
,p_button_condition=>'P26_USERNAME'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141007913896073142)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(200171755577739326)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141008333978073142)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(200171755577739326)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Delete'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P26_USERNAME'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140932551725216297)
,p_name=>'P26_EMAIL'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(140932685191216298)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140933017711216301)
,p_name=>'P26_PASS'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(140932685191216298)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140934350663216315)
,p_name=>'P26_USER_LOCKED'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(140932685191216298)
,p_prompt=>'User Locked'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P26_USERNAME'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Yes'
,p_attribute_03=>'No'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141003518540073131)
,p_name=>'P26_USERNAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140932685191216298)
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_name',
'     , email',
'FROM apex_workspace_apex_users',
'WHERE user_name = :P26_USERNAME'))
,p_read_only_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(140934111858216312)
,p_validation_name=>'unique_username'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_name',
'FROM apex_workspace_apex_users',
'WHERE UPPER(user_name) = UPPER(:P26_USERNAME)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Username must be unique!'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(141007460955073142)
,p_associated_item=>wwv_flow_imp.id(141003518540073131)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(141009521575073168)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(141007913896073142)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141009946600073169)
,p_event_id=>wwv_flow_imp.id(141009521575073168)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140933261768216304)
,p_name=>'Delete'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(141008333978073142)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140933506898216306)
,p_event_id=>wwv_flow_imp.id(140933261768216304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to remove the user?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140933372148216305)
,p_event_id=>wwv_flow_imp.id(140933261768216304)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    APEX_UTIL.REMOVE_USER(p_user_name => :P26_USERNAME);',
'END;'))
,p_attribute_02=>'P26_USERNAME,P26_PASS,P26_EMAIL'
,p_attribute_03=>'P26_USERNAME,P26_PASS,P26_EMAIL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140933838245216309)
,p_event_id=>wwv_flow_imp.id(140933261768216304)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140934335747216314)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CreateUser'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    APEX_UTIL.CREATE_USER(',
'        p_user_name    => :P26_USERNAME,',
'        p_web_password => :P26_PASS,',
'        p_email_address => :P26_EMAIL,',
'        p_change_password_on_first_use => ''Y''',
');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(141007460955073142)
,p_process_success_message=>'User created!'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140934981010216321)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UpdateUser'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P26_PASS IS NULL THEN',
'        apex_util.edit_user( p_user_id => apex_util.get_user_id(:P26_USERNAME)',
'                           , p_user_name => :P26_USERNAME',
'                           , p_email_address => :P26_EMAIL',
'                           , p_account_locked => CASE :P26_USER_LOCKED WHEN ''Yes'' THEN ''Y'' ELSE ''N'' END',
'                           );',
'    ELSE',
'        apex_util.edit_user( p_user_id => apex_util.get_user_id(:P26_USERNAME)',
'                           , p_user_name => :P26_USERNAME',
'                           , p_email_address => :P26_EMAIL',
'                           , p_web_password => :P26_PASS',
'                           , p_new_password => :P26_PASS',
'                           , p_account_locked => CASE :P26_USER_LOCKED WHEN ''Yes'' THEN ''Y'' ELSE ''N'' END',
'                           , p_change_password_on_first_use => ''Y''',
'                           );',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(141007121095073141)
,p_process_success_message=>'User updated'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(141008665212073167)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Reset Page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(141008333978073142)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(141009043187073167)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
