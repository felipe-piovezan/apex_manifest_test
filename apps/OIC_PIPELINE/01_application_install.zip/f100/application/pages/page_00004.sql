prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Confirm Next Step Pipeline'
,p_alias=>'CONFIRM-NEXT-PIPELINE'
,p_page_mode=>'MODAL'
,p_step_title=>'Confirm Next Step Pipeline'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(183981809851094792)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220802181750'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182165237624923361)
,p_plug_name=>'Confirm'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Integration <b>&P4_INTEGRATION_ID.</b> will be submitted to next step on pipeline.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14658777916207645)
,p_plug_name=>'Comments'
,p_parent_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(184005152652094806)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14656839867207626)
,p_name=>'Comments'
,p_parent_plug_id=>wwv_flow_imp.id(14658777916207645)
,p_template=>wwv_flow_imp.id(184010598600094810)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT apex_string.get_initials(created_by)   AS user_icon',
'     , ''u-color-'' || ORA_HASH(created_by, 45) AS icon_modifier',
'     , LOWER(created_by)                      AS user_name',
'     , text                                   AS comment_text',
'     , created_on                             AS comment_date',
'     , NULL                                   AS comment_modifiers',
'     , NULL                                   AS actions',
'     , NULL                                   AS attribute_1',
'     , NULL                                   AS attribute_2',
'     , NULL                                   AS attribute_3',
'     , NULL                                   AS attribute_4',
'FROM oic_pip_pipeline_comments',
'WHERE (pipeline_id = :P4_PIPELINE_ID)',
'  OR (:P4_PIPELINE_ID IS NULL AND integration_id = :P4_INTEGRATION_ID);'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P4_PIPELINE_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(184043502405094831)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14656944300207627)
,p_query_column_id=>1
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>10
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657098103207628)
,p_query_column_id=>2
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>20
,p_column_heading=>'Icon Modifier'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657125045207629)
,p_query_column_id=>3
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657273257207630)
,p_query_column_id=>4
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>40
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657384210207631)
,p_query_column_id=>5
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>50
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_default_sort_column_sequence=>1
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657489234207632)
,p_query_column_id=>6
,p_column_alias=>'COMMENT_MODIFIERS'
,p_column_display_sequence=>60
,p_column_heading=>'Comment Modifiers'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657567136207633)
,p_query_column_id=>7
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>70
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657679644207634)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>80
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657795100207635)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>90
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657864165207636)
,p_query_column_id=>10
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>100
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14657992411207637)
,p_query_column_id=>11
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>110
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182529930963017043)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P4_STATUS'
,p_plug_display_when_cond2=>'READY_TO_DEPLOY'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18809700035392184)
,p_plug_name=>'API Gateway (Target Environment)'
,p_parent_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM oic_pip_ints_downloaded int',
'   , oic_pip_projects next_proj',
'WHERE int.id = :P4_INTEGRATION_ID',
'  AND int.project_id = :P4_CURRENT_PROJ_ID',
'  AND int.pattern = ''Orchestration''',
'  AND oic_pip_pkg_utils.FNC_GET_NEXT_PROJECT_ID(int.project_id) = next_proj.id',
'  AND next_proj.has_gateway = ''Y'''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14658114349207639)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14656839867207626)
,p_button_name=>'ADD_COMMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Add Comment'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182165435821923363)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182277991753981043)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_button_name=>'Reject'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Reject'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P4_STATUS NOT IN (''WAITING_SUBMIT'', ''DONE'', ''REJECT'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182165379008923362)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10799922254064654)
,p_name=>'P4_ERROR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14658044808207638)
,p_name=>'P4_COMMENT_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14656839867207626)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comment'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18588315383815322)
,p_name=>'P4_TRACE_ON_PROMOTION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_prompt=>'Enable Trace on Promotion'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18809732181392185)
,p_name=>'P4_GW_DEPLOY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_prompt=>'Deploy on API Gateway?'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM oic_pip_ints_downloaded int',
'   , oic_pip_projects next_proj',
'WHERE int.id = :P4_INTEGRATION_ID',
'  AND int.project_id = :P4_CURRENT_PROJ_ID',
'  AND int.pattern = ''Orchestration''',
'  AND oic_pip_pkg_utils.FNC_GET_NEXT_PROJECT_ID(int.project_id) = next_proj.id',
'  AND next_proj.has_gateway = ''Y'''))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18810118759392188)
,p_name=>'P4_GW_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(18809700035392184)
,p_item_default=>'select max(displayname) from oic_pip_int_api_gateway_info where integration_id = :P4_INTEGRATION_ID AND project_id = :P4_CURRENT_PROJ_ID'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18810162680392189)
,p_name=>'P4_COMPARTMENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18809700035392184)
,p_item_default=>'select compartment_name from oic_pip_projects where id = oic_pip_pkg_utils.FNC_GET_NEXT_PROJECT_ID(:P4_CURRENT_PROJ_ID)'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Compartment'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18810240594392190)
,p_name=>'P4_GW_GATEWAY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18809700035392184)
,p_item_default=>'select apigws_displayname from oic_pip_projects where id = oic_pip_pkg_utils.FNC_GET_NEXT_PROJECT_ID(:P4_CURRENT_PROJ_ID)'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Gateway'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18810381237392191)
,p_name=>'P4_PATH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(18809700035392184)
,p_item_default=>'select max(pathprefix) from oic_pip_int_api_gateway_info where integration_id = :P4_INTEGRATION_ID AND project_id = :P4_CURRENT_PROJ_ID'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Path'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182165742304923366)
,p_name=>'P4_INTEGRATION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182165841847923367)
,p_name=>'P4_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182165960039923368)
,p_name=>'P4_CURRENT_PROJ_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182166039270923369)
,p_name=>'P4_USER_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182166138772923370)
,p_name=>'P4_PIPELINE_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(182165237624923361)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182569162788145097)
,p_name=>'P4_TARGET_STATUS'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_prompt=>'Target Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:CONFIGURED;CONFIGURED,ACTIVATED;ACTIVATED'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182569489569148164)
,p_name=>'P4_SCHEDULE_ON_PROMOTION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182529930963017043)
,p_prompt=>'Schedule on Promotion'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_display_when=>'select 1 from oic_pip_ints_downloaded where id = :P4_INTEGRATION_ID AND project_id = :P4_CURRENT_PROJ_ID AND pattern = ''Scheduled'''
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182165547178923364)
,p_name=>'NEXT_PIP_STEP'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(182165379008923362)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182166323798923371)
,p_event_id=>wwv_flow_imp.id(182165547178923364)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182165660177923365)
,p_event_id=>wwv_flow_imp.id(182165547178923364)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_int_downloads'';',
'',
'    l_in_execution      BOOLEAN;',
'    l_dummy             NUMBER;',
'BEGIN',
'',
'    :P4_ERROR := null;',
'',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'',
'    IF l_in_execution THEN',
'        :P4_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'        oic_pip_pkg_pipeline.prc_to_next_step(:P4_INTEGRATION_ID, :P4_STATUS, :P4_CURRENT_PROJ_ID, :P4_PIPELINE_ID,',
'                                          :P4_TARGET_STATUS, :P4_SCHEDULE_ON_PROMOTION, :P4_TRACE_ON_PROMOTION,',
'                                          :P4_GW_NAME, :P4_PATH);',
'    END IF;',
'EXCEPTION WHEN OTHERS THEN',
'    :P4_ERROR := SQLERRM;',
'END;'))
,p_attribute_02=>'P4_INTEGRATION_ID,P4_STATUS,P4_CURRENT_PROJ_ID,P4_PIPELINE_ID,P4_TARGET_STATUS,P4_SCHEDULE_ON_PROMOTION,P4_TRACE_ON_PROMOTION,P4_GW_NAME,P4_PATH,P4_ERROR'
,p_attribute_03=>'P4_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182166413258923372)
,p_event_id=>wwv_flow_imp.id(182165547178923364)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10475820525703424)
,p_event_id=>wwv_flow_imp.id(182165547178923364)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P4_ERROR.'
,p_attribute_02=>'Action Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P4_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182166493096923473)
,p_event_id=>wwv_flow_imp.id(182165547178923364)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182278771510981051)
,p_name=>'Reject'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(182277991753981043)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182278941670981053)
,p_event_id=>wwv_flow_imp.id(182278771510981051)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182278825430981052)
,p_event_id=>wwv_flow_imp.id(182278771510981051)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_pkg_pipeline.prc_reject(:P4_PIPELINE_ID, :P4_INTEGRATION_ID, :P4_CURRENT_PROJ_ID, :P4_STATUS);',
'END;'))
,p_attribute_02=>'P4_TARGET_STATUS,P4_SCHEDULE_ON_PROMOTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182279060167981054)
,p_event_id=>wwv_flow_imp.id(182278771510981051)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182279174992981055)
,p_event_id=>wwv_flow_imp.id(182278771510981051)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182530033308017044)
,p_name=>'Change'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_TARGET_STATUS'
,p_condition_element=>'P4_TARGET_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'ACTIVATED'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182530124589017045)
,p_event_id=>wwv_flow_imp.id(182530033308017044)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_SCHEDULE_ON_PROMOTION,P4_TRACE_ON_PROMOTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182530229985017046)
,p_event_id=>wwv_flow_imp.id(182530033308017044)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_SCHEDULE_ON_PROMOTION,P4_TRACE_ON_PROMOTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18809916951392186)
,p_event_id=>wwv_flow_imp.id(182530033308017044)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_GW_DEPLOY'
,p_server_condition_type=>'EXISTS'
,p_server_condition_expr1=>'select 1 from oic_pip_ints_downloaded where id = :P4_INTEGRATION_ID AND project_id = :P4_CURRENT_PROJ_ID AND pattern = ''Orchestration'''
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18809954192392187)
,p_event_id=>wwv_flow_imp.id(182530033308017044)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_GW_DEPLOY'
,p_server_condition_type=>'EXISTS'
,p_server_condition_expr1=>'select 1 from oic_pip_ints_downloaded where id = :P4_INTEGRATION_ID AND project_id = :P4_CURRENT_PROJ_ID AND pattern = ''Orchestration'''
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18810502723392192)
,p_name=>'Change_GW'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_GW_DEPLOY'
,p_condition_element=>'P4_GW_DEPLOY'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18810531910392193)
,p_event_id=>wwv_flow_imp.id(18810502723392192)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(18809700035392184)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18810626914392194)
,p_event_id=>wwv_flow_imp.id(18810502723392192)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(18809700035392184)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14658249907207640)
,p_name=>'Add Comment'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14658114349207639)
,p_condition_element=>'P4_COMMENT_TEXT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14658325073207641)
,p_event_id=>wwv_flow_imp.id(14658249907207640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    INSERT INTO oic_pip_pipeline_comments ( created_by',
'                                          , text',
'                                          , created_on',
'                                          , pipeline_id',
'                                          , integration_id)',
'    VALUES ( v(''APP_USER'')',
'           , :P4_COMMENT_TEXT',
'           , SYSTIMESTAMP',
'           , :P4_PIPELINE_ID',
'           , :P4_INTEGRATION_ID);',
'    COMMIT;',
'END;'))
,p_attribute_02=>'P4_COMMENT_TEXT,P4_PIPELINE_ID,P4_INTEGRATION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14658497560207642)
,p_event_id=>wwv_flow_imp.id(14658249907207640)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14656839867207626)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14658597825207643)
,p_event_id=>wwv_flow_imp.id(14658249907207640)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_COMMENT_TEXT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14658611888207644)
,p_event_id=>wwv_flow_imp.id(14658249907207640)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_COMMENT_TEXT'
);
wwv_flow_imp.component_end;
end;
/
