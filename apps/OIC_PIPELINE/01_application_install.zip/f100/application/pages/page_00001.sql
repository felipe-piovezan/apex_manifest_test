prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'OIC_PIPELINE'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'13'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220531232133'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(181931801823777085)
,p_plug_name=>'Last Sync Date'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_05'
,p_plug_source=>'Last Sync in &P1_LAST_SYNC.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184121177563094891)
,p_plug_name=>'OIC PIPELINE'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184012542622094811)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184292815571317438)
,p_plug_name=>'Envs'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC:t-Form--stretchInputs:margin-top-md:margin-bottom-md:margin-left-lg:margin-right-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(183996957676094802)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'OIC_PIP_VW_PIPELINE_ENV'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1=1',
'--pipeline_id IN ( SELECT t.column_value AS int_id FROM TABLE (apex_string.split(RTRIM(LTRIM(:P1_NEW_1, '':''), '':''), '':'')) t) OR :P1_NEW_1 IS NULL'))
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(184292848957317439)
,p_region_id=>wwv_flow_imp.id(184292815571317438)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title ">&PROJECT.</h3> '
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'STATUS'
,p_body_adv_formatting=>false
,p_body_column_name=>'TOTAL_INTS_ACTIVATED'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'ACL_WARNING'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'TASK_NAME'
,p_icon_position=>'START'
,p_badge_column_name=>'PIPELINE_ORDER'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(184336881732694847)
,p_card_id=>wwv_flow_imp.id(184292848957317439)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_PROJECT_ID:&ID.'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(150358929096183558)
,p_card_id=>wwv_flow_imp.id(184292848957317439)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'Edit Env'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::P13_ID,P13_SOURCE:&ID.,1'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-folder-edit'
,p_is_hot=>false
,p_authorization_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(150358009089183549)
,p_card_id=>wwv_flow_imp.id(184292848957317439)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Sync Env'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::P25_PROJECT_ID:&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-refresh'
,p_is_hot=>false
,p_authorization_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184292684618317437)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184121177563094891)
,p_button_name=>'SyncAll'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sync All'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(140936723907216338)
,p_branch_name=>'Go To Page 28'
,p_branch_action=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'FUNCTION_BODY'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_dummy NUMBER;',
'    l_found BOOLEAN;',
'    l_ret   BOOLEAN := FALSE;',
'    ',
'    -- cur_remote_credential',
'    CURSOR cur_remote_credential IS',
'        SELECT 1',
'        FROM apex_workspace_credentials',
'        WHERE static_id = ''BITBUCKT_CREDENTIAL'';',
'    ',
'    -- cur_remote_config',
'    CURSOR cur_remote_config IS',
'        SELECT 1',
'        FROM user_objects',
'        WHERE object_name = ''OIC_PIP_REMOTE_UPDATE_CONF'';',
'    ',
'BEGIN',
'    OPEN cur_remote_credential;',
'    FETCH cur_remote_credential INTO l_dummy;',
'    l_found := cur_remote_credential%FOUND;',
'    CLOSE cur_remote_credential;',
'    ',
'    IF NOT (l_found) THEN',
'        l_ret := TRUE;',
'    ELSE',
'        OPEN cur_remote_config;',
'        FETCH cur_remote_config INTO l_dummy;',
'        l_found := cur_remote_config%FOUND;',
'        CLOSE cur_remote_config;',
'        ',
'        IF NOT (l_found) THEN',
'            l_ret := TRUE;',
'        END IF;',
'    END IF;',
'    ',
'    RETURN l_ret;',
'END;'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140679506195060432)
,p_name=>'P1_CHECK_UPDATES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(184121177563094891)
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142606671617357838)
,p_name=>'P1_PROGRESS_BAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(181931801823777085)
,p_source=>'oic_pip_pkg_progress.fnc_get(null, 1)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''35px'';',
'}'))
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#0063ce'
,p_attribute_05=>'#a6d1ff'
,p_attribute_07=>'linear'
,p_attribute_08=>'4500'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'add-timer'
,p_attribute_12=>'3500'
,p_attribute_13=>'progress-is-complete'
,p_attribute_15=>'P1_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(181931883716777086)
,p_name=>'P1_LAST_SYNC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(181931801823777085)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'SELECT TO_CHAR(MAX(apex$row_sync_timestamp), ''DD-MM-YYYY HH24:MI:SS'') LAST_SYNC FROM oic_pip_rest_ds_integration;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(184337250968694851)
,p_name=>'SyncAll'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(184292684618317437)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44144732012089123)
,p_event_id=>wwv_flow_imp.id(184337250968694851)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PROGRESS_BAR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P1_PROGRESS_BAR'');',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44144782588089124)
,p_event_id=>wwv_flow_imp.id(184337250968694851)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148708220089163)
,p_event_id=>wwv_flow_imp.id(184337250968694851)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(184292684618317437)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184337410274694852)
,p_event_id=>wwv_flow_imp.id(184337250968694851)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_prc_auto_int_downloads(p_page_progress_bar => 1);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150354945430183518)
,p_name=>'Initialize Drag and Drop'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150355007553183519)
,p_event_id=>wwv_flow_imp.id(150354945430183518)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.DRAG_AND_DROP_LIST'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(184292815571317438)
,p_attribute_01=>'sort'
,p_attribute_02=>'plsql'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_prc_env_reorder(:AFTER_SEQUENCE);',
'END;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150355118184183520)
,p_name=>'Refresh'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(184292815571317438)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.DRAG_AND_DROP_LIST|DYNAMIC ACTION|fos-enabledraganddrop-update-complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150355249317183521)
,p_event_id=>wwv_flow_imp.id(150355118184183520)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140679988949060437)
,p_name=>'CHECK_UPDATE_NOTIFICATION'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM oic_pip_check_update',
'WHERE session_id = apex_custom_auth.get_session_id;'))
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140931887638216290)
,p_event_id=>wwv_flow_imp.id(140679988949060437)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'info'
,p_attribute_02=>'static'
,p_attribute_03=>'New version Available!'
,p_attribute_04=>'Go to administration page to update'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-button'
,p_attribute_08=>'bottom-right'
,p_attribute_09=>'Y'
,p_attribute_10=>'fa-arrow-circle-down'
,p_attribute_11=>'8'
,p_attribute_13=>'warning'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'oic_pip_pkg_application.has_remote_update_available()'
,p_server_condition_expr2=>'PLSQL'
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134972644772904200)
,p_event_id=>wwv_flow_imp.id(140679988949060437)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE oic_pip_check_update',
'    WHERE session_id = apex_custom_auth.get_session_id;',
'    COMMIT;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44144927858089125)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44147130786089147)
,p_event_id=>wwv_flow_imp.id(44144927858089125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(null, 1);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44146336529089139)
,p_event_id=>wwv_flow_imp.id(44144927858089125)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44145332919089129)
,p_name=>'INIT_PROGRESS_BAR'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44146463137089141)
,p_event_id=>wwv_flow_imp.id(44145332919089129)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44145242673089128)
,p_event_id=>wwv_flow_imp.id(44145332919089129)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PROGRESS_BAR'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'oic_pip_pkg_progress.fnc_get(null, 1)'
,p_attribute_07=>'P1_PROGRESS_BAR'
,p_attribute_08=>'Y'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44146167668089138)
,p_event_id=>wwv_flow_imp.id(44145332919089129)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PROGRESS_BAR'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P1_PROGRESS_BAR'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44146683102089143)
,p_event_id=>wwv_flow_imp.id(44145332919089129)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P1_PROGRESS_BAR'');',
'let value = item.getValue();',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P1_PROGRESS_BAR'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44147416437089150)
,p_name=>'Dialog_closed'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(184292815571317438)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44147514320089151)
,p_event_id=>wwv_flow_imp.id(44147416437089150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(184292815571317438)
);
wwv_flow_imp.component_end;
end;
/
