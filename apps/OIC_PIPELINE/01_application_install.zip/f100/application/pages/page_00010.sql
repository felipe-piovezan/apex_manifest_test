prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Snapshot'
,p_alias=>'SNAPSHOT'
,p_step_title=>'Snapshot'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'04'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220401004504'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(183448690017123632)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(183453473981123653)
,p_plug_name=>'Integration Lifetime'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(183453885045123653)
,p_region_id=>wwv_flow_imp.id(183453473981123653)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(183455550450123656)
,p_chart_id=>wwv_flow_imp.id(183453885045123653)
,p_seq=>10
,p_name=>'Environments'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT proj_name label',
'     , SUM(qtd_int) value',
'     , project_id',
'FROM ( SELECT COUNT(1)                                           qtd_int',
'            , oic_pip_pkg_utils.fnc_get_project_name(project_id) proj_name',
'            , project_id',
'       FROM oic_pip_ints_downloaded b',
'       WHERE TO_DATE( :P10_TIME, ''DD-MM-YYYY HH24:MI:SS'') > b.creation_date',
'         AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'         AND NOT EXISTS(SELECT NULL',
'                        FROM oic_pip_ints_downloaded_hist a',
'                        WHERE a.id = b.id',
'                          AND a.project_id = b.project_id',
'                          AND TO_DATE( :P10_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN a.last_updated_date AND a.execution_date',
'                          )',
'       GROUP BY project_id',
'       UNION',
'       SELECT COUNT(1)                                           qtd_int',
'            , oic_pip_pkg_utils.fnc_get_project_name(project_id) proj_name',
'            , project_id',
'       FROM oic_pip_ints_downloaded_hist a',
'       WHERE TO_DATE( :P10_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN last_updated_date AND execution_date',
'         AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'       GROUP BY project_id',
'     )',
'GROUP BY proj_name, project_id;'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P10_TIME'
,p_series_name_column_name=>'LABEL'
,p_items_value_column_name=>'VALUE'
,p_items_z_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'VALUE'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::P11_PROJECT_ID,P11_TIME:&PROJECT_ID.,&P10_TIME.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(183454367765123654)
,p_chart_id=>wwv_flow_imp.id(183453885045123653)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(183440212023992750)
,p_chart_id=>wwv_flow_imp.id(183453885045123653)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(183454983158123655)
,p_chart_id=>wwv_flow_imp.id(183453885045123653)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Number of Integration'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(183442211616992770)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(183448690017123632)
,p_button_name=>'Backup'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate Backup'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cloud-arrow-down'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137269158165646535)
,p_name=>'FILE_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(183453473981123653)
,p_source=>'SNAPSHOT_BKP'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183439894193992747)
,p_name=>'P10_TIME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(183453473981123653)
,p_prompt=>'Time in History'
,p_format_mask=>'DD-MM-YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(183439980726992748)
,p_name=>'Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_TIME'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183440079618992749)
,p_event_id=>wwv_flow_imp.id(183439980726992748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(183453473981123653)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(183443787347992786)
,p_name=>'GenerateBkp'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(183442211616992770)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183532573442213541)
,p_event_id=>wwv_flow_imp.id(183443787347992786)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183532178304213537)
,p_event_id=>wwv_flow_imp.id(183443787347992786)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'oic_pip_prc_generate_snapshot_bkp(TO_DATE( :P10_TIME, ''DD-MM-YYYY HH24:MI:SS''));',
'END;'))
,p_attribute_02=>'P10_TIME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183532702759213542)
,p_event_id=>wwv_flow_imp.id(183443787347992786)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183533515671213550)
,p_event_id=>wwv_flow_imp.id(183443787347992786)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'url = ''f?p=&APP_ID.:10:&APP_SESSION.:APPLICATION_PROCESS=DOWNLOAD_BLOB:::FILE_TYPE:&FILE_TYPE.''',
'window.open(url).focus();'))
);
wwv_flow_imp.component_end;
end;
/
