prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Environment'
,p_alias=>'ENVIRONMENT'
,p_step_title=>'Environment'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220802142531'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184294958977317460)
,p_plug_name=>'Environment Details'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'TABLE'
,p_query_table=>'OIC_PIP_PROJECTS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46652203451492853)
,p_plug_name=>'API Gateway Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>160
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151542062385231025)
,p_plug_name=>'Credential'
,p_parent_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>140
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151542284802231027)
,p_plug_name=>'Credential Created'
,p_parent_plug_id=>wwv_flow_imp.id(151542062385231025)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM apex_workspace_credentials',
'WHERE static_id = :P13_ID'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151542484071231029)
,p_plug_name=>'Credential NOT Created'
,p_parent_plug_id=>wwv_flow_imp.id(151542062385231025)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM apex_workspace_credentials',
'WHERE static_id = :P13_ID'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182055322743962086)
,p_plug_name=>'ACL'
,p_parent_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P13_ACL_GRANTED'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ACL NOT GRANTED TO THIS ENVIRONMENT!!!',
'<br>',
'Please, after create the credential, test the ACL connection.',
'<br><br>'))
,p_plug_footer=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<br>',
'If you are using an ATP with "Access Type:',
' Allow secure access from everywhere", you just need to test the ACL connection. Otherwise, you will need to execute the ALC_GRANT.sql script with ADMIN database user rigths.'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184309585524439964)
,p_plug_name=>'Environment'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11515735600906719)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182055322743962086)
,p_button_name=>'Test_ACL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Test Acl'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46653227403492863)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(46652203451492853)
,p_button_name=>'Test'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Test Connection'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184294777718317458)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(184309585524439964)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_condition=>'P13_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184294601824317456)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(184309585524439964)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11503226854806244)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(151542284802231027)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Delete Credential'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184294916222317459)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184309585524439964)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Environment'
,p_button_position=>'CREATE'
,p_button_condition=>'P13_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11503901608806246)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(151542484071231029)
,p_button_name=>'Create'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Credential'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184294689218317457)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(184309585524439964)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>'Are you sure you want to delete this environment? This will erase all data linked to that environment.'
,p_confirm_style=>'danger'
,p_button_condition=>'P13_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(140678791676060425)
,p_branch_name=>'Go to Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P13_SOURCE'
,p_branch_condition_text=>'1'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(181927609840777043)
,p_branch_name=>'Go To Page 2'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P13_SOURCE'
,p_branch_condition_text=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11516548605906727)
,p_name=>'P13_ACL_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182055322743962086)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46652647996492857)
,p_name=>'P13_HAS_GATEWAY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Configure API Gateway for this environment?'
,p_source=>'HAS_GATEWAY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46652683233492858)
,p_name=>'P13_COMPARTMENT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(46652203451492853)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Compartment Name'
,p_source=>'COMPARTMENT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>70
,p_cMaxlength=>600
,p_field_template=>wwv_flow_imp.id(184083366914094858)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46652824465492859)
,p_name=>'P13_APIGWS_DISPLAYNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(46652203451492853)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'API Gateway Name'
,p_source=>'APIGWS_DISPLAYNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>70
,p_cMaxlength=>600
,p_field_template=>wwv_flow_imp.id(184083366914094858)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46653524588492866)
,p_name=>'P13_CHECK_GATEWAY'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140678904192060426)
,p_name=>'P13_SOURCE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(184309585524439964)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150355476190183524)
,p_name=>'P13_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182055099395962084)
,p_name=>'P13_ACL_GRANTED'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_source=>'ACL_GRANTED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182101796398836741)
,p_name=>'P13_ROLES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Roles'
,p_source=>'ROLES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_LIST_MANAGER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT role_name',
'     , role_static_id',
'  FROM apex_appl_acl_roles',
'  WHERE role_static_id <> ''OIC_PIPELINE_DEVELOPER'';'))
,p_field_template=>wwv_flow_imp.id(184083366914094858)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'FIRST_ROWSET'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184295195810317462)
,p_name=>'P13_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184295299882317463)
,p_name=>'P13_ROW_VERSION_NUMBER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_source=>'ROW_VERSION_NUMBER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184295348186317464)
,p_name=>'P13_PROJECT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Environment Name'
,p_source=>'PROJECT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184295468997317465)
,p_name=>'P13_TASK_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Task'
,p_source=>'TASK_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184295536204317466)
,p_name=>'P13_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_default=>'OPEN'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Open;OPEN,Closed;CLOSED,Only Integration Sync;ONLY_INTEGRATION_SYNC'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Open - Synchronize All</p>',
'<p>Closed - Synchronize nothing</p>',
'<p>Only Integration Sync - Synchronize integrations, but not schedule details</p>'))
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184296907357317479)
,p_name=>'P13_OIC_HOST_ENV'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Host OIC'
,p_source=>'OIC_HOST_ENV'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>70
,p_cMaxlength=>300
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'https://&ltoic-host&gt/'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184296947171317480)
,p_name=>'P13_PIPELINE_ORDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_item_source_plug_id=>wwv_flow_imp.id(184294958977317460)
,p_prompt=>'Pipeline Order'
,p_source=>'PIPELINE_ORDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>1
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184297055841317481)
,p_name=>'P13_USER_OIC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(151542484071231029)
,p_prompt=>'User OIC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'You need to create the environment record before the credential.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184297128006317482)
,p_name=>'P13_PASS_OIC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(151542484071231029)
,p_prompt=>'Pass OIC'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(184083631779094859)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(181927666020777044)
,p_validation_name=>'Valid_Host'
,p_validation_sequence=>10
,p_validation=>'oic_pip_fnc_valid_proj_host(:P13_OIC_HOST_ENV)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Host Pattern not recognized. Please, Correct.'
,p_associated_item=>wwv_flow_imp.id(184296907357317479)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46652283388492854)
,p_name=>'Change_gateway'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_HAS_GATEWAY'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46652404953492855)
,p_event_id=>wwv_flow_imp.id(46652283388492854)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46652203451492853)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P13_HAS_GATEWAY'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46652466647492856)
,p_event_id=>wwv_flow_imp.id(46652283388492854)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46652203451492853)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P13_HAS_GATEWAY'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46653267131492864)
,p_name=>'TestCon'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46653227403492863)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46653408067492865)
,p_event_id=>wwv_flow_imp.id(46653267131492864)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR cur_proj IS',
'        SELECT id',
'             , row_version_number',
'             , project',
'             , task_name',
'             , status',
'             , created_by',
'             , icon_name',
'             , icon_comments',
'             , icon_blob',
'             , icon_mimetype',
'             , icon_charset',
'             , icon_last_updated',
'             , oic_host_env',
'             , pipeline_order',
'             , user_oic',
'             , pass_oic',
'             , acl_granted',
'             , roles',
'             , has_gateway',
'             , compartment_name',
'             , apigws_displayname',
'        FROM oic_pip_projects a',
'        WHERE id = :P13_ID;',
'    vr_proj          CUR_PROJ%ROWTYPE;',
'    l_compartment_id VARCHAR2(600);',
'    l_apigws_id      VARCHAR2(600);',
'',
'BEGIN',
'    OPEN cur_proj;',
'    FETCH cur_proj INTO vr_proj;',
'    CLOSE cur_proj;',
'    ',
'    l_compartment_id := oic_pip_pkg_int_interface.fnc_get_gateway_compartment_id(vr_proj);',
'    IF l_compartment_id IS NOT NULL THEN',
'        l_apigws_id := oic_pip_pkg_int_interface.fnc_get_gateway_apigws_id(vr_proj,l_compartment_id);',
'        IF l_apigws_id IS NOT NULL THEN',
'            :P13_CHECK_GATEWAY := ''Y'';',
'        ELSE',
'            :P13_CHECK_GATEWAY := ''Error fnc_get_gateway_apigws_id.'';',
'        END IF;',
'    ELSE',
'        :P13_CHECK_GATEWAY := ''Error fnc_get_gateway_compartment_id.'';',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN :P13_CHECK_GATEWAY := SQLERRM;',
'END;'))
,p_attribute_02=>'P13_ID,P13_CHECK_GATEWAY'
,p_attribute_03=>'P13_ID,P13_CHECK_GATEWAY'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46653592092492867)
,p_event_id=>wwv_flow_imp.id(46653267131492864)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_04=>'Gateway Configuration works fine!'
,p_attribute_08=>'top-right'
,p_attribute_09=>'N'
,p_attribute_11=>'10'
,p_attribute_13=>'warning'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P13_CHECK_GATEWAY'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46653681562492868)
,p_event_id=>wwv_flow_imp.id(46653267131492864)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'error'
,p_attribute_02=>'static'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Gateway Configuration error! Check the configuration.',
'&P13_CHECK_GATEWAY.'))
,p_attribute_08=>'top-right'
,p_attribute_09=>'N'
,p_attribute_11=>'10'
,p_attribute_12=>'P13_CHECK_GATEWAY'
,p_attribute_13=>'warning'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P13_CHECK_GATEWAY'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11513927349906701)
,p_name=>'create_credential'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11503901608806246)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514069824906702)
,p_event_id=>wwv_flow_imp.id(11513927349906701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_pkg_utils.prc_create_oic_credential(:P13_ID, :P13_USER_OIC, :P13_PASS_OIC);',
'END;'))
,p_attribute_02=>'P13_ID,P13_USER_OIC,P13_PASS_OIC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514679171906708)
,p_event_id=>wwv_flow_imp.id(11513927349906701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_SOURCE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514413632906706)
,p_event_id=>wwv_flow_imp.id(11513927349906701)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11514172492906703)
,p_name=>'delete_creadential'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11503226854806244)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514273716906704)
,p_event_id=>wwv_flow_imp.id(11514172492906703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  oic_pip_pkg_utils.prc_delete_oic_credential(:P13_ID);',
'END;'))
,p_attribute_02=>'P13_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11517252525906734)
,p_event_id=>wwv_flow_imp.id(11514172492906703)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE oic_pip_projects',
'SET acl_granted = null',
'WHERE id = :P13_ID;'))
,p_attribute_02=>'P13_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514778631906709)
,p_event_id=>wwv_flow_imp.id(11514172492906703)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_SOURCE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514322066906705)
,p_event_id=>wwv_flow_imp.id(11514172492906703)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11514810451906710)
,p_name=>'user_oic_start'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_USER_OIC'
,p_condition_element=>'P13_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11515013527906712)
,p_event_id=>wwv_flow_imp.id(11514810451906710)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_USER_OIC'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11514902487906711)
,p_event_id=>wwv_flow_imp.id(11514810451906710)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_USER_OIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11515108852906713)
,p_name=>'pass_oic_start'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_PASS_OIC'
,p_condition_element=>'P13_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11515252006906714)
,p_event_id=>wwv_flow_imp.id(11515108852906713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_PASS_OIC'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11515344974906715)
,p_event_id=>wwv_flow_imp.id(11515108852906713)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_PASS_OIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11515437943906716)
,p_name=>'start_create_btn'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11503901608806246)
,p_condition_element=>'P13_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11515588806906717)
,p_event_id=>wwv_flow_imp.id(11515437943906716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11503901608806246)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11515652242906718)
,p_event_id=>wwv_flow_imp.id(11515437943906716)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11503901608806246)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11516170675906723)
,p_name=>'start_acl_btn'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11515735600906719)
,p_bind_type=>'bind'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516227079906724)
,p_event_id=>wwv_flow_imp.id(11516170675906723)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11515735600906719)
,p_server_condition_type=>'NOT_EXISTS'
,p_server_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM apex_workspace_credentials',
'WHERE static_id = :P13_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11516389245906725)
,p_name=>'test_acl_click'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11515735600906719)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516449390906726)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P13_ACL_STATUS := oic_pip_pkg_int_interface.prc_test_connection(:P13_ID);',
'END;'))
,p_attribute_02=>'P13_ID,P13_ACL_STATUS'
,p_attribute_03=>'P13_ACL_STATUS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516680901906728)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Connection successfully established'
,p_attribute_02=>'Success'
,p_attribute_03=>'success'
,p_client_condition_type=>'IN_LIST'
,p_client_condition_element=>'P13_ACL_STATUS'
,p_client_condition_expression=>'200, 204'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516865214906730)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE oic_pip_projects',
'SET acl_granted = ''Y''',
'WHERE id = :P13_ID;'))
,p_attribute_02=>'P13_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'IN_LIST'
,p_client_condition_element=>'P13_ACL_STATUS'
,p_client_condition_expression=>'200,204'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516714831906729)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Connection not established.',
'<br>',
'&P13_ACL_STATUS.'))
,p_attribute_02=>'Error'
,p_attribute_03=>'danger'
,p_client_condition_type=>'NOT_IN_LIST'
,p_client_condition_element=>'P13_ACL_STATUS'
,p_client_condition_expression=>'200, 204'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11516974908906731)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE oic_pip_projects',
'SET acl_granted = null',
'WHERE id = :P13_ID;'))
,p_attribute_02=>'P13_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_IN_LIST'
,p_client_condition_element=>'P13_ACL_STATUS'
,p_client_condition_expression=>'200,204'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11517146146906733)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_SOURCE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11517039757906732)
,p_event_id=>wwv_flow_imp.id(11516389245906725)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7833384187954804)
,p_name=>'Delete Env'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(184294689218317457)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7833456219954805)
,p_event_id=>wwv_flow_imp.id(7833384187954804)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7833652014954807)
,p_event_id=>wwv_flow_imp.id(7833384187954804)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_project_id NUMBER := :P13_ID;',
'',
'BEGIN',
'    /***************',
'        PIPELINE',
'    ****************/',
'    DELETE oic_pip_int_pipeline_msgs',
'    WHERE project_id = l_project_id;',
'',
'    UPDATE oic_pip_int_pipeline',
'    SET current_project_id = NULL',
'    WHERE current_project_id = l_project_id;',
'',
'    /***************',
'        LOOKUP',
'    ****************/',
'',
'    DELETE oic_pip_lookup_rows',
'    WHERE lookup_header_id IN ( SELECT lookup_header_id',
'                                FROM oic_pip_lookup_header',
'                                WHERE project_id = l_project_id',
'                              );',
'',
'    DELETE oic_pip_lookup_columns',
'    WHERE lookup_header_id IN ( SELECT lookup_header_id',
'                                FROM oic_pip_lookup_header',
'                                WHERE project_id = l_project_id',
'                              );',
'',
'    DELETE oic_pip_lookup_file',
'    WHERE lookup_header_id IN ( SELECT lookup_header_id',
'                                FROM oic_pip_lookup_header',
'                                WHERE project_id = l_project_id',
'                              );',
'',
'    DELETE oic_pip_lookup_header',
'    WHERE project_id = l_project_id;',
'',
'    DELETE oic_pip_lkps_usage',
'    WHERE project_id = l_project_id;',
'',
'    /***************',
'        PACKAGES',
'    ****************/',
'    DELETE oic_pip_rest_ds_package',
'    WHERE project_id = l_project_id;',
'',
'    DELETE oic_pip_pkgs_downloaded',
'    WHERE project_id = l_project_id;',
'',
'    /***************',
'       INTEGRATION',
'    ****************/',
'    DELETE oic_pip_rest_ds_integration',
'    WHERE project_id = l_project_id;',
'',
'    DELETE oic_pip_ints_downloaded',
'    WHERE project_id = l_project_id;',
'',
'    DELETE oic_pip_ints_downloaded_hist',
'    WHERE project_id = l_project_id;',
'',
'    /***************',
'           GW',
'    ****************/',
'    DELETE oic_pip_int_api_gateway_info',
'    WHERE project_id = l_project_id;',
'',
'    /***************',
'          ENV',
'    ****************/',
'    ',
'    oic_pip_pkg_utils.prc_delete_oic_credential(:P13_ID);',
'',
'    DELETE oic_pip_projects',
'    WHERE id = l_project_id;',
'',
'    COMMIT;',
'    :P13_SOURCE := 2;',
'END;'))
,p_attribute_02=>'P13_ID'
,p_attribute_03=>'P13_SOURCE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7833539712954806)
,p_event_id=>wwv_flow_imp.id(7833384187954804)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7833761212954808)
,p_event_id=>wwv_flow_imp.id(7833384187954804)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(181927449133777042)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'After delete'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(184294689218317457)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184295095348317461)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(184294958977317460)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Project'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184297346859317484)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_region_id=>wwv_flow_imp.id(184294958977317460)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Fetch'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
