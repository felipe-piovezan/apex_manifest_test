prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Confirm Promotion'
,p_alias=>'CONFIRM-PROMOTION'
,p_page_mode=>'MODAL'
,p_step_title=>'Confirm Promotion'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(184111529044094880)
,p_dialog_chained=>'N'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220607134623'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182051905580962052)
,p_plug_name=>'Integration Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160419761708933890)
,p_plug_name=>'active_schedule_in_target'
,p_parent_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'There is an active integration running on target environment (&P9_INT_TARGET_SCH_ACTIVATED.)'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT int.name || '' '' || int.version',
'FROM oic_pip_ints_downloaded int',
'   , oic_pip_projects proj',
'WHERE int.pattern = ''Scheduled''',
'  AND int.schedule_status = ''Activated''',
'  AND int.name = :P9_INT_SOURCE',
'  AND int.project_id = proj.id',
'  AND  proj.project = :P9_ENV_TARGET'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182053843125962072)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182053815139962071)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10475630186703422)
,p_name=>'P9_ERROR'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18588021831815319)
,p_name=>'P9_TRACE_ON_PROMOTION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Enable Tracing on Promotion'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160419843468933891)
,p_name=>'P9_INT_TARGET_SCH_ACTIVATED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(160419761708933890)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT int.name || '' '' || int.version',
'FROM oic_pip_ints_downloaded int',
'   , oic_pip_projects proj',
'WHERE int.pattern = ''Scheduled''',
'  AND int.schedule_status = ''Activated''',
'  AND int.name = :P9_INT_SOURCE',
'  AND int.project_id = proj.id',
'  AND  proj.project = :P9_ENV_TARGET'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182051927935962053)
,p_name=>'P9_ENV_SOURCE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Environment Source'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052112852962054)
,p_name=>'P9_ENV_TARGET'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Environment Target'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052302588962056)
,p_name=>'P9_INT_SOURCE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Integration Source'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052381370962057)
,p_name=>'P9_INT_TARGET'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Integration Target'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P9_INT_TARGET'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052488891962058)
,p_name=>'P9_INT_SOURCE_VERSION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Integration Version Source'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052710328962060)
,p_name=>'P9_INT_TARGET_VERSION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Integration Version Target'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P9_INT_TARGET_VERSION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052759702962061)
,p_name=>'P9_INT_SOURCE_STATUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Source Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182052900858962062)
,p_name=>'P9_INT_TARGET_STATUS'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Target Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:CONFIGURED;CONFIGURED,ACTIVATED;ACTIVATED'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182053005598962063)
,p_name=>'P9_INT_PATTERN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182053109729962064)
,p_name=>'P9_INT_TASK_FROM'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182053171352962065)
,p_name=>'P9_INT_TASK_TO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182053316144962066)
,p_name=>'P9_PROJECT_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182053324938962067)
,p_name=>'P9_SCHEDULE_ON_PROMOTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(182051905580962052)
,p_prompt=>'Schedule on Promotion'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_display_when=>'P9_INT_PATTERN'
,p_display_when2=>'Scheduled'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182053436306962068)
,p_name=>'Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_INT_TARGET_STATUS'
,p_condition_element=>'P9_INT_TARGET_STATUS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'ACTIVATED'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182053582401962069)
,p_event_id=>wwv_flow_imp.id(182053436306962068)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_SCHEDULE_ON_PROMOTION,P9_TRACE_ON_PROMOTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182053707446962070)
,p_event_id=>wwv_flow_imp.id(182053436306962068)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_SCHEDULE_ON_PROMOTION,P9_TRACE_ON_PROMOTION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(182053959520962073)
,p_name=>'Promote'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(182053843125962072)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054089822962074)
,p_event_id=>wwv_flow_imp.id(182053959520962073)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054254435962076)
,p_event_id=>wwv_flow_imp.id(182053959520962073)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_int_downloads'';',
'    l_in_execution BOOLEAN;',
'    l_dummy        NUMBER;',
'    l_erro         oic_pip_pkg_int_interface.INTERFACE_ERROR;',
'',
'BEGIN',
'    :P9_ERROR := NULL;',
'    ',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'    ',
'    IF l_in_execution THEN',
'        :P9_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'        oic_pip_prc_confirm_promotion(l_erro, :P9_INT_SOURCE, :P9_INT_SOURCE_VERSION, :P9_INT_TARGET_STATUS,',
'                                      :P9_SCHEDULE_ON_PROMOTION, :P9_INT_TASK_FROM, :P9_INT_TASK_TO,',
'                                      :P9_TRACE_ON_PROMOTION);',
'        IF l_erro.code IS NOT NULL THEN',
'            :P9_ERROR := l_erro.detail || '' - '' || l_erro.code;',
'        END IF;',
'    END IF;',
'EXCEPTION WHEN OTHERS THEN',
'    :P9_ERROR := SQLERRM;',
'END;'))
,p_attribute_02=>'P9_INT_SOURCE,P9_INT_SOURCE_VERSION,P9_INT_TARGET_VERSION,P9_INT_TARGET_STATUS,P9_SCHEDULE_ON_PROMOTION,P9_INT_TASK_FROM,P9_INT_TASK_TO,P9_TRACE_ON_PROMOTION,P9_ERROR'
,p_attribute_03=>'P9_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054333850962077)
,p_event_id=>wwv_flow_imp.id(182053959520962073)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10475707624703423)
,p_event_id=>wwv_flow_imp.id(182053959520962073)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P9_ERROR.'
,p_attribute_02=>'Promote Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(182054460601962078)
,p_event_id=>wwv_flow_imp.id(182053959520962073)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P9_PROJECT_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(160419997091933892)
,p_name=>'Change_Field'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_SCHEDULE_ON_PROMOTION'
,p_condition_element=>'P9_INT_TARGET_SCH_ACTIVATED'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(160420110327933893)
,p_event_id=>wwv_flow_imp.id(160419997091933892)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(160419761708933890)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(160420236305933894)
,p_event_id=>wwv_flow_imp.id(160419997091933892)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(160419761708933890)
);
wwv_flow_imp.component_end;
end;
/
