prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'3. Install - Finished'
,p_alias=>'3-INSTALL-FINISHED'
,p_step_title=>'3. Install - Finished'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_page_component_map=>'17'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220531214600'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142594119013170588)
,p_plug_name=>'3. Install - Finished'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(184032613546094824)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(142585931375170577)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184081847704094857)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142594188295170588)
,p_plug_name=>'3. Install - Finished'
,p_parent_plug_id=>wwv_flow_imp.id(142594119013170588)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(183993785181094800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20297267523813821)
,p_plug_name=>'Completed'
,p_parent_plug_id=>wwv_flow_imp.id(142594188295170588)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>30
,p_plug_source=>'Install completed! <span class="fa fa-check-circle" aria-hidden="true" style="padding-left:10px;"></span>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(142596033009170590)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(142594119013170588)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(142596085666170590)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(142594119013170588)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184083948638094859)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(142597597014170592)
,p_branch_name=>'Go To Page OIC_PIP_HML'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(142596899858170591)
,p_branch_name=>'Go To Page 34'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::P34_BITBUCKET_PASS:&P35_BITBUCKET_PASS.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(142596085666170590)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20618765518951814)
,p_name=>'P35_PROGRESS_BAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(142594188295170588)
,p_item_default=>'0'
,p_pre_element_text=>'Finishing and validating the installation'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''20px'';',
'}'))
,p_attribute_01=>'circle'
,p_attribute_03=>'solid'
,p_attribute_04=>'#4c6478'
,p_attribute_05=>'#eee'
,p_attribute_07=>'linear'
,p_attribute_08=>'7000'
,p_attribute_09=>'no'
,p_attribute_10=>'no'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20296135132813810)
,p_name=>'onLoad'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20297343952813822)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(20297267523813821)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296623192813815)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(142596033009170590)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296297096813811)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'60'
,p_attribute_09=>'N'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142606087339357832)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_application.perform_upgrade_ddl;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296430095813813)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'95'
,p_attribute_09=>'N'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(142606208931357833)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_session_id NUMBER;',
'    l_app_id     NUMBER;',
'    l_user       VARCHAR2(4000);',
'BEGIN',
'    l_session_id := v(''APP_SESSION'');',
'    /*l_app_id := v(''APP_ID'');',
'    l_user := :G_USER;',
'    apex_util.clear_app_cache(l_app_id);',
'    apex_util.cache_purge_stale(l_app_id);',
'    apex_util.purge_regions_by_app(l_app_id);',
'',
'    --apex_session.detach;',
'    apex_session.delete_session(p_session_id => l_session_id);',
'    --apex_authentication.logout(p_session_id => l_session_id, p_app_id => l_app_id);',
'     apex_session.create_session(p_app_id => l_app_id, p_page_id => 1, p_username => l_user);',
'     apex_session.attach(l_app_id, 1, v(''APP_SESSION''));*/',
'END;'))
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296538008813814)
,p_event_id=>wwv_flow_imp.id(20296135132813810)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P35_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'100'
,p_attribute_09=>'N'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20296919916813817)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P35_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20296736606813816)
,p_event_id=>wwv_flow_imp.id(20296919916813817)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(142596033009170590)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20297458865813823)
,p_event_id=>wwv_flow_imp.id(20296919916813817)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(20297267523813821)
);
wwv_flow_imp.component_end;
end;
/
