prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Schedules'
,p_alias=>'SCHEDULES'
,p_step_title=>'Schedules'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220418103915'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(159414594888737366)
,p_plug_name=>'Schedules'
,p_region_name=>'Schedules'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT name',
'     , version',
'     , schedule_status',
'     , schedule_type',
'     , schedule_detail',
'     , id',
'     , project_id',
'FROM oic_pip_vw_schedules',
'WHERE project_id = :P15_PROJECT_ID',
'  AND schedule_detail IS NOT NULL',
'  AND schedule_status = DECODE(:P15_ACTION, ''STOP'', ''Activated'', ''START'', ''Deactivated'')'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P15_PROJECT_ID,P15_ACTION,P15_PROJECT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Schedules'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(144463978079461706)
,p_name=>'row_selector'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159414894026737369)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159415128023737371)
,p_name=>'VERSION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERSION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159415623923737376)
,p_name=>'SCHEDULE_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SCHEDULE_STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Schedule Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'Activated'
,p_attribute_03=>'Deactivated'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159415733233737377)
,p_name=>'SCHEDULE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SCHEDULE_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Schedule Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159415755540737378)
,p_name=>'SCHEDULE_DETAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SCHEDULE_DETAIL'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Schedule Detail'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159417569366737396)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(159417654414737397)
,p_name=>'PROJECT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(159414711248737367)
,p_internal_uid=>10399272229520016
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(160716126982966368)
,p_interactive_grid_id=>wwv_flow_imp.id(159414711248737367)
,p_static_id=>'117007'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(160716256108966370)
,p_report_id=>wwv_flow_imp.id(160716126982966368)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160717560189966385)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(159414894026737369)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160719369358966392)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(159415128023737371)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160723924847966407)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(159415623923737376)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160724826856966410)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(159415733233737377)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160725697083966413)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(159415755540737378)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160764885578424599)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(159417569366737396)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160765812853424602)
,p_view_id=>wwv_flow_imp.id(160716256108966370)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(159417654414737397)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160706026008898759)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(159417200152737392)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(160706026008898759)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_PROJECT_ID:&P15_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(144641209025039697)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(160706026008898759)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46563338194123941)
,p_name=>'P15_PROGRESS_BAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(159414594888737366)
,p_source=>'oic_pip_pkg_progress.fnc_get(apex_custom_auth.get_session_id, :APP_PAGE_ID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''35px'';',
'}'))
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#0063ce'
,p_attribute_05=>'#a6d1ff'
,p_attribute_07=>'linear'
,p_attribute_08=>'5000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'add-timer'
,p_attribute_12=>'4000'
,p_attribute_13=>'progress-is-complete'
,p_attribute_15=>'P15_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(144640047457034296)
,p_name=>'P15_ACTION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(159414594888737366)
,p_item_default=>'null'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Action'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Stop Schedule;STOP,Start Schedule;START'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-'
,p_lov_null_value=>'NULL'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(144653859985115037)
,p_name=>'P15_IDS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(159414594888737366)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(159416992158737390)
,p_name=>'P15_PROJECT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(159414594888737366)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(159417057849737391)
,p_name=>'P15_PROJECT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(159414594888737366)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Environment'
,p_source=>'SELECT project FROM oic_pip_projects WHERE id = :P15_PROJECT_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(144640288867037257)
,p_name=>'Refresh_on_Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_ACTION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144640666820037265)
,p_event_id=>wwv_flow_imp.id(144640288867037257)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(159414594888737366)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(144641422416040693)
,p_name=>'SubimitProcess'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(144641209025039697)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46565186454130207)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P15_PROGRESS_BAR'');',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148357887089159)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(144641209025039697)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148936559089165)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_ACTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46566237239130208)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144642289216040695)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sq1               NUMBER;',
'    l_har_errors        BOOLEAN := FALSE;',
'    l_count             NUMBER := 0;',
'    l_max               NUMBER;',
'',
'    CURSOR cur_count IS',
'        SELECT count(1) AS int_id',
'          FROM TABLE (apex_string.split(RTRIM(LTRIM(:P15_IDS, '':''), '':''), '':'')) t;',
'',
'BEGIN',
'    OPEN cur_count;',
'    FETCH cur_count INTO l_max;',
'    CLOSE cur_count;',
'',
'    oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 5);',
'',
'    FOR reg IN ( SELECT t.column_value AS int_id',
'                   FROM TABLE (apex_string.split(RTRIM(LTRIM(:P15_IDS, '':''), '':''), '':'')) t',
'                )',
'        LOOP',
'            l_sq1 := oic_pip_fnc_create_log(''SCHEDULE CHANGE - oic_pip_pkg_int_interface.fnc_upd_schedule'', ''RUNNING'');',
'            IF NOT (oic_pip_pkg_int_interface.fnc_upd_schedule(reg.int_id, '''', lower(:P15_ACTION), :P15_PROJECT_ID, l_sq1)) THEN',
'                oic_pip_prc_create_log_err(l_sq1, ''oic_pip_pkg_int_interface.fnc_upd_schedule call - status - ''||lower(:P15_ACTION) ||'' - int - ''|| reg.int_id ||'' - environment - ''|| :P15_PROJECT);',
'                l_har_errors := TRUE;',
'            ELSE',
'                UPDATE oic_pip_ints_downloaded',
'                SET schedule_status = DECODE(LOWER(:P15_ACTION), ''start'', ''Activated'', ''Deactivated'')',
'                WHERE id = reg.int_id',
'                  AND project_id = :P15_PROJECT_ID;',
'                COMMIT;',
'            END IF;',
'            IF l_har_errors THEN',
'                l_sq1 := oic_pip_fnc_create_log(''SCHEDULE CHANGE - oic_pip_pkg_int_interface.fnc_upd_schedule'', ''WARNING'', l_sq1, SYSDATE);',
'            ELSE',
'                l_sq1 := oic_pip_fnc_create_log(''SCHEDULE CHANGE - oic_pip_pkg_int_interface.fnc_upd_schedule'', ''COMPLETED'', l_sq1, SYSDATE);',
'            END IF;',
'',
'            l_count := l_count + 1;',
'            dbms_session.SLEEP(0.3);',
'            oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, CEIL(l_count/l_max*100) - 2);',
'        END LOOP;',
'',
'        dbms_session.SLEEP(1.3);',
'        oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'EXCEPTION WHEN OTHERS THEN',
'    oic_pip_prc_create_log_err(l_sq1, ''oic_pip_pkg_int_interface.fnc_upd_schedule call - error - '' || SQLERRM);',
'    l_sq1 := oic_pip_fnc_create_log(''SCHEDULE CHANGE - oic_pip_pkg_int_interface.fnc_upd_schedule'', ''ERROR'', l_sq1, SYSDATE);',
'    oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'END;'))
,p_attribute_02=>'P15_PROJECT_ID,P15_PROJECT,P15_IDS,P15_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44149314826089169)
,p_event_id=>wwv_flow_imp.id(144641422416040693)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'info'
,p_attribute_02=>'static'
,p_attribute_04=>'Process started'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_attribute_13=>'warning'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(144654059589118643)
,p_name=>'catchIDs'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(159414594888737366)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144654517302118644)
,p_event_id=>wwv_flow_imp.id(144654059589118643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i_ids = ":", i_ids,',
'',
'model = this.data.model;',
'',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    ',
'    i_ids += model.getValue( this.data.selectedRecords[i], "ID") + ":";',
'    ',
'}',
'',
'apex.item( "P15_IDS" ).setValue (i_ids);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144655012159118645)
,p_event_id=>wwv_flow_imp.id(144654059589118643)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_IDS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46563561878126447)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46564441867126448)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(apex_custom_auth.get_session_id, :APP_PAGE_ID);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148156529089157)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148262418089158)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44148422040089160)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(144641209025039697)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44149048179089166)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_ACTION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144643275257040696)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(159414594888737366)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44149365106089170)
,p_event_id=>wwv_flow_imp.id(46563561878126447)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_04=>'Process completed successfully'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_attribute_13=>'warning'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46566577241141382)
,p_name=>'INIT_PROGRESS_BAR'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46567471129141385)
,p_event_id=>wwv_flow_imp.id(46566577241141382)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46567059757141384)
,p_event_id=>wwv_flow_imp.id(46566577241141382)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P15_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
