prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Schedules Report'
,p_alias=>'SCHEDULES-REPORT'
,p_step_title=>'Schedules Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220317183843'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206894487165215775)
,p_plug_name=>'Schedule'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.name',
'     , a.version version',
'     , b.project',
'     , a.pattern',
'     , a.status intergration_status',
'     , a.schedule_status',
'     , a.schedule_type',
'     , a.schedule_detail',
'FROM oic_pip_ints_downloaded a',
'   , oic_pip_projects        b',
'WHERE a.project_id = b.id ',
'  AND a.pattern = ''Scheduled'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Schedule'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(206894536494215776)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>57879097474998425
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161512747675438563)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161513171839438564)
,p_db_column_name=>'VERSION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161513552037438565)
,p_db_column_name=>'PROJECT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Environment'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161513959221438565)
,p_db_column_name=>'PATTERN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pattern'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161514384497438566)
,p_db_column_name=>'SCHEDULE_STATUS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Schedule Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161514739807438567)
,p_db_column_name=>'SCHEDULE_TYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Schedule Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161515190922438567)
,p_db_column_name=>'SCHEDULE_DETAIL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Schedule Detail'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161515629613438568)
,p_db_column_name=>'INTERGRATION_STATUS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Intergration Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(208391021285300639)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125005'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:VERSION:PROJECT:SCHEDULE_STATUS:SCHEDULE_TYPE:SCHEDULE_DETAIL:'
,p_sort_column_1=>'NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PROJECT'
,p_sort_direction_2=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(161516393099438569)
,p_report_id=>wwv_flow_imp.id(208391021285300639)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'INTERGRATION_STATUS'
,p_operator=>'='
,p_expr=>'ACTIVATED'
,p_condition_sql=>'"INTERGRATION_STATUS" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ACTIVATED''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161474595160398957)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(206894487165215775)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161522708033438582)
,p_name=>'ChangeIntStatus'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P16_INTEGRATION_STATUS_SCH'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161523210192438583)
,p_event_id=>wwv_flow_imp.id(161522708033438582)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(206894487165215775)
);
wwv_flow_imp.component_end;
end;
/
