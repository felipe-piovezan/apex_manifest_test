prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Integrations In Time'
,p_alias=>'INTEGRATIONS-IN-TIME'
,p_step_title=>'Integrations In Time'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220401004828'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(183440434452992753)
,p_plug_name=>'Integrations'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT b.name',
'     , b.status',
'     , b.version',
'     , b.pattern',
'     , b.last_updated_date',
'     , oic_pip_pkg_utils.fnc_get_project_name(project_id) environment',
'     , b.schedule_status',
'     , b.schedule_type',
'     , b.schedule_detail',
'     , dbms_lob.getlength(b.integration_content) download',
'     , b.id || to_char(b.project_id) identificador',
'     , b.mime_type',
'     , b.charset',
'     , b.filename',
'FROM oic_pip_ints_downloaded b',
'WHERE TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') > b.creation_date',
'  AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'  AND NOT EXISTS(SELECT NULL',
'                 FROM oic_pip_ints_downloaded_hist a',
'                 WHERE a.id = b.id',
'                   AND a.project_id = b.project_id',
'                   AND TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN a.last_updated_date AND a.execution_date)',
'  AND project_id = :P11_PROJECT_ID',
'UNION',
'SELECT a.name',
'     , a.status',
'     , a.version',
'     , a.pattern',
'     , a.last_updated_date',
'     , oic_pip_pkg_utils.fnc_get_project_name(project_id) environment',
'     , a.schedule_status',
'     , a.schedule_type',
'     , a.schedule_detail',
'     , dbms_lob.getlength(a.integration_content) download',
'     , to_char(a.hist_id) identificador',
'     , a.mime_type',
'     , a.charset',
'     , a.filename',
'FROM oic_pip_ints_downloaded_hist a',
'WHERE TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN last_updated_date AND execution_date',
'  AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'  AND project_id = :P11_PROJECT_ID;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Integrations'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(183440553905992754)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>11308929432495718
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183440690374992755)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183440751009992756)
,p_db_column_name=>'STATUS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183440889941992757)
,p_db_column_name=>'VERSION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183440945041992758)
,p_db_column_name=>'PATTERN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pattern'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441080442992759)
,p_db_column_name=>'LAST_UPDATED_DATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Last Updated Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441148567992760)
,p_db_column_name=>'ENVIRONMENT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Environment'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441275604992761)
,p_db_column_name=>'SCHEDULE_STATUS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Schedule Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441376411992762)
,p_db_column_name=>'SCHEDULE_TYPE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Schedule Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441470740992763)
,p_db_column_name=>'SCHEDULE_DETAIL'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Schedule Detail'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441570699992764)
,p_db_column_name=>'DOWNLOAD'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Download File'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:OIC_PIP_INT_IN_TIME_BLOB:DOWNLOAD:IDENTIFICADOR::MIME_TYPE:FILENAME::CHARSET:attachment:Download:'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441640919992765)
,p_db_column_name=>'IDENTIFICADOR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Identificador'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441843566992767)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Mime Type'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183441958880992768)
,p_db_column_name=>'CHARSET'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Charset'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183442105594992769)
,p_db_column_name=>'FILENAME'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(183505593769026974)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'113740'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:STATUS:VERSION:PATTERN:LAST_UPDATED_DATE:ENVIRONMENT:SCHEDULE_STATUS:SCHEDULE_TYPE:SCHEDULE_DETAIL:DOWNLOAD:IDENTIFICADOR:MIME_TYPE:CHARSET:FILENAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194806089229471853)
,p_plug_name=>'Integrations In Time'
,p_region_template_options=>'t-BreadcrumbRegion--useRegionTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141073999505799647)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(194806089229471853)
,p_button_name=>'Backup'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate Backup'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cloud-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(183486059672830741)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194806089229471853)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::P10_TIME:&P11_TIME.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140935337657216324)
,p_name=>'P11_FILE_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(183440434452992753)
,p_source=>'SNAPSHOT_BKP'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183440261612992751)
,p_name=>'P11_TIME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(183440434452992753)
,p_prompt=>'Time: '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183485418102830735)
,p_name=>'P11_PROJECT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(183440434452992753)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(141074171678803980)
,p_name=>'GenerateBkp'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(141073999505799647)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141074603822803989)
,p_event_id=>wwv_flow_imp.id(141074171678803980)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141075067981803990)
,p_event_id=>wwv_flow_imp.id(141074171678803980)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'oic_pip_prc_generate_snapshot_bkp(TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS''), :P11_PROJECT_ID);',
'END;'))
,p_attribute_02=>'P11_TIME,P11_PROJECT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141075620852803991)
,p_event_id=>wwv_flow_imp.id(141074171678803980)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141076112745803991)
,p_event_id=>wwv_flow_imp.id(141074171678803980)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'url = ''f?p=&APP_ID.:11:&APP_SESSION.:APPLICATION_PROCESS=DOWNLOAD_BLOB:::FILE_TYPE:&P11_FILE_TYPE.''',
'window.open(url).focus();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(183441815126992766)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Creating Dowload'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE oic_pip_int_in_time_blob;',
'    COMMIT;',
'    FOR reg IN (SELECT b.integration_content         download',
'                     , b.id || TO_CHAR(b.project_id) identificador',
'                     , b.mime_type',
'                     , b.charset',
'                     , b.filename',
'                FROM oic_pip_ints_downloaded b',
'                WHERE TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') > ( SELECT TO_DATE(REPLACE(SUBSTR(created, 1, 19), ''T'', '' ''), ''YYYY-MM-DD HH24:MI:SS'')',
'                                    FROM oic_pip_rest_ds_integration ds',
'                                    WHERE ds.id = b.id AND ds.project_id = b.project_id',
'                                  )',
'                  AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'                  AND NOT EXISTS(SELECT NULL',
'                                 FROM oic_pip_ints_downloaded_hist a',
'                                 WHERE a.id = b.id',
'                                   AND a.project_id = b.project_id',
'                                   AND TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN a.last_updated_date AND a.execution_date)',
'                  AND project_id = :P11_PROJECT_ID)',
'        LOOP',
'            INSERT INTO oic_pip_int_in_time_blob (identificador, download, mime_type, charset, filename)',
'            VALUES (reg.identificador, reg.download, reg.mime_type, reg.charset, reg.filename);',
'        END LOOP;',
'    FOR reg IN (SELECT a.integration_content download',
'                     , TO_CHAR(a.hist_id)    identificador',
'                     , a.mime_type',
'                     , a.charset',
'                     , a.filename',
'                FROM oic_pip_ints_downloaded_hist a',
'                WHERE TO_DATE( :P11_TIME, ''DD-MM-YYYY HH24:MI:SS'') BETWEEN last_updated_date AND execution_date',
'                  AND oic_pip_pkg_utils.fnc_get_project_name(project_id) IS NOT NULL',
'                  AND project_id = :P11_PROJECT_ID )',
'        LOOP',
'            INSERT INTO oic_pip_int_in_time_blob (identificador, download, mime_type, charset, filename)',
'            VALUES (reg.identificador, reg.download, reg.mime_type, reg.charset, reg.filename);',
'        END LOOP;',
'    COMMIT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
