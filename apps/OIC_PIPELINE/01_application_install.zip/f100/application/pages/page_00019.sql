prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Batch Environment Promotion'
,p_alias=>'BATCH-ENVIRONMENT-PROMOTION'
,p_step_title=>'Batch Environment Promotion'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220530203603'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194638756867043829)
,p_plug_name=>'Ints'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM ( SELECT a.name                                               "source integration name"',
'            , a.version                                            "source integration version"',
'            , b.task_name                                          "source task name"',
'            , a.status                                             "source integration status"',
'            , a.pattern',
'            , DECODE(:P19_ALL_INTEGRATIONS, ''Y'', null, target.task_name) "target task name"',
'            , DECODE(:P19_ALL_INTEGRATIONS, ''Y'', null, target.version)   "target integration version"',
'            , DECODE(:P19_ALL_INTEGRATIONS, ''Y'', null, target.status)    "target integration status"',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'          , ( SELECT MIN(d.status)  status',
'                   , c.project',
'                   , d.name',
'                   , MAX(d.version) version',
'                   , c.pipeline_order',
'                   , c.task_name',
'              FROM oic_pip_projects        c',
'                 , oic_pip_ints_downloaded d',
'              WHERE c.id = d.project_id',
'              GROUP BY c.project',
'                     , d.name',
'                     , c.pipeline_order',
'                     , c.task_name',
'            )                       target',
'       WHERE a.project_id = b.id',
'         AND :P19_PROJECT_ID = b.id',
'         AND b.pipeline_order + 1 = target.pipeline_order',
'         AND a.name = target.name',
'         --  AND a.status = ''ACTIVATED''',
'         AND a.status = DECODE(:P19_ALL_STATUS, ''Y'', a.status, ''ACTIVATED'')',
'         AND (((TO_NUMBER(SUBSTR(a.version, 1, 2)) = TO_NUMBER(SUBSTR(target.version, 1, 2)) AND',
'                TO_NUMBER(SUBSTR(a.version, 4, 2)) = TO_NUMBER(SUBSTR(target.version, 4, 2)) AND',
'                TO_NUMBER(SUBSTR(a.version, 7, 4)) > TO_NUMBER(SUBSTR(target.version, 7, 4))) OR',
'               (TO_NUMBER(SUBSTR(a.version, 1, 2)) = TO_NUMBER(SUBSTR(target.version, 1, 2)) AND',
'                TO_NUMBER(SUBSTR(a.version, 4, 2)) > TO_NUMBER(SUBSTR(target.version, 4, 2))) OR',
'               TO_NUMBER(SUBSTR(a.version, 1, 2)) > TO_NUMBER(SUBSTR(target.version, 1, 2))) OR',
'              :P19_ALL_INTEGRATIONS = ''Y'')',
'       UNION ALL',
'       SELECT a.name         "source integration name"',
'            , MAX(a.version) "source integration version"',
'            , b.task_name    "source task name"',
'            , MIN(a.status)  "source integration status"',
'            , a.pattern',
'            , i.task_name    "target task name"',
'            , NULL           "target integration version"',
'            , NULL           "target integration status"',
'       FROM oic_pip_ints_downloaded a',
'          , oic_pip_projects        b',
'          , oic_pip_projects        i',
'       WHERE a.project_id = b.id',
'         AND b.pipeline_order + 1 = i.pipeline_order',
'         AND :P19_PROJECT_ID = b.id',
'         AND a.status = DECODE(:P19_ALL_STATUS, ''Y'', a.status, ''ACTIVATED'')',
'         AND NOT EXISTS(SELECT NULL',
'                        FROM oic_pip_ints_downloaded d',
'                        WHERE i.id = d.project_id',
'                          AND a.name = d.name)',
'       GROUP BY a.name',
'              , b.project',
'              , a.pattern',
'              , i.project',
'              , i.task_name',
'              , b.task_name',
'       ORDER BY 1',
'     )'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P19_ALL_STATUS,P19_ALL_INTEGRATIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Ints'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161615751385352565)
,p_name=>'source integration name'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'source integration name'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Integration Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>400
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161615846462352566)
,p_name=>'source integration version'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'source integration version'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Integration Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616117024352568)
,p_name=>'source task name'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'source task name'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616200176352569)
,p_name=>'source integration status'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'source integration status'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Integration Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616277650352570)
,p_name=>'PATTERN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Pattern'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616477771352572)
,p_name=>'target task name'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'target task name'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616694265352574)
,p_name=>'target integration version'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'target integration version'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Target Integration Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616817785352575)
,p_name=>'target integration status'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'target integration status'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Target Integration Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161616894146352576)
,p_name=>'row_selector'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(161615675393352564)
,p_internal_uid=>12600236374135213
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(161636006773407177)
,p_interactive_grid_id=>wwv_flow_imp.id(161615675393352564)
,p_static_id=>'126206'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(161636217729407177)
,p_report_id=>wwv_flow_imp.id(161636006773407177)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161636693464407184)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(161615751385352565)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161637609462407191)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(161615846462352566)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161639381245407200)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(161616117024352568)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161640296672407204)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(161616200176352569)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161641168821407207)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(161616277650352570)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161642974982407215)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(161616477771352572)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161644794043407223)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(161616694265352574)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161645689696407226)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(161616817785352575)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161660167282437579)
,p_view_id=>wwv_flow_imp.id(161636217729407177)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(161616894146352576)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194807997697022795)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161476202335398973)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(194807997697022795)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_PROJECT_ID:&P19_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161616951301352577)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194807997697022795)
,p_button_name=>'Apply'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10999041251777519)
,p_name=>'P19_ERROR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46692199776230248)
,p_name=>'P19_PROGRESS_BAR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_source=>'oic_pip_pkg_progress.fnc_get(apex_custom_auth.get_session_id, :APP_PAGE_ID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    config.height = ''35px'';',
'}'))
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#0063ce'
,p_attribute_05=>'#a6d1ff'
,p_attribute_07=>'linear'
,p_attribute_08=>'5000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
,p_attribute_11=>'add-timer'
,p_attribute_12=>'4000'
,p_attribute_13=>'progress-is-complete'
,p_attribute_15=>'P19_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140677444553060412)
,p_name=>'P19_ALL_INTEGRATIONS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_prompt=>'All Integrations'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(159418132354737401)
,p_name=>'P19_SOURCE_ENV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_prompt=>'Source Environment'
,p_source=>'SELECT project FROM oic_pip_projects WHERE id = :P19_PROJECT_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161609263722299159)
,p_name=>'P19_PROJECT_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161609980655299162)
,p_name=>'P19_ALL_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_prompt=>'All Integration Status'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161614462139352552)
,p_name=>'P19_TARGET_ENV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_prompt=>'Source Environment'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT proj_target.project ',
'  FROM oic_pip_projects proj_source',
'     , oic_pip_projects proj_target',
' WHERE proj_target.pipeline_order = proj_source.pipeline_order + 1',
'   AND proj_source.id = :P19_PROJECT_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083613088094859)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161617530068352582)
,p_name=>'P19_IDS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161617887781352586)
,p_name=>'P19_TARGET_STATUS'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(194638756867043829)
,p_prompt=>'Target Status For ALL Integrations'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:CONFIGURED;CONFIGURED,ACTIVATED;ACTIVATED'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083856723094859)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161610944107299164)
,p_name=>'DiagClose'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(194638756867043829)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161611447973299165)
,p_event_id=>wwv_flow_imp.id(161610944107299164)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROJECT_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P19_PROJECT_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161612009564299166)
,p_event_id=>wwv_flow_imp.id(161610944107299164)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194638756867043829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161612423891299166)
,p_name=>'Refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_ALL_STATUS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161612916664299167)
,p_event_id=>wwv_flow_imp.id(161612423891299166)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194638756867043829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161617331281352580)
,p_name=>'catchIDs'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(194638756867043829)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161617432685352581)
,p_event_id=>wwv_flow_imp.id(161617331281352580)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i_ids = ":", i_ids,',
'',
'model = this.data.model;',
'',
'for ( i = 0; i < this.data.selectedRecords.length; i++ ) {',
'    ',
'    i_ids += model.getValue( this.data.selectedRecords[i], "source integration name") ',
'           + "|"',
'           + model.getValue( this.data.selectedRecords[i], "source integration version")',
'           + ":";',
'    ',
'}',
'',
'apex.item( "P19_IDS" ).setValue (i_ids);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161617551241352583)
,p_event_id=>wwv_flow_imp.id(161617331281352580)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_IDS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140677575626060413)
,p_name=>'replace_warning'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_ALL_INTEGRATIONS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140677800694060415)
,p_event_id=>wwv_flow_imp.id(140677575626060413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Integrations that already exists in target environment will be replaced!'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P19_ALL_INTEGRATIONS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140677715107060414)
,p_event_id=>wwv_flow_imp.id(140677575626060413)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194638756867043829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46690814943227473)
,p_name=>'INIT_PROGRESS_BAR'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46691762850227475)
,p_event_id=>wwv_flow_imp.id(46690814943227473)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46691253234227474)
,p_event_id=>wwv_flow_imp.id(46690814943227473)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46692385615231902)
,p_name=>'PROGRESS_BAR_COMPLETED'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46694789852231905)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    oic_pip_pkg_progress.prc_clean(apex_custom_auth.get_session_id, :APP_PAGE_ID);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46694343345231904)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46695339618231905)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46693347380231903)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(161616951301352577)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46695826668231906)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ALL_STATUS,P19_ALL_INTEGRATIONS,P19_TARGET_STATUS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10999297417777521)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P19_ERROR.'
,p_attribute_02=>'Promotion Failed'
,p_attribute_03=>'warning'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P19_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46693847135231904)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194638756867043829)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46692827089231903)
,p_event_id=>wwv_flow_imp.id(46692385615231902)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'success'
,p_attribute_02=>'static'
,p_attribute_04=>'Process completed successfully'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P19_ERROR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46696169411233142)
,p_name=>'SubimitProcess'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(161616951301352577)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46698143108233145)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let item = apex.item(''P19_PROGRESS_BAR'');',
'if(item.callbacks){',
'    item.callbacks.startInterval();',
'} else {',
'    item.startInterval();',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46697620002233144)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(161616951301352577)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46699075063233146)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ALL_STATUS,P19_ALL_INTEGRATIONS,P19_TARGET_STATUS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46698600222233145)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161617970457352587)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_count        NUMBER := 0;',
'    l_max          NUMBER := 0;',
'    l_in_execution BOOLEAN;',
'    l_dummy        NUMBER;',
'    l_erro         oic_pip_pkg_int_interface.INTERFACE_ERROR;',
'    ',
'    -- cur_in_exec',
'    CURSOR cur_in_exec IS',
'        SELECT 1',
'        FROM oic_pip_automation_log',
'        WHERE end_time IS NULL',
'          AND name = ''SYNC - oic_pip_prc_auto_int_downloads'';',
'    ',
'    -- cur_count',
'    CURSOR cur_count IS',
'        SELECT COUNT(1) AS int_id',
'        FROM TABLE (apex_string.split(RTRIM(LTRIM(:P15_IDS, '':''), '':''), '':'')) t;',
'',
'BEGIN',
'    :P19_ERROR := '''';',
'    ',
'    OPEN cur_in_exec;',
'    FETCH cur_in_exec INTO l_dummy;',
'    l_in_execution := cur_in_exec%FOUND;',
'    CLOSE cur_in_exec;',
'    ',
'    IF l_in_execution THEN',
'        :P19_ERROR := ''SYNC executing, please wait.'';',
'    ELSE',
'        ',
'        OPEN cur_count;',
'        FETCH cur_count INTO l_max;',
'        CLOSE cur_count;',
'        ',
'        IF l_max = 0 THEN',
'            l_max := 1;',
'        END IF;',
'        ',
'        oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 5);',
'        ',
'        FOR reg IN ( SELECT *',
'                     FROM oic_pip_vw_int_batch_promotion',
'                     WHERE "source integration name" || ''|'' || "source integration version" IN',
'                           ( SELECT t.column_value AS int_id',
'                             FROM TABLE (apex_string.split(RTRIM(LTRIM(:P19_IDS, '':''), '':''), '':'')) t',
'                           )',
'                       AND "source task name" = ( SELECT task_name',
'                                                  FROM oic_pip_projects',
'                                                  WHERE id = :P19_PROJECT_ID',
'                                                ))',
'        LOOP',
'            oic_pip_prc_confirm_promotion(l_erro, reg."source integration name", reg."source integration version",',
'                                          :P19_TARGET_STATUS, ''N'', reg."source task name", reg."target task name");',
'            IF l_erro.code IS NOT NULL THEN',
'                :P19_ERROR := :P19_ERROR || l_erro.detail || '' - '' || l_erro.code || ''; '';',
'                l_erro.code := NULL;',
'                l_erro.detail := NULL;',
'            END IF;',
'            ',
'            l_count := l_count + 1;',
'            oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID,',
'                                         CEIL(l_count / l_max * 100) - 2);',
'        END LOOP;',
'        ',
'        dbms_session.sleep(0.3);',
'        oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'    END IF;',
'EXCEPTION',
'    WHEN OTHERS THEN oic_pip_pkg_progress.prc_set(apex_custom_auth.get_session_id, :APP_PAGE_ID, 100);',
'    :P19_ERROR := :P19_ERROR || SQLERRM;',
'END;'))
,p_attribute_02=>'P19_IDS,P19_TARGET_STATUS,P19_PROJECT_ID,P19_ALL_INTEGRATIONS,P19_ERROR'
,p_attribute_03=>'P19_ERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46696606138233143)
,p_event_id=>wwv_flow_imp.id(46696169411233142)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'info'
,p_attribute_02=>'static'
,p_attribute_04=>'Process started'
,p_attribute_07=>'autodismiss:escape-html:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'5'
,p_attribute_13=>'warning'
);
null;
wwv_flow_imp.component_end;
end;
/
