prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Integrations'
,p_alias=>'INTEGRATIONS'
,p_step_title=>'Integrations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220609132436'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140935604525216327)
,p_plug_name=>'EnvActions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P41_PROJECT_ID'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184297548406317486)
,p_plug_name=>'Integrations'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.rowid',
'     , a.name',
'     , a.status',
'     , a.version',
'     , a.pattern',
'     , a.last_updated_date',
'     , b.project',
'     , a.schedule_status',
'     , a.schedule_type',
'     , a.schedule_detail',
'     , dbms_lob.getlength(integration_content) download',
'     , a.package_name',
'FROM oic_pip_ints_downloaded a',
'   , oic_pip_projects        b',
'WHERE a.project_id = b.id',
'  AND :P41_PROJECT_ID = b.id',
'ORDER BY b.id',
', a.status',
'       , a.name;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P41_PROJECT_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Integrations'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(184335864636694837)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>12204240163197801
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184335990715694838)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336199617694840)
,p_db_column_name=>'VERSION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336051904694839)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336273670694841)
,p_db_column_name=>'PATTERN'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Pattern'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336489694694843)
,p_db_column_name=>'PROJECT'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Environment'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336609462694844)
,p_db_column_name=>'SCHEDULE_STATUS'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Schedule Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336722632694845)
,p_db_column_name=>'SCHEDULE_TYPE'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Schedule Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336820277694846)
,p_db_column_name=>'SCHEDULE_DETAIL'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Schedule Detail'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184336404888694842)
,p_db_column_name=>'LAST_UPDATED_DATE'
,p_display_order=>110
,p_column_identifier=>'E'
,p_column_label=>'Last Updated Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(188656480372720047)
,p_db_column_name=>'ROWID'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(140935186370216323)
,p_db_column_name=>'PACKAGE_NAME'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>'Package Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(188656586928720048)
,p_db_column_name=>'DOWNLOAD'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Integration'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:OIC_PIP_INTS_DOWNLOADED:INTEGRATION_CONTENT:ROWID::MIME_TYPE:FILENAME:LAST_UPDATED_DATE:CHARSET:attachment:<i class="fa fa-download"></i>:'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(184344338183698331)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'122128'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:STATUS:VERSION:PATTERN:LAST_UPDATED_DATE:PROJECT:SCHEDULE_STATUS:SCHEDULE_TYPE:SCHEDULE_DETAIL:PACKAGE_NAME:DOWNLOAD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184335251413682895)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184297479546317485)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(184335251413682895)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(149263579960629420)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Delete'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::P20_PROJECT_ID:&P41_PROJECT_ID.'
,p_button_condition=>'SELECT 1 FROM oic_pip_projects WHERE id = :P41_PROJECT_ID AND STATUS NOT IN (''CLOSED'')'
,p_button_condition_type=>'EXISTS'
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(150356696909183536)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'Manage_Status'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Manage Status'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::P23_PROJECT_ID:&P41_PROJECT_ID.'
,p_button_condition=>'SELECT 1 FROM oic_pip_projects WHERE id = :P41_PROJECT_ID AND STATUS NOT IN (''CLOSED'')'
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(159414322557737363)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'Manage_Schedules'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Manage Schedules'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::P15_PROJECT_ID:&P41_PROJECT_ID.'
,p_button_condition=>'SELECT 1 FROM oic_pip_projects WHERE id = :P41_PROJECT_ID AND STATUS NOT IN (''CLOSED'')'
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182051792274962051)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'Promote'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Promote'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_PROJECT_ID:&P41_PROJECT_ID.'
,p_button_condition=>'oic_pip_pkg_utils.oic_pip_fnc_has_next_env(:P41_PROJECT_ID)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_security_scheme=>wwv_flow_imp.id(184111529044094880)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140935518452216326)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'Packages'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Packages'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_PROJECT_ID:&P41_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11000371892777532)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'Lookups'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Lookups'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::P37_PROJECT_ID:&P41_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30615207285203924)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_button_name=>'APIG'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'API Gateway'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::P28_PROJECT_ID:&P41_PROJECT_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM oic_pip_projects',
'WHERE apigws_displayname IS NOT NULL',
'  AND compartment_name IS NOT NULL',
'  AND id = :P41_PROJECT_ID'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140935369532216325)
,p_name=>'P41_PROJECT_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140935604525216327)
,p_prompt=>'Environment'
,p_source=>'oic_pip_pkg_utils.fnc_get_project_name(:P41_PROJECT_ID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(184083467654094858)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184336952769694848)
,p_name=>'P41_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(184297548406317486)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
