prompt --application/pages/page_10000
begin
--   Manifest
--     PAGE: 10000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>10000
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Administration'
,p_alias=>'ADMIN'
,p_step_title=>'Administration'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(184113450625094882)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(184111529044094880)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The administration page allows application owners (Administrators) to configure the application and maintain common data used across the application.',
'By selecting one of the available settings, administrators can potentially change how the application is displayed and/or features available to the end users.</p>',
'<p>Access to this page should be limited to Administrators only.</p>'))
,p_page_component_map=>'03'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220629211244'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184270461481096960)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184031563542094824)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(184299022800356885)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(184086106627094860)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184277005595096964)
,p_plug_name=>'Column 1'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183993962616094800)
,p_plug_display_sequence=>10
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184277397193096965)
,p_plug_name=>'Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(184277005595096964)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(184271080153096961)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184069055818094849)
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(184109230400094878)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184277755467096965)
,p_plug_name=>'User Interface'
,p_parent_plug_id=>wwv_flow_imp.id(184277005595096964)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(184271810174096961)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184069055818094849)
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(184109703739094878)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184278199731096965)
,p_plug_name=>'Activity Reports'
,p_parent_plug_id=>wwv_flow_imp.id(184277005595096964)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(184272457247096962)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184069055818094849)
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(184108966515094878)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184278550083096965)
,p_plug_name=>'Column 2'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183993962616094800)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140932499223216296)
,p_plug_name=>'Users'
,p_parent_plug_id=>wwv_flow_imp.id(184278550083096965)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_name',
'     , email',
'     , account_locked',
'FROM apex_workspace_apex_users a'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'USER_NAME'
,p_attribute_06=>'EMAIL'
,p_attribute_16=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::P26_USERNAME,P26_EMAIL,P26_USER_LOCKED:&USER_NAME.,&EMAIL.,&ACCOUNT_LOCKED.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184278972741096966)
,p_plug_name=>'Access Control'
,p_parent_plug_id=>wwv_flow_imp.id(184278550083096965)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_imp.id(184108851778094878)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184279740605096966)
,p_plug_name=>'ACL Information'
,p_parent_plug_id=>wwv_flow_imp.id(184278972741096966)
,p_region_css_classes=>'margin-sm'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--warning:t-Alert--accessibleHeading'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183990039014094797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_acl_scope   varchar2(45);',
'begin',
'    l_acl_scope   := apex_app_setting.get_value( p_name => ''ACCESS_CONTROL_SCOPE'' );',
'',
'    if l_acl_scope = ''ALL_USERS'' then',
'        sys.htp.p( apex_lang.message(''APEX.FEATURE.ACL.INFO.ALL_USERS'') );',
'    elsif l_acl_scope = ''ACL_ONLY'' then',
'        sys.htp.p( apex_lang.message(''APEX.FEATURE.ACL.INFO.ACL_ONLY'') );',
'    else',
'        sys.htp.p( apex_lang.message(''APEX.FEATURE.ACL.INFO.ACL_VALUE_INVALID'', l_acl_scope) );',
'    end if;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(184280223765096966)
,p_name=>'User Counts Report'
,p_parent_plug_id=>wwv_flow_imp.id(184278972741096966)
,p_template=>wwv_flow_imp.id(184022174135094818)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:t-Region--noPadding'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.role_name, (select count(*) from apex_appl_acl_user_roles ur where r.role_id = ur.role_id) user_count, r.role_id',
'from  APEX_APPL_ACL_ROLES r',
'where r.application_id = :APP_ID',
'  and r.role_name NOT IN (''OIC_PIPELINE_DEVELOPER'')',
'group by r.role_name, r.role_id',
'order by 2 desc, 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(184056084137094840)
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(184280919540096967)
,p_query_column_id=>1
,p_column_alias=>'ROLE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'Role Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(184281303059096968)
,p_query_column_id=>2
,p_column_alias=>'USER_COUNT'
,p_column_display_sequence=>2
,p_column_heading=>'User Count'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(184281649332096968)
,p_query_column_id=>3
,p_column_alias=>'ROLE_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Role Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184284626597097357)
,p_plug_name=>'Access Control Actions'
,p_parent_plug_id=>wwv_flow_imp.id(184278972741096966)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183993785181094800)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(184275211840096963)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184069055818094849)
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184285041620097357)
,p_plug_name=>'Feedback'
,p_parent_plug_id=>wwv_flow_imp.id(184278550083096965)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(184022174135094818)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_imp.id(184109024614094878)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(184285450488097357)
,p_name=>'Report'
,p_parent_plug_id=>wwv_flow_imp.id(184285041620097357)
,p_template=>wwv_flow_imp.id(184022174135094818)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody:t-Region--noPadding'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.display_value feedback_status, ',
'(select count(*) from apex_team_feedback f where f.application_id = :APP_ID and f.feedback_status = l.return_value) feedback_count ',
'from apex_application_lov_entries l',
'where l.application_id = :APP_ID',
'and l.list_of_values_name = ''FEEDBACK_STATUS''',
'order by 2 desc, 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(184056084137094840)
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(184286168180097358)
,p_query_column_id=>1
,p_column_alias=>'FEEDBACK_STATUS'
,p_column_display_sequence=>1
,p_column_heading=>'Feedback Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(184286600163097358)
,p_query_column_id=>2
,p_column_alias=>'FEEDBACK_COUNT'
,p_column_display_sequence=>2
,p_column_heading=>'Feedback Count'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184288350471097740)
,p_plug_name=>'Feedback'
,p_parent_plug_id=>wwv_flow_imp.id(184285041620097357)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(183993785181094800)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(184276233785096964)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(184069055818094849)
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137267469138646518)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184270461481096960)
,p_button_name=>'Update'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Check for Updates'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM oic_pip_remote_update_conf',
'WHERE provider = ''bitbucket''',
'  AND repo_name IS NOT NULL',
'  AND owner IS NOT NULL',
'  AND install_file_path IS NOT NULL',
'  AND EXISTS(SELECT 1',
'             FROM apex_workspace_credentials',
'             WHERE UPPER(static_id) = ''BITBUCKT_CREDENTIAL'')',
'UNION ALL',
'SELECT 1',
'FROM oic_pip_remote_update_conf',
'WHERE provider = ''github''',
'  AND repo_name IS NOT NULL',
'  AND owner IS NOT NULL',
'  AND install_file_path IS NOT NULL',
'  AND EXISTS(SELECT 1',
'             FROM user_credentials',
'             WHERE UPPER(credential_name) = ''OIC_PIPELINE_CRED'')'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-arrow-circle-o-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140932368787216295)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(140932499223216296)
,p_button_name=>'ADD_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_image_alt=>'Add'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:RP,26::'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184279367991096966)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184278972741096966)
,p_button_name=>'ADD_ACL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(184084792489094860)
,p_button_image_alt=>'Add'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:10042:&SESSION.::&DEBUG.:RP,10042::'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137267770893646521)
,p_name=>'P10000_REMOTE_VERSION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(184270461481096960)
,p_item_default=>'oic_pip_pkg_application.get_cur_repo_version'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137267861247646522)
,p_name=>'P10000_CUR_VERSION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(184270461481096960)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT apx.version apex_version',
'    FROM apex_applications apx',
'    WHERE apx.application_id = :APP_ID;'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137268862878646532)
,p_name=>'P10000_REMOTE_CONF_ROWID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(184277397193096965)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROWID',
'--INTO :P22_ROWID',
'FROM oic_pip_remote_update_conf;'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140041662652424816)
,p_name=>'P10000_UPDATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(184270461481096960)
,p_item_default=>'oic_pip_pkg_application.get_cur_repo_version'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(184283808944097356)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(184279367991096966)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184284289231097356)
,p_event_id=>wwv_flow_imp.id(184283808944097356)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(184280223765096966)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46651905751492850)
,p_name=>'Refresh on Dialog Close_2'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(140932499223216296)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46651987562492851)
,p_event_id=>wwv_flow_imp.id(46651905751492850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(137267544315646519)
,p_name=>'Check'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(137267469138646518)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140042228457424821)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10000_REMOTE_VERSION,P10000_UPDATE,P10000_CUR_VERSION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20297097211813819)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(137267469138646518)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134972512476904198)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10000_REMOTE_VERSION'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'oic_pip_pkg_application.get_cur_repo_version'
,p_attribute_07=>'P10000_REMOTE_VERSION'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134972633646904199)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10000_CUR_VERSION'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT apx.version',
'    FROM apex_applications apx',
'    WHERE apx.application_id = :APP_ID;'))
,p_attribute_07=>'P10000_CUR_VERSION'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137267958821646523)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF oic_pip_pkg_application.has_remote_update_available(:P10000_CUR_VERSION, :P10000_REMOTE_VERSION) THEN',
'        :P10000_UPDATE := ''S'';',
'    ELSE ',
'        :P10000_UPDATE := ''N'';',
'    END IF;',
'END;'))
,p_attribute_02=>'P10000_UPDATE,P10000_REMOTE_VERSION,P10000_CUR_VERSION'
,p_attribute_03=>'P10000_UPDATE,P10000_REMOTE_VERSION,P10000_CUR_VERSION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137267675130646520)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.NOTIFICATIONS'
,p_attribute_01=>'info'
,p_attribute_02=>'static'
,p_attribute_03=>'Update OIC_PIPELINE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You alread have the latest version of OIC_PIPELINE installed.',
'<br>',
'Current: &P10000_CUR_VERSION.'))
,p_attribute_07=>'autodismiss:newest-on-top:client-side-substitutions:dismiss-on-click:dismiss-on-button'
,p_attribute_08=>'top-right'
,p_attribute_09=>'Y'
,p_attribute_11=>'10'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P10000_UPDATE'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20297177259813820)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(137267469138646518)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137268068092646524)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P10000_UPDATE'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137268204698646525)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Do you want to upgrade now?',
'<br><br>',
'Current  : &P10000_CUR_VERSION.',
'<br>',
'Available: Release &P10000_REMOTE_VERSION.'))
,p_attribute_02=>'There is a new version available!'
,p_attribute_03=>'information'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P10000_UPDATE'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(144676541935537553)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup = apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137268476109646528)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    --cur_conf',
'    CURSOR cur_conf IS',
'        SELECT *',
'          FROM oic_pip_remote_update_conf;',
'    vr_conf oic_pip_remote_update_conf%ROWTYPE;',
'    ',
'BEGIN',
'    FOR reg IN (SELECT static_id',
'                     , application_id',
'                FROM apex_appl_automations',
'                WHERE application_id = apex_application.g_flow_id)',
'    LOOP',
'        apex_automation.disable(p_application_id => reg.application_id, p_static_id => reg.static_id);',
'    END LOOP;',
'',
'    OPEN cur_conf;',
'    FETCH cur_conf INTO vr_conf;',
'    CLOSE cur_conf;',
'    ',
'    oic_pip_prc_app_install(null, vr_conf, ''UPDATE'');',
'',
'    dbms_scheduler.create_job(job_name => ''PERFORM_DDL_UPGRADE_'' || SYS_GUID(), job_type => ''PLSQL_BLOCK'',',
'                              job_action => ''oic_pip_pkg_application.perform_upgrade_ddl;'',',
'                              start_date => SYSDATE + 2 / 86400, enabled => TRUE, auto_drop => TRUE,',
'                              comments => ''one-time job execution'');',
'',
'    FOR reg IN (SELECT ROWNUM/1440 next_run',
'                     , static_id',
'                     , application_id',
'                FROM apex_appl_automations',
'                WHERE application_id = apex_application.g_flow_id)',
'    LOOP',
'        apex_automation.enable(p_application_id => reg.application_id, p_static_id => reg.static_id);',
'        apex_automation.reschedule(p_application_id => reg.application_id, p_static_id => reg.static_id, p_next_run_at => SYSDATE + reg.next_run);',
'    END LOOP;',
'',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45918204609514447)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>140
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'waitPopup.remove();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040938322424808)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>160
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Upgrade completed!'
,p_attribute_02=>'OIC_PIPELINE'
,p_attribute_03=>'success'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140040987907424809)
,p_event_id=>wwv_flow_imp.id(137267544315646519)
,p_event_result=>'TRUE'
,p_action_sequence=>170
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140678508987060422)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear_Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
