prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>9013933507680050
,p_default_application_id=>100
,p_default_id_offset=>172131624473497036
,p_default_owner=>'OIC_PIP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_imp.id(184107339692094873)
,p_name=>'Pipeline View Report'
,p_alias=>'PIPELINE-VIEW-REPORT'
,p_step_title=>'Pipeline View Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'OIC_PIP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20220802183044'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194634601267140973)
,p_plug_name=>'Pipeline'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(184020313651094816)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT t1.integration_id integration',
'     , t1.status         pipeline_status',
'     , t1.cur_prj        current_environment',
'     , t1.next_prj       next_environment',
'     , t1.action_project environment_with_action',
'     , NULL              pipeline_id',
'     , ( SELECT COALESCE(( SELECT ''fa fa-comment''',
'                           FROM dual',
'                           WHERE EXISTS(SELECT NULL',
'                                        FROM oic_pip_pipeline_comments c',
'                                        WHERE c.integration_id = t1.integration_id)',
'                         ), ''fa fa-comment-o'')',
'         FROM dual',
'       )                 comments',
'FROM oic_pip_vw_task1 t1',
'UNION ALL',
'-- pipe',
'SELECT pip.integration_id',
'     , pip.status',
'     , cur_prj.project  cur_prj',
'     , next_prj.project next_prj',
'     , next_prj.project action_project',
'     , pip.id           pipeline_id',
'     , ( SELECT COALESCE(( SELECT ''fa fa-comment''',
'                           FROM dual',
'                           WHERE EXISTS(SELECT NULL',
'                                        FROM oic_pip_pipeline_comments c',
'                                        WHERE c.pipeline_id = pip.id',
'                                           OR (c.pipeline_id IS NULL AND c.integration_id = pip.integration_id))',
'                         ), ''fa fa-comment-o'')',
'         FROM dual',
'       )                comments',
'FROM oic_pip_int_pipeline pip',
'   , oic_pip_projects     cur_prj',
'   , oic_pip_projects     next_prj',
'WHERE pip.current_project_id = cur_prj.id',
'  AND cur_prj.pipeline_order + 1 = next_prj.pipeline_order',
'  AND pip.status = ''READY_TO_DEPLOY''',
'UNION ALL',
'SELECT pip.integration_id',
'     , pip.status',
'     , cur_prj.project  cur_prj',
'     , next_prj.project next_prj',
'     , cur_prj.project  action_project',
'     , pip.id           pipeline_id',
'     , ( SELECT COALESCE(( SELECT ''fa fa-comment''',
'                           FROM dual',
'                           WHERE EXISTS(SELECT NULL',
'                                        FROM oic_pip_pipeline_comments c',
'                                        WHERE c.pipeline_id = pip.id',
'                                           OR (c.pipeline_id IS NULL AND c.integration_id = pip.integration_id))',
'                         ), ''fa fa-comment-o'')',
'         FROM dual',
'       )                comments',
'FROM oic_pip_int_pipeline pip',
'   , oic_pip_projects     cur_prj',
'   , oic_pip_projects     next_prj',
'WHERE pip.current_project_id = cur_prj.id',
'  AND cur_prj.pipeline_order + 1 = next_prj.pipeline_order',
'  AND pip.status = ''TESTING''',
'UNION ALL',
'SELECT pip.integration_id',
'     , pip.status',
'     , cur_prj.project  cur_prj',
'     , next_prj.project next_prj',
'     , '' - ''            action_project',
'     , pip.id           pipeline_id',
'     , ( SELECT COALESCE(( SELECT ''fa fa-comment''',
'                           FROM dual',
'                           WHERE EXISTS(SELECT NULL',
'                                        FROM oic_pip_pipeline_comments c',
'                                        WHERE c.pipeline_id = pip.id',
'                                           OR (c.pipeline_id IS NULL AND c.integration_id = pip.integration_id))',
'                         ), ''fa fa-comment-o'')',
'         FROM dual',
'       )                comments',
'FROM oic_pip_int_pipeline pip',
'   , oic_pip_projects     cur_prj',
'   , oic_pip_projects     next_prj',
'WHERE pip.current_project_id = cur_prj.id',
'  AND cur_prj.pipeline_order + 1 = next_prj.pipeline_order',
'  AND pip.status = ''REJECTED''',
'UNION ALL',
'SELECT pip.integration_id',
'     , pip.status',
'     , cur_prj.project cur_prj',
'     , '' - ''           next_prj',
'     , '' - ''           action_project',
'     , pip.id          pipeline_id',
'     , ( SELECT COALESCE(( SELECT ''fa fa-comment''',
'                           FROM dual',
'                           WHERE EXISTS(SELECT NULL',
'                                        FROM oic_pip_pipeline_comments c',
'                                        WHERE c.pipeline_id = pip.id',
'                                           OR (c.pipeline_id IS NULL AND c.integration_id = pip.integration_id))',
'                         ), ''fa fa-comment-o'')',
'         FROM dual',
'       )               comments',
'FROM oic_pip_int_pipeline pip',
'   , oic_pip_projects     cur_prj',
'WHERE pip.current_project_id = cur_prj.id',
'  AND pip.status = ''DONE'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Pipeline'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(194634628394140974)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PROJ1'
,p_internal_uid=>45619189374923623
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161497476029434884)
,p_db_column_name=>'INTEGRATION'
,p_display_order=>10
,p_column_identifier=>'F'
,p_column_label=>'Integration'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161497840555434885)
,p_db_column_name=>'PIPELINE_STATUS'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>'Pipeline Status'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161498303529434885)
,p_db_column_name=>'CURRENT_ENVIRONMENT'
,p_display_order=>30
,p_column_identifier=>'H'
,p_column_label=>'Current Environment'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161498735261434886)
,p_db_column_name=>'NEXT_ENVIRONMENT'
,p_display_order=>40
,p_column_identifier=>'I'
,p_column_label=>'Next Environment'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161499042864434886)
,p_db_column_name=>'ENVIRONMENT_WITH_ACTION'
,p_display_order=>50
,p_column_identifier=>'J'
,p_column_label=>'Environment With Action'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161497043094434883)
,p_db_column_name=>'PIPELINE_ID'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'History'
,p_column_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_INTEGRATION_ID,P7_PIPELINE_ID:#INTEGRATION#,#PIPELINE_ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14659183324207649)
,p_db_column_name=>'COMMENTS'
,p_display_order=>70
,p_column_identifier=>'N'
,p_column_label=>'Comments'
,p_column_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::P46_PIPELINE_ID,P46_INTEGRATION_ID:#PIPELINE_ID#,#INTEGRATION#'
,p_column_linktext=>'<span class="#COMMENTS#" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(20495259789824416)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'In Progress'
,p_report_seq=>10
,p_report_alias=>'100396'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INTEGRATION:PIPELINE_STATUS:CURRENT_ENVIRONMENT:NEXT_ENVIRONMENT:ENVIRONMENT_WITH_ACTION:COMMENTS:PIPELINE_ID:'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(14880234837111023)
,p_report_id=>wwv_flow_imp.id(20495259789824416)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PIPELINE_STATUS'
,p_operator=>'in'
,p_expr=>'TESTING,READY_TO_DEPLOY'
,p_condition_sql=>'"PIPELINE_STATUS" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''TESTING, READY_TO_DEPLOY''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(194753080509198893)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124840'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INTEGRATION:PIPELINE_STATUS:CURRENT_ENVIRONMENT:NEXT_ENVIRONMENT:ENVIRONMENT_WITH_ACTION:COMMENTS:PIPELINE_ID:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161474477389398956)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194634601267140973)
,p_button_name=>'Close'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(184084704328094860)
,p_button_image_alt=>'Close'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161503670401434894)
,p_name=>'ChangeIntStatus'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_INTEGRATION_STATUS_SCH'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18809423123392182)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(194634601267140973)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18809532911392183)
,p_event_id=>wwv_flow_imp.id(18809423123392182)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194634601267140973)
);
wwv_flow_imp.component_end;
end;
/
