prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>25342774287247165
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APPENGINE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Apps'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'APP_ENGINE'
,p_last_upd_yyyymmddhh24miss=>'20221122210152'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23674217605166021)
,p_plug_name=>'Apps'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(25392080157253315)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT application_name',
'     , ''Installed.'' txt',
'     , app_pkg_utils.get_app_redirect_url(UPPER(application_name)) url',
'  FROM apex_applications a',
'WHERE UPPER(application_name) <> ''APP_ENGINE'';'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(23674350453166022)
,p_region_id=>wwv_flow_imp.id(23674217605166021)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'APPLICATION_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'TXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'URL'
,p_icon_image_url=>'#APP_FILES#icons/app-icon-512.png'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(23674495020166023)
,p_card_id=>wwv_flow_imp.id(23674350453166022)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&URL.'
,p_link_attributes=>'&URL.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25551702847253518)
,p_plug_name=>'Apps'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(25417582657253347)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
