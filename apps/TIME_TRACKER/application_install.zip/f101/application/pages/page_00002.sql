prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>25342774287247165
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APPENGINE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Install - Welcome'
,p_alias=>'INSTALL-WELCOME'
,p_step_title=>'Install - Welcome'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APP_ENGINE'
,p_last_upd_yyyymmddhh24miss=>'20221122202702'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25566427206637637)
,p_plug_name=>'Install - Welcome'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(25462592515253400)
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(25565519487637632)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(25514063814253464)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'<center><h1><b>&P2_APP_NAME. Install</b></h1></center>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25566538059637637)
,p_plug_name=>'Install - Welcome'
,p_parent_plug_id=>wwv_flow_imp.id(25566427206637637)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(25384963968253306)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Welcome to the &P2_APP_NAME. Wizard Setup</b></p>',
'<p>This Wizard will guide you through the installation of &P2_APP_NAME..</p>',
'<p>To proceed with the installation, it is necessary to configure the remote repository. Fill in the information below and click "Test".</p>',
'<p>Click "Next" to continue.</p>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20467560685667612)
,p_plug_name=>'Repo'
,p_parent_plug_id=>wwv_flow_imp.id(25566538059637637)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(25445384602253381)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25567826865637639)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25566427206637637)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25518278265253470)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20467677643667613)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(20467560685667612)
,p_button_name=>'Test'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25518278265253470)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Test'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25568106152637639)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(25566427206637637)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(25518369878253470)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(25568862290637641)
,p_branch_name=>'Go To Page 3'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_APP_NAME:&P2_APP_NAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(25568106152637639)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(23674158014166020)
,p_branch_name=>'Already_installed'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXISTS'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'  FROM apex_applications',
' WHERE UPPER(application_name) = app_pkg_utils.get_profile(''APP_INTERNAL_NAME'')'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20467030656667607)
,p_name=>'P2_REPO_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(20467560685667612)
,p_item_default=>'app_pkg_utils.get_profile(''REPO_NAME'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Repository Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(25515728395253467)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20467176382667608)
,p_name=>'P2_REPO_OWNER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(20467560685667612)
,p_item_default=>'app_pkg_utils.get_profile(''REPO_OWNER'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Repository Owner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(25515728395253467)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20467234296667609)
,p_name=>'P2_APP_NAME'
,p_item_sequence=>10
,p_item_default=>'app_pkg_utils.get_app_info(''APP_NAME'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20467352157667610)
,p_name=>'P2_BITBUCKET_PASS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(20467560685667612)
,p_prompt=>'Bitbucket Token'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(25515728395253467)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20467476005667611)
,p_name=>'P2_BITBUCKET_USER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(20467560685667612)
,p_prompt=>'Bitbucket User'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(25515728395253467)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20468221599667619)
,p_name=>'P2_ERROR'
,p_item_sequence=>20
,p_item_default=>'app_pkg_utils.get_app_info(''APP_NAME'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20467767033667614)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(20467677643667613)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20468134120667618)
,p_event_id=>wwv_flow_imp.id(20467767033667614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Test_repo_connection'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    app_pkg_engine.test_repo_connection(:P2_REPO_NAME',
'        , :P2_REPO_OWNER',
'        , :P2_BITBUCKET_USER',
'        , :P2_BITBUCKET_PASS',
'        , :P2_ERROR',
'        );',
'END;'))
,p_attribute_02=>'P2_REPO_NAME,P2_REPO_OWNER,P2_BITBUCKET_USER,P2_BITBUCKET_PASS'
,p_attribute_03=>'P2_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20468314509667620)
,p_event_id=>wwv_flow_imp.id(20467767033667614)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Error_message'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P2_ERROR.'
,p_attribute_02=>'Repository Configuration'
,p_attribute_03=>'danger'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P2_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20468482488667621)
,p_event_id=>wwv_flow_imp.id(20467767033667614)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Success_message'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Succeeded!'
,p_attribute_02=>'Repository Configuration '
,p_attribute_03=>'success'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P2_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20468535120667622)
,p_event_id=>wwv_flow_imp.id(20467767033667614)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Create_bitbucket_credentials'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    app_pkg_engine.create_bitbucket_credentials(:P2_BITBUCKET_USER',
'        , :P2_BITBUCKET_PASS',
'        , :P2_REPO_NAME',
'        , :P2_REPO_OWNER',
'        );',
'END;'))
,p_attribute_02=>'P2_REPO_NAME,P2_REPO_OWNER,P2_BITBUCKET_USER,P2_BITBUCKET_PASS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P2_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20467889549667615)
,p_event_id=>wwv_flow_imp.id(20467767033667614)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_name=>'Enable_Next_BTN'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25568106152637639)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P2_ERROR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20467977655667616)
,p_name=>'Load'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25568106152637639)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20468099889667617)
,p_event_id=>wwv_flow_imp.id(20467977655667616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25568106152637639)
);
wwv_flow_imp.component_end;
end;
/
