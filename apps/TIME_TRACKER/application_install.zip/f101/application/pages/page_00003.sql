prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>25342774287247165
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APPENGINE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Install - Get DDL Files'
,p_alias=>'INSTALL-GET-DDL-FILES'
,p_step_title=>'Install - Get DDL Files'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.pct-meter {',
'    border-radius: 2px;',
'    height: 20px;',
'    background-color: #d9dee3;',
'    box-shadow: 0 0 0 1px rgba(0, 0, 0, .1) inset;',
'    position: relative;',
'}',
'',
'.pct-meter data {',
'    display: block;',
'    text-align: end;',
'    padding-right: 5px;',
'    border-radius: 2px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APP_ENGINE'
,p_last_upd_yyyymmddhh24miss=>'20221104135529'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25569540229637647)
,p_plug_name=>'Install - Repository Configuration'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_imp.id(25462592515253400)
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(25565519487637632)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(25514063814253464)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'<center><h1><b>&P2_APP_NAME. Install</b></h1></center>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25569640842637647)
,p_plug_name=>'Install - Repository Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(25384963968253306)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Ready to install.</p>',
'<p>Click "Install" to continue.</p>',
'<p>After the progress bar is completed, click "Next" to continue.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25570974384637649)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25518278265253470)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20469734953667634)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_button_name=>'Install'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25518278265253470)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Install'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25571211225637649)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(25518369878253470)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25571159004637649)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25517528237253469)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(25572668751637651)
,p_branch_action=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(25571211225637649)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(25571949045637650)
,p_branch_action=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(25571159004637649)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20468649058667623)
,p_name=>'P3_APP_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20470425224667641)
,p_name=>'P3_PROGRESS_BAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(25569640842637647)
,p_item_default=>'0'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'PLUGIN_COM.FOS.PROGRESS_BAR'
,p_field_template=>wwv_flow_imp.id(25515728395253467)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'line'
,p_attribute_03=>'solid'
,p_attribute_04=>'#5b8133'
,p_attribute_05=>'#e9e7e6'
,p_attribute_07=>'ease-in-out'
,p_attribute_08=>'20000'
,p_attribute_09=>'on-element'
,p_attribute_10=>'no'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25629395340804603)
,p_name=>'P3_PREREQ'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25629772656804607)
,p_name=>'P3_INSTALL_RESULT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(25569540229637647)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20469875078667635)
,p_name=>'Click'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(20469734953667634)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20469959708667636)
,p_event_id=>wwv_flow_imp.id(20469875078667635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470705029667644)
,p_event_id=>wwv_flow_imp.id(20469875078667635)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'60'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470827067667645)
,p_event_id=>wwv_flow_imp.id(20469875078667635)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(20469734953667634)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470139939667638)
,p_event_id=>wwv_flow_imp.id(20469875078667635)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_total   NUMBER;',
'    l_invalid NUMBER;',
'    l_error   VARCHAR2(4000);',
'BEGIN',
'    :P3_INSTALL_RESULT := NULL;',
'    app_pkg_engine.install_ddl(l_total, l_invalid);',
'    IF l_invalid > 0 THEN',
'        :P3_INSTALL_RESULT := l_invalid || '' of '' || l_total || '' objects still invalid!'';',
'    ELSE',
'        :P3_INSTALL_RESULT := l_total || '' installed successfully!'';',
'    END IF;',
'END;'))
,p_attribute_03=>'P3_INSTALL_RESULT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470901386667646)
,p_event_id=>wwv_flow_imp.id(20469875078667635)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PROGRESS_BAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'100'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20470214733667639)
,p_name=>'on_load'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(25571211225637649)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470330321667640)
,p_event_id=>wwv_flow_imp.id(20470214733667639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25571211225637649)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20470548565667642)
,p_name=>'load_resource'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'load'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20470634089667643)
,p_event_id=>wwv_flow_imp.id(20470548565667642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PROGRESS_BAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20471054600667647)
,p_name=>'COMPLETED'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_PROGRESS_BAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_COM.FOS.PROGRESS_BAR|ITEM TYPE|fos_prb_progress_complete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20471180428667648)
,p_event_id=>wwv_flow_imp.id(20471054600667647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P3_INSTALL_RESULT.'
,p_attribute_02=>'Installation Finished'
,p_attribute_03=>'information'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20471285580667649)
,p_event_id=>wwv_flow_imp.id(20471054600667647)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(25571211225637649)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20471372136667650)
,p_name=>'on_page_load'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25629188121804601)
,p_event_id=>wwv_flow_imp.id(20471372136667650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P3_PREREQ := NULL;',
'    IF NOT(app_pkg_engine.prc_pre_requirement_validation(:P3_PREREQ)) THEN',
'        :P3_PREREQ := ''There is pre requirements not done: ''||:P3_PREREQ;',
'    END IF;',
'END;'))
,p_attribute_03=>'P3_PREREQ'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25629679214804606)
,p_event_id=>wwv_flow_imp.id(20471372136667650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'&P3_PREREQ.'
,p_attribute_02=>'Error'
,p_attribute_03=>'danger'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P3_PREREQ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25629477437804604)
,p_event_id=>wwv_flow_imp.id(20471372136667650)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(20469734953667634)
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P3_PREREQ'
);
wwv_flow_imp.component_end;
end;
/
