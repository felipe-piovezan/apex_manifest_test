prompt --application/deployment/install/install_app_name
begin
--   Manifest
--     INSTALL: INSTALL-APP_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>25342774287247165
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APPENGINE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14979490180261912)
,p_install_id=>wwv_flow_imp.id(9052296656401455)
,p_name=>'APP_NAME'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    app_pkg_utils.set_profile(''APP_INTERNAL_NAME'', ''TIME_TRACKER'');',
'END;'))
);
wwv_flow_imp.component_end;
end;
/
