prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>25342774287247165
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APPENGINE'
);
null;
wwv_flow_imp.component_end;
end;
/
